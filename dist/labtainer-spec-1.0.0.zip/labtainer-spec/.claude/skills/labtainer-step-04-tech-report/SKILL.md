---
name: labtainer-step-04-tech-report
description: >-
  Thực hiện Bước 4 trong quy trình chuẩn hoá bài lab Labtainer: Báo cáo Thẻ 3 (Kế hoạch kỹ thuật sửa và build lại bài lab, cấu hình DockerHub và GitHub imodule), Thẻ 4 (Nhận xét của người phụ trách) và Thẻ 5 (Nhận xét HTML).
  Sử dụng khi người dùng yêu cầu "làm bước 4", "hoàn thiện bước 4", hoặc trong cụm "bước 3-4".
---

> **Cấu hình dùng chung:** Đọc [cấu hình](../labtainer-spec/references/configuration.md) và [chuẩn/checklist](../labtainer-spec/references/standards.md). Các `<...>` là tham số cần lấy từ cấu hình/quan sát, không chạy nguyên mẫu. Scripts và assets ở skill `labtainer-spec`. `configuration.md` bên dưới chỉ tài liệu cấu hình này. Mật khẩu lấy từ biến môi trường `connection.password_env`, không lưu trong JSON.


# Bước 4: Báo cáo Thẻ 3, 4, 5 - Kế Hoạch Kỹ Thuật & Tổng Kết Báo Cáo

Skill này hướng dẫn hoàn thiện các thẻ báo cáo kỹ thuật còn lại (Thẻ 3, Thẻ 4 và Thẻ 5) trong hồ sơ chuẩn hoá bài thực hành cho SecLab PTIT.

## Mục Tiêu & Phạm Vi Đầu Ra (Deliverables)

1. **Thẻ 3: Báo cáo sửa và build lại bài lab**:
   - Khai báo tài khoản DockerHub lưu trữ image (`<registry-namespace>`) và link repository GitHub chứa file `imodule.tar`.
   - Lập **Bảng các vấn đề đối với bài lab cũ và hướng xử lý trong lab mới**: Phân tích sâu về logic kỹ thuật Labtainer (sửa `results.config`, `goals.config`, bổ sung task checkwork bị thiếu, sửa script `prestop`/`pregrade.sh`, regex bắt cờ...).
2. **Thẻ 4: Nhận xét của người phụ trách**:
   - Khung đánh giá tiến độ, chất lượng kịch bản, độ ổn định của môi trường và khả năng áp dụng thực tế cho sinh viên PTIT.
3. **Thẻ 5: Nhận xét HTML**:
   - Đánh giá tổng quan về file HTML mới sinh: độ tuân thủ bảng màu box, font chữ, xưng hô, tính trực quan và checklist.
4. **Quy chuẩn Typography Google Docs (nếu đưa vào báo cáo gdocs)**:
   - **Font chữ & Cỡ chữ:** 100% font **Times New Roman**, cỡ chữ **13pt** cho toàn bộ nội dung và các cấp tiêu đề.
   - **Phân cấp tiêu đề (h1, h2, h3, h4 đều cỡ 13pt):**
     - **Heading 1 & Heading 2:** Cỡ **13pt**, **in đậm (bold)**.
     - **Heading 3 & Heading 4:** Cỡ **13pt**, **in đậm + in nghiêng (bold + italic)**.
   - **Định dạng khối lệnh / Code:** Chỉ căn giữa (**CENTER**), giữ nguyên màu chữ đen và kiểu chữ tiêu chuẩn Times New Roman 13pt (tuyệt đối không tô màu xanh lá, không in nghiêng).
   - **Định dạng bảng:** Viền đen mảnh, chữ đen, nền trong suốt 100%, bề rộng $\le 467.7\,\text{pt}$.

---

## Mẫu Trình Bày Chuẩn Cho Thẻ 3, 4, 5

```markdown
# THẺ 3: BÁO CÁO SỬA VÀ BUILD LẠI LAB

*Bài lab hiện được push lên DockerHub tài khoản `<registry-namespace>` và file imodule được lưu trữ tại GitHub repository `<registry-namespace>` với tên lab chuẩn là `[tên_lab_mới]`.*

## Bảng các vấn đề đối với bài lab cũ và hướng xử lý ở bài lab mới

| STT | Vấn đề kỹ thuật ở bài lab cũ | Hướng xử lý cụ thể trong lab mới |
| :--- | :--- | :--- |
| 1 | Hướng dẫn cũ có nhiệm vụ thực hành nhưng thiếu định nghĩa chấm điểm `checkwork` trong `goals.config`. | - Thêm định nghĩa task mới trong `instr_config/goals.config`:<br>`[tên_goal] = matchany : string_equal : [tên_result] : answer=True`<br>- Định nghĩa nguồn kết quả trong `instr_config/results.config`:<br>`[tên_result] = [container]:prestop.stdout : CONTAINS : [FLAG_STRING]`<br>- Viết bổ sung script kiểm tra trong `prestop` của container tương ứng. |
| 2 | Logic kiểm tra tấn công dùng chuỗi tĩnh dễ bị sai lệch khi sinh viên gõ lệnh khác hoặc terminal ngắt kết nối bất thường. | Cải tiến regex trong `results.config` để bắt chính xác dấu nhắc lệnh và trạng thái phiên làm việc thực tế của dịch vụ. |
| 3 | File `pregrade.sh` bị lỗi định dạng kết thúc dòng Windows (CRLF) khiến grader container báo lỗi `autoGrade()`. | Sử dụng `dos2unix` và cấp quyền thực thi `chmod +x` cho toàn bộ các script trong `instr_config`. |
| 4 | File `start.config` cũ đang trỏ `REGISTRY` về tài khoản không thể push hoặc tên lab chưa đồng bộ với CYBOK. | Cập nhật `REGISTRY <registry-namespace>` trong khối `GLOBAL_SETTINGS` và đổi tên lab sang `[tên_lab_mới]`. |

---

# THẺ 4: NHẬN XÉT CỦA NGƯỜI PHỤ TRÁCH

- **Họ và tên người đánh giá:** [Tên cán bộ / Giảng viên phụ trách]
- **Đánh giá về tính sư phạm và kịch bản:**
  - Kịch bản thực tế doanh nghiệp đã mô phỏng rõ nét bài toán an ninh mạng, giúp sinh viên hiểu rõ mục đích của từng thao tác thay vì gõ lệnh thụ động.
  - Phân loại CYBOK 1.1 và môn học tại PTIT chính xác, phù hợp đưa vào khung bài tập thực hành.
- **Đánh giá về tính ổn định kỹ thuật:**
  - Bộ chấm điểm `checkwork` đã bao quát đầy đủ các nhiệm vụ trọng tâm.
  - Đã khắc phục triệt để lỗi môi trường (CRLF, permissions) giúp bài lab đạt AC ổn định trên hệ thống SecLab.
- **Kết luận:** [Đạt yêu cầu đưa vào giảng dạy / Cần hiệu chỉnh thêm].

---

# THẺ 5: NHẬN XÉT HTML

- **Đánh giá về định dạng và bố cục:**
  - Đã áp dụng chuẩn layout theo mẫu SecLab PTIT, phân chia rõ ràng 4 mục tiêu chuẩn.
  - Hệ thống hộp màu sắc (Box) đã phân loại đúng: Xanh lá cho điều kiện checkwork, Đỏ cho câu hỏi, Vàng cho lưu ý, Xanh dương cho gợi ý lệnh.
- **Đánh giá về văn phong:**
  - Toàn bộ văn bản xưng hô "sinh viên", không còn xưng hô "bạn".
  - Đã loại bỏ hoàn toàn lối viết AI Title Case và các từ tiếng Anh giải thích thừa.
  - Các câu hỏi đều có dòng kẻ `Trả lời: ___________________________` chuẩn chỉ.
- **Link imodule tích hợp:** Đã sẵn sàng nhúng đường dẫn raw từ GitHub sau khi hoàn tất Bước 7.
```

---

## Tiêu Chí Kiểm Tra (Checklist Bước 4)
- [ ] Thẻ 3 có bảng giải pháp kỹ thuật cụ thể (định nghĩa rõ cú pháp `goals.config` / `results.config`).
- [ ] Ghi rõ tài khoản DockerHub (`<registry-namespace>`) và repository GitHub của file imodule.
- [ ] Thẻ 4 có đầy đủ các tiêu chí sư phạm, kịch bản và kỹ thuật.
- [ ] Thẻ 5 xác nhận sự tuân thủ các quy chuẩn giao diện của file HTML.

---

## Hướng Dẫn Tái Sử Dụng Helper Toolkit Cho Bước 4

Sử dụng trực tiếp `helpers.lab_parser` để trích xuất nhanh cấu hình Labtainer phục vụ phân tích kỹ thuật:

```python
from helpers.lab_parser import parse_start_config, parse_goals_config, parse_results_config

start_info = parse_start_config("path/to/start.config")
goals = parse_goals_config("path/to/goals.config")
results = parse_results_config("path/to/results.config")
```
Giúp Agent liệt kê đầy đủ các container, biến kết quả và mục tiêu chấm điểm hiện có để lập phương án sửa đổi chuẩn xác.

