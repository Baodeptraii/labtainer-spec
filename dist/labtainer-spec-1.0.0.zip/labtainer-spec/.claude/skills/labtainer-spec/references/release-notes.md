# Căn cứ bản phát hành

Bản 1.0.0 khôi phục đầy đủ skill từng bước từ bộ quy trình gốc. Thứ tự và các phần nội dung chính được giữ: audit, CyBOK, HTML, báo cáo kỹ thuật, chuẩn bị source, rebuild, phát hành, kết nối tester, thực hành lại và báo cáo DOCX.

Những thay đổi có chủ đích:

- Tên skill có namespace labtainer, số bước hai chữ số; coordinator là labtainer-spec.
- Host, user, mật khẩu, mã sinh viên, thư mục cá nhân và namespace registry chuyển thành cấu hình/placeholder.
- Scripts, template và quy tắc chung lưu một nơi ở skill labtainer-spec; các step tham chiếu đến đó.
- Lệnh xóa toàn bộ container, prune toàn host, xóa .git hoặc wildcard docs được giới hạn/bảo toàn theo đúng bài đang xử lý.
- Giữ các yêu cầu hiện hành: URL bất kỳ được giao, ưu tiên ptitdseclab, không cần snapshot sạch, cài công cụ host trước thực hành, ảnh mới từng bước và báo cáo local.
- Ghi rõ giới hạn helper/API và phân biệt kiểm tra offline với kết quả lab thật.

Mẫu DOCX không bị thiết kế lại. Các chỉnh sửa trên không tự chứng minh hiệu suất agent tương đương trên mọi bài; việc đó cần đánh giá thực tế qua các lượt được giao. Không dùng kết quả cũ để tuyên bố đã kiểm thử bản phát hành.
