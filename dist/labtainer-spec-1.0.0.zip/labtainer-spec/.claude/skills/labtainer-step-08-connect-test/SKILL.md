---
name: labtainer-step-08-connect-test
description: Chuẩn bị host và kết nối tester để kiểm thử imodule từ bất kỳ URL được giao, ưu tiên ptitdseclab. Nhận HTML trực tiếp hoặc sau bước 7; không yêu cầu snapshot sạch hay VM độc lập.
---

> **Cấu hình dùng chung:** Đọc [cấu hình](../labtainer-spec/references/configuration.md) và [chuẩn/checklist](../labtainer-spec/references/standards.md). Các `<...>` là tham số cần lấy từ cấu hình/quan sát, không chạy nguyên mẫu. Scripts và assets ở skill `labtainer-spec`. `configuration.md` bên dưới chỉ tài liệu cấu hình này. Mật khẩu lấy từ biến môi trường `connection.password_env`, không lưu trong JSON.


# Bước 8: Chuẩn bị host và kết nối Labtainer

Đọc [cấu hình môi trường](../labtainer-spec/references/configuration.md) và [quy trình kế thừa](../labtainer-spec/references/review-workflow.md). Trong bước 8–10, hướng dẫn ở các skill này bổ sung cách vận hành từ Windows qua SSH; giữ nguyên quy tắc hàng đợi, bằng chứng và báo cáo của bộ review.

## Đầu vào và bàn giao HTML

1. Nhận HTML và URL imodule trực tiếp từ yêu cầu, hoặc HTML sau bước 7 tại `<môn>/New-HTML/<lab>.html`. Chấp nhận mọi URL được giao, ưu tiên ptitdseclab khi lựa chọn/xếp hàng, không giới hạn <registry-namespace> hay domain nào. Giữ nguyên URL được giao; nếu khác link HTML, ghi URL thực tế dùng trong manifest mà không sửa HTML nguồn. Không bắt buộc chạy bước 1–7. Chỉ có URL thì tìm hướng dẫn trong gói/nguồn liên quan; thiếu hướng dẫn phải ghi rõ, không bịa nội dung thực hành. Đọc toàn bộ bài, xác định tên lab từ nội dung.
2. Workspace kiểm thử mặc định là `<workspace>`. Helper nằm ở skill `labtainer-spec`, không dùng thư mục skill làm workspace.
3. Sao chép nguyên byte HTML sang `<workspace>/html/<môn>/<lab>.html`, giữ nguyên các tài nguyên tương đối nếu có. So SHA-256 nguồn và bản sao bằng `Get-FileHash`. Lưu đường dẫn nguồn, hash, URL imodule và thời điểm bàn giao vào hồ sơ. Không đưa template hoặc HTML ví dụ vào hàng đợi.
4. Nếu bản sao/report đã tồn tại, quét trước khi thay đổi: DOCX hợp lệ là SKIP kể cả FAIL hoặc HTML nguồn đã thay đổi; file báo cáo lỗi hoặc tên trùng là CONFLICT. Không ghi đè. Nếu PENDING và HTML staging khác nguồn, bảo toàn lượt cũ trước khi tạo lượt mới. Khi được giao kiểm thử lại bản đã hiệu chỉnh ở bước 9, dùng workspace lượt mới để giữ báo cáo cũ, không SKIP yêu cầu này; xem mục kiểm thử lại trong [bước 9](../labtainer-step-09-execute-html/SKILL.md).

```powershell
$root = (Get-Location).Path
$review = Join-Path $root '.claude/skills/labtainer-spec'
$workspace = '<workspace-from-run-config>'
python "$review/scripts/workspace_queue.py" scan --workspace "$workspace"
# Chỉ prepare bài PENDING đã được bàn giao và đọc hết HTML.
python "$review/scripts/workspace_queue.py" prepare 'html/<môn>/<lab>.html' --workspace "$workspace"
```

## Kết nối và chuẩn bị công cụ trước thực hành

1. Máy tester đã được cung cấp: `<username>@<host>:<port>`, đăng nhập bằng mật khẩu lấy từ biến môi trường được `connection.password_env` chỉ định ở gốc labtainer-spec. Không yêu cầu SSH private key/tệp AES và không bắt buộc alias. Đọc configuration.md để nạp biến môi trường cho backend mật khẩu; không dùng BatchMode=yes cho kết nối này. Không in thông tin mật khẩu ra log.
2. Dùng SSH tương tác hoặc backend mật khẩu Paramiko trên Windows theo configuration.md. Host key phải được xác minh trước. Ghi hostname/user, phiên bản và trạng thái hiện tại để truy vết; không yêu cầu đối chiếu máy build, VM độc lập hay snapshot sạch.
3. Kiểm tra framework, đường dẫn terminal sinh viên, `docker ps -a`, image/phiên bài đang có, dung lượng và truy cập URL/registry thực tế. Tiếp tục phiên phù hợp, không reset/xóa dữ liệu chỉ để tạo môi trường sạch. Ghi dữ liệu và goals có sẵn để phân biệt với kết quả của lượt mới. Không dừng phiên bài không liên quan hoặc chạy nhiều bài chồng nhau.
4. Kiểm tra phiên desktop đăng nhập, `DISPLAY`, Xauthority và các công cụ thực có: SSH/SCP, xdotool, ImageMagick `import` hoặc backend tương thích. Tìm đúng cửa sổ terminal sinh viên bằng tiêu đề thực tế, không gán cứng hostname máy cũ. Chụp thử trên **desktop VM test**, tải PNG về hồ sơ và mở xem; ảnh PowerShell Windows không phải ảnh VM.
5. Tự cài công cụ còn thiếu trên host **bên ngoài container**, trước khi bắt đầu bài: dependency SSH/Paramiko ở Windows, công cụ điều khiển/chụp như xdotool/ImageMagick trên host Labtainer nếu cần. Dùng công cụ cài phù hợp hệ điều hành/quyền hiện có, ghi tên/phiên bản/nơi cài và kiểm tra hoạt động. Không hỏi lại quyền cài đã được giao. Không cài vào container hoặc thêm công cụ khi bài đã chạy. Nếu đang tiếp tục bài dở, áp dụng ngay giới hạn không cài thêm; ghi checkpoint nếu công cụ thiếu thực sự ngăn bước tiếp theo. Chỉ BLOCKED khi lỗi thực tế chưa khắc phục được, không vì thiếu snapshot.

## Đầu ra và điều kiện chuyển bước

Trong manifest ghi `environment` với hostname, phiên bản, đường dẫn, DISPLAY, công cụ đã cài, trạng thái ban đầu, ảnh thử và kết nối; không lưu mật khẩu. Ghi mã sinh viên <student_id> và URL imodule được giao. `environment.step8_status` là READY khi công cụ/kết nối đủ thực hiện, không xét sạch/độc lập. Điền đủ bước HTML dự kiến, mặc định NOT_RUN/false.

Chuyển bước 9 khi có hướng dẫn, kết nối và công cụ thực hành/chụp/xem ảnh hoạt động. Bàn giao manifest/workspace; nếu được giao kiểm thử và báo cáo thì tiếp tục bước 9–10, không dừng để xin xác nhận lại.
