# Detailed step procedures

Use the full step skills below. Their instructions and shared standards are authoritative.

- [Step 10](../../labtainer-step-10-review-report/SKILL.md)
