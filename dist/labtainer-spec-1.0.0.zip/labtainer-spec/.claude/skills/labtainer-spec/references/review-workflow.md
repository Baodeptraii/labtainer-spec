# Quy trình html/ → report/*.docx

Đọc [rules](review-rules.md). Bộ skill nằm ở đâu không quyết định workspace: luôn truyền --workspace khi gọi helper. Chỉ xử lý bài trong html/ của workspace được giao.

## 1. Quét bài chưa có báo cáo

```sh
python3 <skill-dir>/scripts/workspace_queue.py scan --workspace <workspace>
```

Kết quả là danh sách JSON: source_html, report, status, reason.

- SKIP: DOCX đã có, không khởi động bài, không lấy thêm ảnh, không tạo lại báo cáo.
- PENDING: chưa có DOCX, được đưa vào lượt làm.
- CONFLICT: đường dẫn đầu ra đã có nhưng không đọc được như DOCX. Giữ nguyên, báo người dùng và làm bài khác.
- Nếu html/ chưa tồn tại, báo thiếu thư mục; không quét cả workspace hoặc ví dụ trong skill để thay thế.
- Nếu danh sách rỗng hoặc toàn SKIP, trả kết quả ngắn gọn và kết thúc.

Không dùng hash để tự động làm lại bài đã có DOCX. Bản ghi thiếu metadata vẫn được bỏ qua nếu file Word hợp lệ. Báo cáo FAIL cũng được bỏ qua theo yêu cầu người dùng.

## 2. Chuẩn bị bài còn thiếu

Đọc toàn bộ HTML. Xác định lab name thực thi, imodule nếu có, sơ đồ/role, nhiệm vụ, bước mô tả bằng lời, các lệnh và câu hỏi. Không suy lab name chỉ từ tên file.

```sh
python3 <skill-dir>/scripts/workspace_queue.py prepare html/<tên>.html --workspace <workspace>
```

Helper tạo report/_work/<tên>/<run-id>/report-data.json và evidence/, trả đường dẫn báo cáo cuối. Không tự thực thi lab. Trước khi tạo lượt mới, nếu có hồ sơ cũ bị gián đoạn thì đọc nó và đối chiếu trạng thái lab; tiếp tục được thì dùng manifest cũ, không chạy lại lệnh thay đổi trạng thái một cách mù quáng.

Điền vào manifest **toàn bộ bước dự kiến trước khi chạy**, mỗi bước có ID, task, title, source (mục HTML), terminal, action, expected, actual, status, executed, started_at, finished_at, evidence. Mặc định NOT_RUN/false. Ghi các trường cover nếu người dùng cung cấp; không hỏi lại chỉ vì thiếu thông tin bìa.

Thiếu ZIP/diff không chặn luồng thực hành đã đủ HTML và lab đã cài. Chỉ giới hạn phần kết luận về sửa đổi/phát hành. Không tự tải lại imodule nếu không cần; kiểm tra đúng bản và quyền trước reset.

## 3. Kiểm tra năng lực và môi trường

Xác nhận shell host Labtainer khác shell container, cwd đúng, phiên bản lab/framework nếu truy xuất được. Ghi environment vào JSON.

Dò công cụ terminal/desktop/chụp/xem ảnh thực sự có. Nếu dùng xdotool hay backend X11, xác nhận phù hợp phiên desktop và đúng cửa sổ trước khi gõ. Với Wayland, dùng tool tương thích được phép. Không mặc định model có computer-use.

Chụp thử và xem ảnh để kiểm tra đúng màn hình, không bị đen và đọc được. Ảnh thử không tính là minh chứng nhiệm vụ. Nếu không điều khiển hoặc chụp/xem được thì ghi BLOCKED, giữ nháp, không giả lập ảnh.

## 4. Thực hiện và chụp từng bước

Mỗi bước:

1. Xác nhận đúng terminal/container, trạng thái phụ thuộc; lấy placeholder từ giá trị quan sát, không dùng IP trong báo cáo mẫu.
2. Ghi started_at, chạy thao tác HTML. Lệnh mẫu trong bảng cú pháp không tự thành lệnh thực thi.
3. Với tcpdump/listener, dùng terminal riêng và chờ sẵn sàng trước khi tạo lưu lượng ở terminal tác nhân; ghi cách điều phối nếu thứ tự hiển thị trong HTML dễ gây nhầm. Dừng đúng tiến trình của lượt mình, không kill toàn hệ thống.
4. Với nano/editor, thao tác đúng file trong container, lưu và xác nhận. Thay đổi route/DNS trong bài là thao tác thực hành được giao, không bị nhầm với sửa định nghĩa lab.
5. Quan sát thực tế theo điều kiện hoàn thành; lỗi có chủ đích như ping bị chặn có thể là kết quả đúng. Không chỉ nhìn exit code.
6. Chụp ảnh mới cho lệnh/thao tác và kết quả, xem lại đúng cửa sổ/role, rõ chữ, không lộ dữ liệu ngoài bài. Với output dài chụp nhiều ảnh và giữ log.
7. Điền actual, trạng thái, thời gian và evidence; ghi JSON ngay sau bước.

Ví dụ nếu máy có scrot phù hợp:

```sh
python3 <skill-dir>/scripts/capture_screen.py <run-dir>/evidence/S01-01.png --backend scrot
```

Helper chụp desktop hiện tại, không focus cửa sổ thay agent. Dùng công cụ chụp agent nếu có; đầu ra minh chứng cho DOCX là PNG. Mỗi evidence có file tương đối với run-dir, caption, captured_at, origin=live-capture. Không gắn hình sơ đồ tài liệu thành evidence thực thi.

## 5. Kiểm tra kết quả

Kiểm tra đúng hướng dẫn, hành vi thực tế và checkwork; đủ Y không xóa lỗi HTML hoặc mục tiêu đạt sớm. Lưu ảnh bảng checkwork. Dùng stoplab để lấy .lab của đúng lượt khi phù hợp, sao chép artifact thật vào run-dir và ghi assessment.lab_file tương đối. Không đổi đuôi ZIP để tạo .lab.

PASS cần toàn bộ bước bắt buộc đạt, ảnh, full_y và .lab. FAIL cần bước lỗi đã thực hiện có ảnh; các bước phụ thuộc chưa làm phải ghi rõ. BLOCKED khi thiếu điều kiện, chưa đủ cơ sở nghiệm thu. N/A phải có lý do trong actual. Với lab không có checkwork phù hợp, giữ BLOCKED cho đến khi tiêu chí thay thế được xác nhận.

Câu trả lời dùng lý thuyết và quan sát thực tế, phân biệt suy luận với kiểm tra đã chạy. Không suy từ ảnh mẫu. Nếu không hoàn tất, vẫn lưu checkpoint và tiếp tục bài khác khi môi trường cho phép.

## 6. Sinh Word theo mẫu

```sh
python3 <skill-dir>/scripts/render_report.py <run-dir>/report-data.json --workspace <workspace>
```

Helper tự ánh xạ source_html tới report/<tên>.docx, từ chối ghi đè và xác minh HTML chưa đổi kể từ prepare. Không nhập tên đầu ra tùy ý để tránh ghép nhầm bài.

Mẫu là assets/report-template.docx, chuẩn hóa từ Mẫu báo cáo thực hành.docx:
- Bìa, logo, font/styles, lề và footer từ mẫu.
- Mục lục và danh mục hình mới, không giữ số trang minh họa cũ.
- CÁC BƯỚC THỰC HIỆN: nhiệm vụ, thao tác, kỳ vọng, thực tế, ảnh/chú thích và câu hỏi.
- KẾT QUẢ BÀI THỰC HÀNH: trạng thái, nhận xét, checkwork/.lab, nguồn/phiên bản, giới hạn.

Helper chỉ tạo tài liệu, không chạy chuỗi action trong JSON và không thể tự chứng minh ảnh là thật. Agent vẫn phải đối chiếu và xem ảnh. Không có browser/PDF dependency.

Nếu BLOCKED:

```sh
python3 <skill-dir>/scripts/render_report.py <run-dir>/report-data.json --workspace <workspace> --draft
```

Bản nháp nằm trong run-dir/draft.docx, không chặn lần scan tiếp theo. Nếu đã có draft.docx, giữ bản cũ và cập nhật JSON; cần bản nháp mới thì tạo phiên/đường lưu riêng sau khi bảo toàn bản cũ. Không xuất BLOCKED thành báo cáo cuối.

## 7. Kiểm tra và kết thúc lượt

Mở/đọc DOCX, kiểm tra không còn ví dụ Windows/Moodle/CPU, không sai dấu, ảnh đủ và đúng nhiệm vụ. Nếu có Word/LibreOffice, render xem bố cục; PDF chỉ là sản phẩm kiểm tra tùy chọn, không phải đầu ra bắt buộc. Nếu không render được, nói rõ mức kiểm tra cấu trúc đã thực hiện.

Chạy scan lại. Báo các file đã tạo, bài SKIP, bài bị chặn và lý do. Không cần bảng tiến độ cầu kỳ hay daemon: mỗi yêu cầu mới quét lại thư mục. Bài đã có DOCX được giữ nguyên; bài mới tiếp tục được xử lý.

## Điều chỉnh khi dùng ở labtainer-spec

Ví dụ python3 dành cho Linux; Windows dùng python hoặc py -3. Workspace là <workspace>, HTML staging từ yêu cầu trực tiếp hoặc New-HTML sau bước 7 và so SHA-256 theo skill bước 8. capture_screen.py phải chạy trên VM test, không chạy trên Windows để giả định chụp được VM; SCP ảnh về evidence trước khi render. Kiểm tra terminal/desktop áp dụng cho VM test hiện có. Mục 1–3 thuộc bước 8, mục 4–5 thuộc bước 9, mục 6–7 thuộc bước 10.

Quy tắc hiện hành: nhận imodule từ mọi URL được giao, ưu tiên ptitdseclab, không cần bước 1–7 hoặc snapshot sạch/VM độc lập. Tự cài công cụ cần thiết trên host trước thực hành; không cài thêm khi bài đã chạy hoặc trong container. Nhập <student_id> khi prompt yêu cầu. Thực hành/chụp từng bước, ghi nhận dữ liệu có sẵn. Template Word của học viện không đổi; xuất local vào thư mục báo cáo được giao, mặc định <workspace>/report.
