#!/usr/bin/env python3
"""Create a DOCX from the supplied Word template and real review evidence. Python 3.10+."""
import argparse
from copy import deepcopy
import hashlib
import io
import json
import os
from pathlib import Path
import re
import struct
import tempfile
import xml.etree.ElementTree as E
from zipfile import ZipFile, ZIP_DEFLATED
from workspace_queue import PACK, confined, paths, valid_docx

NS = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
      "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
      "wp": "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
      "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
      "pic": "http://schemas.openxmlformats.org/drawingml/2006/picture"}
for prefix, uri in NS.items():
    E.register_namespace(prefix, uri)
REL = "http://schemas.openxmlformats.org/package/2006/relationships"
CT = "http://schemas.openxmlformats.org/package/2006/content-types"
STATUSES = {"PASS", "FAIL", "BLOCKED", "NOT_RUN", "N/A"}

def tag(prefix, name):
    return "{" + NS[prefix] + "}" + name

def element(prefix, name, attrs=None, text=None):
    node = E.Element(tag(prefix, name), attrs or {})
    node.text = text
    return node

def xml(root):
    # ElementTree may drop declarations referenced only by mc:Ignorable.
    for node in root.iter():
        node.attrib.pop("{http://schemas.openxmlformats.org/markup-compatibility/2006}Ignorable", None)
    return E.tostring(root, encoding="utf-8", xml_declaration=True)

def paragraph(text="", style="BTL-Text", page_break=False):
    p = element("w", "p")
    pr = E.SubElement(p, tag("w", "pPr"))
    E.SubElement(pr, tag("w", "pStyle"), {tag("w", "val"): style})
    if page_break:
        E.SubElement(pr, tag("w", "pageBreakBefore"))
    if style in {"BTL-H0", "BTL-H1", "BTL-H2"}:
        E.SubElement(pr, tag("w", "keepNext"))
        num = E.SubElement(pr, tag("w", "numPr"))
        E.SubElement(num, tag("w", "numId"), {tag("w", "val"): "0"})
    for i, line in enumerate(str(text).split("\n")):
        r = E.SubElement(p, tag("w", "r"))
        if i:
            E.SubElement(r, tag("w", "br"))
        t = E.SubElement(r, tag("w", "t"), {"{http://www.w3.org/XML/1998/namespace}space": "preserve"})
        t.text = line
    return p

def replace_paragraph(p, value):
    props = deepcopy(p.find("w:pPr", NS))
    run_props = p.find("w:r/w:rPr", NS)
    run_props = deepcopy(run_props) if run_props is not None else None
    for child in list(p):
        p.remove(child)
    if props is not None:
        p.append(props)
    run = E.SubElement(p, tag("w", "r"))
    if run_props is not None:
        run.append(run_props)
    E.SubElement(run, tag("w", "t"), {"{http://www.w3.org/XML/1998/namespace}space": "preserve"}).text = value

def png_info(path):
    raw = path.read_bytes()
    if len(raw) < 33 or raw[:8] != b"\x89PNG\r\n\x1a\n" or raw[12:16] != b"IHDR":
        raise ValueError("Evidence must be a PNG: " + str(path))
    width, height = struct.unpack(">II", raw[16:24])
    if not width or not height or width > 30000 or height > 30000:
        raise ValueError("Invalid screenshot dimensions")
    return raw, width, height

def validate(data, run):
    for key in ("lab", "run_id", "source_html", "source_sha256", "status", "summary",
                "environment", "steps", "assessment", "limitations"):
        if key not in data:
            raise ValueError("Missing field: " + key)
    if data["status"] not in {"PASS", "FAIL", "BLOCKED"}:
        raise ValueError("Invalid overall status")
    if not data["steps"]:
        raise ValueError("No planned steps")
    ids, evidence = set(), []
    for s in data["steps"]:
        for key in ("id", "task", "title", "source", "terminal", "action", "expected",
                    "actual", "status", "executed", "started_at", "finished_at", "evidence"):
            if key not in s:
                raise ValueError("Missing step field: " + key)
        if s["id"] in ids or s["status"] not in STATUSES or type(s["executed"]) is not bool:
            raise ValueError("Invalid step ID/status/executed")
        ids.add(s["id"])
        if s["status"] in {"PASS", "FAIL"} and not s["executed"]:
            raise ValueError("PASS/FAIL requires execution")
        if s["executed"] and not (s["started_at"] and s["finished_at"]):
            raise ValueError("Executed step requires timestamps")
        if s["status"] in {"PASS", "FAIL"} and not s["evidence"]:
            raise ValueError("PASS/FAIL requires screenshot evidence")
        if s["status"] in {"BLOCKED", "N/A"} and not str(s["actual"]).strip():
            raise ValueError("BLOCKED/N/A requires a reason")
        for ev in s["evidence"]:
            if any(not ev.get(k) for k in ("file", "caption", "captured_at", "origin")):
                raise ValueError("Incomplete evidence metadata")
            if ev["origin"] != "live-capture":
                raise ValueError("Only live-capture is execution evidence")
            p = confined(run / ev["file"], run)
            raw, width, height = png_info(p)
            evidence.append((s["id"], ev, raw, width, height))
    assessment = data["assessment"]
    if assessment.get("status") not in STATUSES:
        raise ValueError("Invalid assessment status")
    if data["status"] == "FAIL" and not any(s["status"] == "FAIL" for s in data["steps"]):
        raise ValueError("FAIL requires a documented failed step")
    if any(s["status"] == "FAIL" for s in data["steps"]) and data["status"] != "FAIL":
        raise ValueError("A failed step requires overall FAIL")
    if data["status"] == "PASS":
        if any(s["status"] not in {"PASS", "N/A"} for s in data["steps"]):
            raise ValueError("PASS contains unfinished steps")
        if not any(s["status"] == "PASS" for s in data["steps"]):
            raise ValueError("PASS requires a passed step")
        if assessment.get("full_y") is not True or assessment["status"] != "PASS":
            raise ValueError("PASS requires confirmed full Y")
        lab_file = assessment.get("lab_file")
        if not lab_file:
            raise ValueError("PASS requires a real .lab")
        lab = confined(run / lab_file, run)
        if lab.suffix.lower() != ".lab" or not lab.is_file() or lab.stat().st_size == 0:
            raise ValueError("PASS requires a nonempty .lab")
        goal_ids = assessment.get("evidence_step_ids", [])
        if not goal_ids or not set(goal_ids) <= ids:
            raise ValueError("Assessment requires evidence step IDs")
        if any(next(s for s in data["steps"] if s["id"] == i)["status"] != "PASS" for i in goal_ids):
            raise ValueError("Assessment evidence step must pass")
    return evidence

def picture(rel_id, number, width, height, caption, max_width=6000000):
    # Preserve aspect ratio; cap both width and height for A4 content area.
    scale = min(max_width / width, 7000000 / height, 9525)
    cx, cy = max(1, int(width * scale)), max(1, int(height * scale))
    p = paragraph("", "BTL-Text")
    pr = p.find("w:pPr", NS)
    E.SubElement(pr, tag("w", "keepNext"))
    E.SubElement(pr, tag("w", "jc"), {tag("w", "val"): "center"})
    drawing = E.SubElement(E.SubElement(p, tag("w", "r")), tag("w", "drawing"))
    inline = E.SubElement(drawing, tag("wp", "inline"), {"distT":"0","distB":"0","distL":"0","distR":"0"})
    E.SubElement(inline, tag("wp", "extent"), {"cx":str(cx),"cy":str(cy)})
    E.SubElement(inline, tag("wp", "docPr"), {"id":str(1000+number),"name":"Evidence "+str(number),"descr":caption})
    frame = E.SubElement(inline, tag("wp", "cNvGraphicFramePr"))
    E.SubElement(frame, tag("a", "graphicFrameLocks"), {"noChangeAspect":"1"})
    gd = E.SubElement(E.SubElement(inline, tag("a", "graphic")), tag("a", "graphicData"), {"uri":NS["pic"]})
    pic = E.SubElement(gd, tag("pic", "pic"))
    nv = E.SubElement(pic, tag("pic", "nvPicPr"))
    E.SubElement(nv, tag("pic", "cNvPr"), {"id":"0","name":"Evidence "+str(number)})
    E.SubElement(nv, tag("pic", "cNvPicPr"))
    fill = E.SubElement(pic, tag("pic", "blipFill"))
    E.SubElement(fill, tag("a", "blip"), {tag("r", "embed"):rel_id})
    E.SubElement(E.SubElement(fill, tag("a", "stretch")), tag("a", "fillRect"))
    sp = E.SubElement(pic, tag("pic", "spPr"))
    transform = E.SubElement(sp, tag("a", "xfrm"))
    E.SubElement(transform, tag("a", "off"), {"x":"0","y":"0"})
    E.SubElement(transform, tag("a", "ext"), {"cx":str(cx),"cy":str(cy)})
    E.SubElement(E.SubElement(sp, tag("a", "prstGeom"), {"prst":"rect"}), tag("a", "avLst"))
    return p

def build(data, run, template):
    evidence = validate(data, run)
    with ZipFile(template) as z:
        parts = {n:z.read(n) for n in z.namelist()}
    root = E.fromstring(parts["word/document.xml"])
    body = root.find("w:body", NS)
    marker = [n for n in body if "".join(n.itertext()) == "{{REPORT_BODY}}"]
    if len(marker) != 1:
        raise ValueError("Expected normalized report-template.docx marker")
    final_section = deepcopy(body.find("w:sectPr", NS))
    cut = list(body).index(marker[0])
    for n in list(body)[cut:]:
        body.remove(n)
    cover = data.get("cover", {})
    replacements = {"{{LAB}}":data["lab"], "{{COURSE}}":cover.get("course", ""),
                    "{{COURSE_CODE}}":cover.get("course_code", ""),
                    "{{REVIEWER}}":cover.get("reviewer", "Agent review"),
                    "{{INSTRUCTOR}}":cover.get("instructor", ""),
                    "{{TERM}}":cover.get("term", "")}
    for p in body.findall(".//w:p", NS):
        text = "".join(t.text or "" for t in p.findall(".//w:t", NS))
        changed = text
        for token, value in replacements.items():
            changed = changed.replace(token, str(value))
        if changed != text:
            replace_paragraph(p, changed)
    rels = E.fromstring(parts["word/_rels/document.xml.rels"])
    types = E.fromstring(parts["[Content_Types].xml"])
    if not any(n.get("Extension") == "png" for n in types):
        E.SubElement(types, "{"+CT+"}Default", {"Extension":"png","ContentType":"image/png"})
    headings = []
    for s in data["steps"]:
        title = s["task"]
        if title not in headings:
            headings.append(title)
    body.append(paragraph("MỤC LỤC", "BTL-H0"))
    body.append(paragraph("CÁC BƯỚC THỰC HIỆN", "TOC1"))
    for title in headings:
        body.append(paragraph(title, "TOC2"))
    body.append(paragraph("KẾT QUẢ BÀI THỰC HÀNH", "TOC1"))
    body.append(paragraph("DANH MỤC CÁC HÌNH VẼ", "BTL-H0", True))
    captions = []
    for i, (_, ev, _, _, _) in enumerate(evidence, 1):
        captions.append("Hình " + str(i) + " — " + ev["caption"])
        body.append(paragraph(captions[-1], "TableofFigures"))
    if not evidence:
        body.append(paragraph("Chưa có hình minh chứng; xem trạng thái và giới hạn ở cuối báo cáo."))
    body.append(paragraph("CÁC BƯỚC THỰC HIỆN", "BTL-H0", True))
    body.append(paragraph("Bài: " + data["lab"] + " | Phiên: " + data["run_id"]))
    for item in data.get("overview", []):
        body.append(paragraph(item["title"] + ": " + item["text"]))
    current_task, number = None, 0
    for s in data["steps"]:
        if current_task != s["task"]:
            body.append(paragraph(s["task"], "BTL-H1"))
            current_task = s["task"]
        body.append(paragraph(s["id"] + " — " + s["title"], "BTL-H2"))
        for label, key in [("Nguồn HTML","source"),("Terminal","terminal"),("Thao tác","action"),
                           ("Mong đợi","expected"),("Thực tế","actual"),("Trạng thái","status")]:
            body.append(paragraph(label + ": " + str(s[key])))
        body.append(paragraph("Thời gian: " + s["started_at"] + " → " + s["finished_at"]))
        for sid, ev, raw, width, height in evidence:
            if sid != s["id"]:
                continue
            number += 1
            rid = "rIdEvidence" + str(number)
            member = "word/media/evidence-" + str(number) + ".png"
            parts[member] = raw
            E.SubElement(rels, "{"+REL+"}Relationship", {"Id":rid,"Type":NS["r"]+"/image",
                                                        "Target":"media/evidence-"+str(number)+".png"})
            body.append(picture(rid, number, width, height, captions[number-1]))
            body.append(paragraph(captions[number-1], "BTL-Hinh"))
            body.append(paragraph("Chụp lúc: " + ev["captured_at"] + " | SHA-256: " + hashlib.sha256(raw).hexdigest()))
    for answer in data.get("answers", []):
        body.append(paragraph("Câu hỏi: " + answer["question"], "BTL-H2"))
        body.append(paragraph("Trả lời: " + answer["answer"]))
        body.append(paragraph("Căn cứ: " + answer.get("basis", "")))
    body.append(paragraph("KẾT QUẢ BÀI THỰC HÀNH", "BTL-H0", True))
    for label, value in [("Kết luận",data["status"]),("Nhận xét",data["summary"]),
                         ("Nguồn HTML",data["source_html"]),("SHA-256",data["source_sha256"]),
                         ("Môi trường",json.dumps(data["environment"],ensure_ascii=False,indent=2)),
                         ("Đánh giá/.lab",json.dumps(data["assessment"],ensure_ascii=False,indent=2)),
                         ("Giới hạn/việc còn lại",data["limitations"])]:
        body.append(paragraph(label + ": " + value))
    body.append(final_section)
    parts["word/document.xml"] = xml(root)
    parts["word/_rels/document.xml.rels"] = xml(rels)
    parts["[Content_Types].xml"] = xml(types)
    buffer = io.BytesIO()
    with ZipFile(buffer, "w", ZIP_DEFLATED) as z:
        for n, content in parts.items():
            z.writestr(n, content)
    return buffer.getvalue()

def publish(manifest, workspace, draft=False, template=None):
    workspace = Path(workspace).resolve()
    run = Path(manifest).resolve().parent
    confined(run, workspace / "report" / "_work")
    data = json.loads(Path(manifest).read_text(encoding="utf-8-sig"))
    source, output, _ = paths(workspace, data["source_html"])
    digest = hashlib.sha256(source.read_bytes()).hexdigest()
    if data["source_sha256"] != digest:
        raise ValueError("HTML changed since prepare; do not publish evidence for another version")
    if data["status"] == "BLOCKED" and not draft:
        raise ValueError("BLOCKED is a draft; use --draft so the next scan retries it")
    if draft:
        output = run / "draft.docx"
    if output.exists():
        raise FileExistsError("Report already exists; no overwrite: " + str(output))
    template = Path(template) if template else PACK / "assets/report-template.docx"
    content = build(data, run, template)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=output.parent, prefix=".report-", suffix=".tmp", delete=False) as f:
        staged = Path(f.name)
        f.write(content)
    try:
        if not valid_docx(staged):
            raise ValueError("Generated DOCX failed package validation")
        if hashlib.sha256(source.read_bytes()).hexdigest() != digest:
            raise ValueError("HTML changed during report generation")
        # Atomic no-clobber publication: existing files always win, even in a race.
        os.link(staged, output)
    finally:
        staged.unlink(missing_ok=True)
    return output

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("manifest", type=Path)
    p.add_argument("--workspace", type=Path, default=Path.cwd())
    p.add_argument("--draft", action="store_true", help="Save BLOCKED draft only inside the run directory")
    args = p.parse_args()
    print(publish(args.manifest, args.workspace, args.draft))

if __name__ == "__main__":
    main()
