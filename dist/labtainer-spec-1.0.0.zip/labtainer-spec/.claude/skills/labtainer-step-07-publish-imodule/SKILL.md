---
name: labtainer-step-07-publish-imodule
description: >-
  Thực hiện Bước 7 trong quy trình chuẩn hoá bài lab Labtainer: Đẩy image bài lab lên DockerHub (publish.py), tạo gói imodule (.tar), đẩy lên kho lưu trữ GitHub và cập nhật đường dẫn tải (raw download link) vào file hướng dẫn HTML cùng báo cáo.
  Sử dụng khi người dùng yêu cầu "làm bước 7", "hoàn thiện bước 7", hoặc khi cần phát hành trước giai đoạn kiểm thử thực tế.
---

> **Cấu hình dùng chung:** Đọc [cấu hình](../labtainer-spec/references/configuration.md) và [chuẩn/checklist](../labtainer-spec/references/standards.md). Các `<...>` là tham số cần lấy từ cấu hình/quan sát, không chạy nguyên mẫu. Scripts và assets ở skill `labtainer-spec`. `configuration.md` bên dưới chỉ tài liệu cấu hình này. Mật khẩu lấy từ biến môi trường `connection.password_env`, không lưu trong JSON.


# Bước 7: Publish DockerHub, Tạo imodule GitHub & Cập Nhật Raw Link

Skill này hướng dẫn hoàn tất công đoạn đóng gói, phát hành và phân phối bài lab mới lên DockerHub và GitHub, đồng thời cập nhật đường dẫn tải chính thức vào tài liệu hướng dẫn.

## Mục Tiêu & Phạm Vi Đầu Ra (Deliverables)

1. **DockerHub Image**: Hình ảnh container bài lab được đẩy thành công lên tài khoản DockerHub `<registry-namespace>`.
2. **Gói `imodule` trên GitHub**: File nén `<tên_lab_mới>.tar` được tạo và đẩy lên kho mã nguồn `github.com/<registry-namespace>/...` thông qua Personal Access Token (PAT).
3. **Cập nhật Raw Download Link**: Đường dẫn tải file `.tar` trực tiếp từ GitHub được tích hợp vào file HTML hướng dẫn thực hành và Thẻ 3 của báo cáo.

---

## Các Bước Thực Thi Chi Tiết

> **Thực thi từ Windows Host qua SSH:**
> ```powershell
> ssh -n labtainer-build "<chuỗi_lệnh_bash>"
> ```


### 1. Đăng nhập DockerHub & Publish Image

1. **Đăng nhập DockerHub trên terminal:**
   ```bash
   docker login
   # Nhập Username: <registry-namespace>
   # Nhập mật khẩu tài khoản DockerHub
   ```

2. **Thực thi script phân phối:**
   ```bash
   cd ~/labtainer/trunk/distrib
   ./publish.py -d -l <tên_lab_mới>
   ```
   > **Xử lý sự cố nếu script báo lỗi:**
   > Đối với bài lab chỉ có 1 container, nếu gặp lỗi không tìm thấy cấu hình hoặc tên image, hãy kiểm tra lại file `~/labtainer/trunk/labs/<tên_lab_mới>/config/start.config` để đảm bảo tên container và `REGISTRY <registry-namespace>` đã đồng bộ hoàn toàn.

---

### 2. Tạo Gói `imodule` Cho Sinh Viên

```bash
cd ~/labtainer/trunk/labs
# Dùng working tree dành cho việc đóng gói; bảo toàn .git hiện có.
git status
# Chỉ git init khi đây là thư mục mới được giao và chưa có repository.
git add <tên_lab_mới>
git commit -m "add <tên_lab_mới>"
create-imodules.sh
```

Lệnh `create-imodules.sh` sẽ sinh ra file `imodule.tar` đặt tại thư mục cha `~/labtainer/trunk/`.

Tiến hành sao chép và đổi tên theo đúng định danh bài lab để tránh bị ghi đè:
```bash
cp ~/labtainer/trunk/imodule.tar ~/labtainer/trunk/<tên_lab_mới>.tar
```

---

### 3. Đẩy Gói `imodule` Lên Kho Lưu Trữ GitHub

*(Ví dụ sử dụng kho lưu trữ của nhóm: `https://github.com/<registry-namespace>/pen_lab_2026.git`)*

```bash
cd ~/labtainer/trunk
git init 2>/dev/null
git remote add origin https://github.com/<registry-namespace>/pen_lab_2026.git 2>/dev/null || git remote set-url origin https://github.com/<registry-namespace>/pen_lab_2026.git
git add <tên_lab_mới>.tar
git commit -m "add imodule for <tên_lab_mới>"
git branch -M main
git push -u origin main
```

**Thông tin xác thực GitHub:**
- **Username:** `<registry-namespace>` (hoặc tài khoản quản trị repo)
- **Password:** Nhập **Personal Access Token (PAT)** có quyền ghi (write/push repo).

---

### 4. Cập Nhật Raw Link Vào File Hướng Dẫn HTML & Thẻ 3 Báo Cáo

1. **Xác định đường dẫn tải trực tiếp (Raw Download Link):**
   Cú pháp chuẩn theo `guide-template.html`:
   `https://github.com/<registry-namespace>/pen_lab_2026/raw/refs/heads/main/<tên_lab_mới>.tar`  
   *(hoặc: `https://raw.githubusercontent.com/<registry-namespace>/pen_lab_2026/main/<tên_lab_mới>.tar`)*

2. **Cập nhật vào file `<tên_lab_mới>.html`:**
   Tìm đến phần hướng dẫn tải bài lab trong hộp `<div class="box box-info">` ở đầu Mục 4 của file HTML, điền lệnh `imodule` chuẩn (chú ý: không để thừa chữ "imodule" rườm rà ở 2 đầu):
   ```html
   <code>imodule https://github.com/<registry-namespace>/pen_lab_2026/raw/refs/heads/main/<tên_lab_mới>.tar</code>
   ```

3. **Cập nhật vào Thẻ 3 của Báo cáo:**
   Ghi rõ link DockerHub và link GitHub repo vào phần đầu Thẻ 3 để phục vụ công tác nghiệm thu, quản lý.

---

## Tiêu Chí Kiểm Tra (Checklist Bước 7)
- [ ] Image bài lab đã hiển thị công khai trên DockerHub tài khoản `<registry-namespace>`.
- [ ] File `<tên_lab_mới>.tar` đã được commit và push lên GitHub nhánh `main`.
- [ ] Đường dẫn tải trực tiếp file tar hoạt động ổn định (trả về mã HTTP 200).
- [ ] Đã nhúng link vào khối `.box-info` của file HTML và cập nhật Thẻ 3 hoàn tất.


## Bàn giao bước 8

Giữ HTML hoàn chỉnh trong New-HTML, ghi URL imodule và image đã phát hành. Khi được giao tiếp bước 8–10, dùng labtainer-step-08-connect-test để bàn giao nguyên byte HTML và kiểm tra trên VM mới; bước 7 chưa phải nghiệm thu cuối.
