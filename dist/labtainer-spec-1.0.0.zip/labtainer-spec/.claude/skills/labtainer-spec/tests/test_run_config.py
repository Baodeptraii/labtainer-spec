import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from run_config import child_environment, load_config


class ConfigTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name).resolve()
        (self.root / "guide.html").write_text("<html>fixture</html>", encoding="utf-8")
        (self.root / "known_hosts").touch()
        self.config = {
            "schema_version": 1, "mode": "retest", "steps": [8, 9, 10],
            "source_html": "guide.html", "workspace": "work", "report_directory": "out",
            "student_id": "fixture-id", "imodule_url": "https://example.org/lab.tar",
            "connection": {"host": "192.0.2.10", "username": "fixture", "port": 2222,
                           "password_env": "TEST_PASSWORD", "known_hosts": "known_hosts"}}
        self.file = self.root / "run.local.json"

    def load(self):
        self.file.write_text(json.dumps(self.config), encoding="utf-8")
        return load_config(self.file)

    def test_paths_are_relative_to_config_and_port_is_forwarded(self):
        data = self.load()
        self.assertEqual(data["workspace"], str(self.root / "work"))
        env = child_environment(data, {"TEST_PASSWORD": "fixture-secret", "LABTAINER_SSH_KEY": "old"})
        self.assertEqual(env["LABTAINER_SSH_PORT"], "2222")
        self.assertEqual(env["LABTAINER_SSH_PASSWORD"], "fixture-secret")
        self.assertNotIn("LABTAINER_SSH_KEY", env)

    def test_missing_password_rejected(self):
        with self.assertRaises(ValueError):
            child_environment(self.load(), {})

    def test_inline_password_rejected(self):
        self.config["connection"]["password"] = "fixture"
        with self.assertRaises(ValueError):
            self.load()

    def test_arbitrary_url_host_allowed_but_embedded_credentials_rejected(self):
        self.config["imodule_url"] = "https://other.example.net/releases/lab.tar"
        self.load()
        self.config["imodule_url"] = "https://user:secret@example.net/lab.tar"
        with self.assertRaises(ValueError):
            self.load()

    def test_report_only_does_not_require_vm_credentials(self):
        self.config["steps"] = [10]
        self.config.pop("connection")
        env = child_environment(self.load(), {"LABTAINER_SSH_TARGET": "stale"})
        self.assertNotIn("LABTAINER_SSH_TARGET", env)

    def test_build_steps_use_the_supplied_host_without_existing_output_html(self):
        self.config["steps"] = [5, 6, 7]
        self.config["source_html"] = "future-guide.html"
        data = self.load()
        env = child_environment(data, {"TEST_PASSWORD": "fixture-secret"})
        self.assertEqual(env["LABTAINER_SSH_TARGET"], "fixture@192.0.2.10")

    def test_invalid_port_rejected_for_build_host(self):
        self.config["steps"] = [5]
        self.config["connection"]["port"] = 70000
        with self.assertRaises(ValueError):
            self.load()


if __name__ == "__main__":
    unittest.main()
