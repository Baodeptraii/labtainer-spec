---
name: labtainer-step-01-audit
description: >-
  Thực hiện Bước 1 trong quy trình chuẩn hoá bài lab Labtainer: Báo cáo Thẻ 1 - Nhận xét bài lab gốc và kiểm thử hiện trạng.
  Sử dụng khi người dùng yêu cầu "làm bước 1", "hoàn thiện bước 1", hoặc trong cụm "bước 1-2".
---

> **Cấu hình dùng chung:** Đọc [cấu hình](../labtainer-spec/references/configuration.md) và [chuẩn/checklist](../labtainer-spec/references/standards.md). Các `<...>` là tham số cần lấy từ cấu hình/quan sát, không chạy nguyên mẫu. Scripts và assets ở skill `labtainer-spec`. `configuration.md` bên dưới chỉ tài liệu cấu hình này. Mật khẩu lấy từ biến môi trường `connection.password_env`, không lưu trong JSON.


# Bước 1: Báo cáo Thẻ 1 - Nhận xét Bài Lab Gốc & Kiểm Thử Hiện Trạng

Skill này hướng dẫn thực hiện trọn vẹn Bước 1 theo quy chuẩn báo cáo Google Docs của SecLab PTIT.

## Mục Tiêu & Phạm Vi Đầu Ra (Deliverables)

1. **Bản sao chép nội dung bài lab gốc** được đưa vào Tab 1 của Google Docs (`Báo cáo 1: Nhận xét chung về bài lab`).
2. **Quy chuẩn Header & Typography Google Docs**:
   - Tiêu đề đầu trang in chữ **ĐỎ nổi bật** (`<mã_lab_cũ>`, font đỏ đậm `#d93025`, in đậm, 20–22pt) và **CĂN GIỮA (CENTER)** thay vì ghi "BÁO CÁO THẺ 1...".
   - **Font chữ toàn văn bản:** Sử dụng 100% font **Times New Roman**, cỡ chữ **13pt** cho toàn bộ nội dung và các cấp tiêu đề.
   - **Phân cấp tiêu đề rõ ràng (h1, h2, h3, h4 đều cỡ 13pt Times New Roman):**
     - **Heading 1 & Heading 2:** Cỡ **13pt**, **in đậm (bold)**.
     - **Heading 3 & Heading 4:** Cỡ **13pt**, **in đậm + in nghiêng (bold + italic)**.
   - **Định dạng khối lệnh / Code:** Chỉ căn giữa (**CENTER**), giữ nguyên màu chữ đen và kiểu chữ tiêu chuẩn Times New Roman 13pt (tuyệt đối không tô màu xanh lá, không in nghiêng).
   - **Xóa bỏ hoàn toàn** 2 dòng metadata: `Chủ đề gốc: ...` và `Tác giả bài gốc: ...` cùng các phần báo cáo đồ án tốt nghiệp của tác giả bài cũ.
3. **Cơ chế Nhận xét (Comments) Native Google Docs**:
   - **Xóa sạch toàn bộ khối text comment inline** trong nội dung bài (`💬 Comment nhận xét...`).
   - Sử dụng **Google Docs API `batchUpdate` (`insertComment`)** với tọa độ `startIndex` và `endIndex` chính xác để tạo mã neo `kix.*` nội bộ.
   - Mỗi comment phải neo và bôi vàng (highlight) trực tiếp vào đoạn văn bản được nhận xét. **Tuyệt đối không để xảy ra lỗi "Đã xóa nội dung gốc"**.
4. **Quy Tắc Kiểm Thử Thực Tế & Chụp Ảnh Minh Chứng**:
   - **Tuân thủ đúng hướng dẫn bài cũ:** Thực hiện theo đúng các bước và lệnh trong tài liệu đề bài gốc (`.docx`).
   - **Không cố gắng gượng ép để đạt Y hết:** Tuyệt đối không can thiệp hay tạo file giả lập để ép checkwork đạt `Y`. Nếu làm theo hướng dẫn bài cũ mà kết quả trả về `N` hoặc lỗi thì ghi nhận trung thực hiện trạng, ghi chú nguyên nhân kỹ thuật và gắn native comment audit chỉ rõ lỗi đó. Chuẩn hóa để đạt 100% `Y` sẽ được thực hiện bài bản ở Bước 5 & 6.
   - **Bắt buộc thao tác trực tiếp trên terminal của bài lab sinh ra (TUYỆT ĐỐI KHÔNG TỰ TẠO TERMINAL MỚI):**
     • Khi chạy `labtainer <tên_lab>`, hệ thống Labtainer đã tự động khởi tạo các cửa sổ terminal container trên màn hình máy ảo (`DISPLAY=:0`) theo đúng cấu hình `start.config` (ví dụ: `ubuntu@attacker:~` với số lượng tab tương ứng).
     • **Nghiêm cấm tuyệt đối:** Không được chạy các lệnh `xterm`, `gnome-terminal`, `xterm -e ...` hoặc tự mở cửa sổ terminal mới riêng bên ngoài để chụp ảnh.
     • **Cơ chế tương tác kỹ thuật bắt buộc qua `xdotool`:**
       1. Tìm Window ID của cửa sổ terminal container: `WID=$(DISPLAY=:0 xdotool search --name "ubuntu@<tên_container>: ~" | head -n 1)`.
       2. Kích hoạt cửa sổ: `DISPLAY=:0 xdotool windowactivate --sync $WID`.
       3. Nhập lệnh vào terminal: `DISPLAY=:0 xdotool type '<lệnh>' && DISPLAY=:0 xdotool key Return`.
       4. Chuyển đổi tab ảo (nếu có nhiều tab): `DISPLAY=:0 xdotool key alt+1`, `alt+2`.
       5. Chụp ảnh màn hình đúng cửa sổ đó: `DISPLAY=:0 import -window $WID /tmp/<tên_ảnh>.png`.
   - **Phân biệt rõ ràng 2 loại Terminal khi thao tác và chụp ảnh:**
     • **Terminal của container bài lab (`ubuntu@<tên_container>:~`):** Dành riêng cho toàn bộ các thao tác kỹ thuật chuyên môn (quét mạng, khai thác lỗ hổng, chèn payload, netcat đón shell, leo quyền root, tạo file backdoor...).
     • **Terminal của máy trạm sinh viên (`student@LabtainerVMware:~/labtainer/labtainer-student`):** Dành riêng cho các câu lệnh điều khiển hệ thống gồm `labtainer <tên_lab>`, `checkwork` và `stoplab <tên_lab>`. Khi chụp ảnh minh chứng cho `checkwork` hoặc `stoplab`, bắt buộc phải chuyển sang cửa sổ này (`DISPLAY=:0 xdotool search --name "student@LabtainerVMware: ~/labtainer/labtainer-student"`) để chạy lệnh và chụp ảnh.
   - **Khởi động Firefox không lỗi Sandbox:** Khi mở trình duyệt Firefox từ terminal của container trong bài lab, nếu gặp lỗi sandbox hoặc ứng dụng không khởi động được, sử dụng câu lệnh: `MOZ_DISABLE_CONTENT_SANDBOX=1 firefox &`.
   - **Bắt buộc chạy stoplab khi kết thúc mỗi bài lab:** Ngay sau khi hoàn thành phiên kiểm thử hoặc chụp ảnh minh chứng của mỗi bài lab, bắt buộc phải thực thi câu lệnh `stoplab` trên terminal máy trạm sinh viên (`~/labtainer/labtainer-student`) để dừng toàn bộ container và giải phóng tài nguyên.
   - **Gộp nhiều lệnh trên 1 terminal theo nhóm việc:** Được phép chạy nhiều lệnh liên tiếp trên cùng một cửa sổ terminal nếu các lệnh đó phục vụ chung một nhóm việc/nhiệm vụ.
   - **Mở terminal và truy cập (access) đúng yêu cầu khi chụp ảnh:** Nếu bước nào trong kịch bản bắt buộc phải mở thêm terminal hoặc truy cập (access) vào một container/máy chủ khác (ví dụ: mở terminal đón reverse shell, SSH sang máy đích, hoặc console chuyên biệt), phải mở terminal và truy cập (access) đúng ngữ cảnh môi trường theo yêu cầu rồi mới thực hiện thao tác và chụp ảnh màn hình minh chứng.
   - **Chụp đúng giao diện thực tế đối với các bước tương tác GUI:** Với các bước thao tác trên giao diện đồ họa (như mở trình duyệt Firefox duyệt web, đăng nhập/đăng ký tài khoản, tải lên tệp web shell, hoặc dùng công cụ GUI như OWASP ZAP, Wireshark, Burp Suite...), bắt buộc phải chụp chính xác cửa sổ giao diện ứng dụng đó (cửa sổ Firefox hiển thị trang web/form/kết quả hoặc giao diện công cụ ZAP/Wireshark), tuyệt đối **KHÔNG chụp màn hình terminal chỉ gõ lệnh chạy nền** (như `firefox &` hay curl).

## Tiêu Chí Kiểm Tra (Checklist Bước 1)
- [ ] Sao chép nguyên vẹn nội dung bài gốc vào Tab 1 Google Docs, không chèn phần nhận xét tổng kết hay đánh giá nộp bài vào thân bài.
- [ ] 100% nhận xét được gắn qua Native Comments trỏ chính xác vào văn bản gốc, nội dung súc tích.
- [ ] Tiêu đề in đỏ đậm, loại bỏ thông tin đồ án cá nhân.
- [ ] Kiểm thử thực tế bám sát tài liệu gốc, không ép Y, ghi nhận trung thực hiện trạng lỗi để phục vụ Báo cáo 2 và Bước 5-6.
- [ ] Bắt buộc sử dụng chính các cửa sổ terminal do bài lab sinh ra trên màn hình máy ảo (X11 DISPLAY=:0), tuyệt đối không tự tạo terminal mới bằng xterm hay gnome-terminal.
- [ ] Minh chứng checkwork và stoplab bắt buộc được chụp trên cửa sổ terminal máy trạm sinh viên (`student@LabtainerVMware:~/labtainer/labtainer-student`).
- [ ] Trường hợp cần mở thêm terminal phụ hoặc access sang container/máy chủ khác đã được truy cập đúng ngữ cảnh môi trường trước khi chụp ảnh minh chứng.
- [ ] Các bước tương tác giao diện đồ họa (Firefox, ZAP, Wireshark) được chụp đúng cửa sổ giao diện ứng dụng thực tế, không chụp terminal gõ lệnh chạy nền.

---

## Hướng Dẫn Tái Sử Dụng Helper Toolkit Cho Bước 1

Thay vì tự viết lại toàn bộ code tương tác SSH hay Google Docs, Agent sử dụng trực tiếp các hàm hoặc CLI sau:

1. **Khởi tạo Google Doc & Chuẩn A4:**
   ```powershell
   python -m helpers.cli doc-setup <doc_id> <tên_lab_gốc>
   ```
2. **Khởi động bài lab trên VM:**
   ```powershell
   python -m helpers.cli vm-start <tên_lab_gốc> --student-id <student_id>
   ```
3. **Thao tác lệnh và chụp ảnh container terminal:**
   ```powershell
   python -m helpers.cli vm-type <tên_container> "<câu_lệnh>"
   python -m helpers.cli vm-capture-container <tên_container> <đường_dẫn_ảnh_png>
   ```
4. **Chạy checkwork và chụp ảnh terminal sinh viên:**
   ```powershell
   python -m helpers.cli vm-checkwork <tên_lab_gốc>
   python -m helpers.cli vm-capture-student <đường_dẫn_ảnh_png>
   ```
5. **Dừng lab:**
   ```powershell
   python -m helpers.cli vm-stop
   ```
6. **Upload ảnh lên Drive & gắn Native Comments:**
   ```powershell
   python -m helpers.cli drive-upload <đường_dẫn_ảnh_png>
   python -m helpers.cli doc-add-comments <doc_id> <tab1_id> <file_comments.json>
   ```