# Detailed step procedures

Use the full step skills below. Their instructions and shared standards are authoritative.

- [Step 1](../../labtainer-step-01-audit/SKILL.md)
- [Step 2](../../labtainer-step-02-scenario-cybok/SKILL.md)
- [Step 3](../../labtainer-step-03-html-guide/SKILL.md)
- [Step 4](../../labtainer-step-04-tech-report/SKILL.md)
