#!/usr/bin/env python3
"""Scan workspace/html and prepare only missing workspace/report/*.docx jobs."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import uuid
import xml.etree.ElementTree as ET
import zipfile

PACK = Path(__file__).resolve().parents[1]

def confined(path, root):
    result = Path(path).resolve()
    if not result.is_relative_to(Path(root).resolve()):
        raise ValueError("Path escapes workspace: " + str(path))
    return result

def paths(workspace, source):
    workspace = Path(workspace).resolve()
    html_root = confined(workspace / "html", workspace)
    source = Path(source)
    source = confined(source if source.is_absolute() else workspace / source, html_root)
    if not source.is_file() or source.suffix.lower() not in {".html", ".htm"}:
        raise ValueError("Expected an HTML file below workspace/html")
    relative = source.relative_to(html_root)
    if any(p.startswith("_") for p in relative.parts):
        raise ValueError("Names starting with _ are reserved")
    report_root = confined(workspace / "report", workspace)
    output = confined(report_root / relative.with_suffix(".docx"), report_root)
    return source, output, relative

def valid_docx(path):
    try:
        with zipfile.ZipFile(path) as z:
            if z.testzip() is not None:
                return False
            ET.fromstring(z.read("[Content_Types].xml"))
            doc = ET.fromstring(z.read("word/document.xml"))
            return doc.tag == "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}document"
    except (OSError, zipfile.BadZipFile, KeyError, ET.ParseError):
        return False

def scan(workspace):
    workspace = Path(workspace).resolve()
    html_root = confined(workspace / "html", workspace)
    if not html_root.is_dir():
        raise ValueError("Missing html/ directory")
    jobs, names = [], {}
    for candidate in sorted(html_root.rglob("*")):
        if not candidate.is_file() or candidate.suffix.lower() not in {".html", ".htm"}:
            continue
        source, output, relative = paths(workspace, candidate)
        key = output.relative_to(workspace).as_posix().casefold()
        if key in names:
            raise ValueError("Output name collision: " + names[key] + " and " + str(relative))
        names[key] = str(relative)
        status = "PENDING"
        if output.exists():
            status = "SKIP" if valid_docx(output) else "CONFLICT"
        jobs.append({"source_html": source.relative_to(workspace).as_posix(),
                     "report": output.relative_to(workspace).as_posix(),
                     "status": status,
                     "reason": {"PENDING": "No report", "SKIP": "Report already exists",
                                "CONFLICT": "Existing path is not a valid DOCX; preserve it"}[status]})
    return jobs

def prepare(workspace, source_name):
    workspace = Path(workspace).resolve()
    source, output, relative = paths(workspace, source_name)
    jobs = scan(workspace)
    job = next(j for j in jobs if j["source_html"] == source.relative_to(workspace).as_posix())
    if job["status"] != "PENDING":
        raise FileExistsError(job["reason"])
    work = confined(workspace / "report" / "_work" / relative.with_suffix(""), workspace / "report")
    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + uuid.uuid4().hex[:8]
    run = work / run_id
    run.mkdir(parents=True, exist_ok=False)
    (run / "evidence").mkdir()
    data = json.loads((PACK / "templates/report-data.json").read_text(encoding="utf-8"))
    data.update(lab=source.stem, run_id=run_id,
                source_html=source.relative_to(workspace).as_posix(),
                source_sha256=hashlib.sha256(source.read_bytes()).hexdigest())
    manifest = run / "report-data.json"
    manifest.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return {"manifest": str(manifest), "report": str(output), "run_dir": str(run)}

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("action", choices=("scan", "prepare"))
    p.add_argument("source", nargs="?", help="Workspace-relative html/file.html for prepare")
    p.add_argument("--workspace", type=Path, default=Path.cwd())
    args = p.parse_args()
    if args.action == "scan":
        result = scan(args.workspace)
    else:
        if not args.source:
            p.error("prepare requires html/file.html")
        result = prepare(args.workspace, args.source)
    print(json.dumps(result, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
