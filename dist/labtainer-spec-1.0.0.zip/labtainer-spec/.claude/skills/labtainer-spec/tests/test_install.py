import importlib.util
from pathlib import Path
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[4]
installer = None
if (ROOT / "tools/install.py").is_file():
    spec = importlib.util.spec_from_file_location("release_installer", ROOT / "tools/install.py")
    installer = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(installer)


@unittest.skipIf(installer is None, "Installer tests require the full release repository")
class InstallTests(unittest.TestCase):
    def test_installs_all_skills_and_preserves_project_instructions(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp)
            (target / "CLAUDE.md").write_text("existing instructions", encoding="utf-8")
            installer.install(target)
            self.assertEqual(len(list((target / ".claude/skills").glob("*/SKILL.md"))), 11)
            self.assertEqual((target / "CLAUDE.md").read_text(), "existing instructions")
            installer.install(target)  # same-content installation is idempotent
            self.assertTrue((target / "config/run.example.json").is_file())

    def test_conflict_is_detected_before_installing_other_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp)
            conflict = target / ".claude/skills/labtainer-spec/SKILL.md"
            conflict.parent.mkdir(parents=True)
            conflict.write_text("custom instructions", encoding="utf-8")
            with self.assertRaises(ValueError):
                installer.install(target)
            self.assertEqual(conflict.read_text(), "custom instructions")
            self.assertFalse((target / ".claude/skills/labtainer-step-01-audit").exists())


if __name__ == "__main__":
    unittest.main()
