# Detailed step procedures

Use the full step skills below. Their instructions and shared standards are authoritative.

- [Step 8](../../labtainer-step-08-connect-test/SKILL.md)
- [Step 9](../../labtainer-step-09-execute-html/SKILL.md)
