---
name: labtainer-step-05-prep-rename
description: >-
  Thực hiện Bước 5 trong quy trình chuẩn hoá bài lab Labtainer: Chuẩn bị mã nguồn gốc, cài đặt Java 17 và công cụ labedit, đổi tên bài lab chuẩn CYBOK, cấu hình REGISTRY DockerHub và làm sạch thư mục docs.
  Sử dụng khi người dùng yêu cầu "làm bước 5", "hoàn thiện bước 5", hoặc trong cụm "bước 5-6".
---

> **Cấu hình dùng chung:** Đọc [cấu hình](../labtainer-spec/references/configuration.md) và [chuẩn/checklist](../labtainer-spec/references/standards.md). Các `<...>` là tham số cần lấy từ cấu hình/quan sát, không chạy nguyên mẫu. Scripts và assets ở skill `labtainer-spec`. `configuration.md` bên dưới chỉ tài liệu cấu hình này. Mật khẩu lấy từ biến môi trường `connection.password_env`, không lưu trong JSON.


# Bước 5: Chuẩn Bị Source Gốc, Cài Java 17 & Đổi Tên Lab (`labedit`)

Skill này hướng dẫn thực thi các thao tác thiết lập ban đầu đối với mã nguồn bài lab Labtainer trên máy trạm (workstation) Linux của Labtainer.

## Mục Tiêu & Phạm Vi Đầu Ra (Deliverables)

1. **Mã nguồn gốc đầy đủ**: Thư mục bài lab phải có đầy đủ: `config/`, `dockerfiles/`, `docs/`, `instr_config/`, thư mục chứa dữ liệu container (ví dụ `user/`), `read_first.txt`.
2. **Môi trường Java 17 & `labedit`**: Cài đặt thành công Java 17 và sẵn sàng công cụ đồ họa `labedit`.
3. **Đổi tên bài lab chuẩn CYBOK**: Đổi tên an toàn bằng `labedit` (trừ môn Phân tích mã độc có tiền tố `mal` giữ nguyên).
4. **Cấu hình `start.config`**: Thiết lập `REGISTRY <registry-namespace>` trong khối `GLOBAL_SETTINGS`.
5. **Làm sạch `docs/`**: Xoá sạch tài liệu cũ và tạo file rỗng `read_first.txt` để dừng ở prompt `Press <enter> to start the lab`.

---

## Các Lệnh Thực Thi Chi Tiết Trên Terminal Linux

> **Thực thi từ Windows Host qua SSH:**
> Để chạy các lệnh dưới đây từ Windows, sử dụng cấu trúc:
> ```powershell
> ssh -n labtainer-build "<chuỗi_lệnh_bash>"
> ```


### 1. Chuẩn bị Mã nguồn gốc (Source Code)

- **Trường hợp bài lab có sẵn trong hệ thống Labtainer:**
  ```bash
  cd /home/student/labtainer
  ./update-designer.sh
  ```
  *(Mã nguồn gốc đầy đủ sẽ nằm tại `~/labtainer/trunk/labs/<tên_lab>`)*

- **Trường hợp bài lab do PTIT hoặc sinh viên tự phát triển (như các bài `pen_attk_*`):**
  *Lưu ý quan trọng:* Nếu trước đó đã chạy tải bài bằng `imodule`, thư mục trong `trunk/labs/` sẽ bị **thiếu** thư mục `dockerfiles/`. Phải xoá thư mục đó đi và dùng file `.zip` gốc:
  ```bash
  # Xoá bài lab cũ bị thiếu dockerfiles
  # Xác minh đúng thư mục của bài, sao lưu sang đường dẫn chưa tồn tại trước khi thay.
  mv ~/labtainer/trunk/labs/<tên_lab_cũ> <đường_dẫn_sao_lưu_chưa_tồn_tại>

  # Copy file zip code gốc vào thư mục labs và giải nén
  cp /path/to/<tên_lab_cũ>.zip ~/labtainer/trunk/labs/
  cd ~/labtainer/trunk/labs
  unzip <tên_lab_cũ>.zip

  # Kiểm tra các thư mục bắt buộc
  ls -la <tên_lab_cũ>
  # Phải thấy: config, dockerfiles, docs, instr_config, user (hoặc tên container)
  ```

---

### 2. Cài đặt Môi trường Java 17 & `labedit`

```bash
cd /home/student/labtainer
./update-designer.sh

sudo apt update
# Mật khẩu sudo mặc định: <mật-khẩu-sudo-của-VM>

sudo apt install openjdk-17-jdk -y

# Cấu hình chọn phiên bản Java 17:
sudo update-alternatives --config java
# (Nhập số thứ tự tương ứng với openjdk-17 rồi nhấn Enter)

# Kiểm tra lại phiên bản Java:
java -version
```

---

### 3. Đổi Tên Bài Lab Bằng `labedit`

*(Quy tắc: Ngoại trừ môn Phân tích mã độc luôn mang tiền tố `mal` đã chuẩn CYBOK, các môn khác cần đổi tên cho thống nhất chuẩn CYBOK, ví dụ `pen_attk_mitre_t1548` $\rightarrow$ `atk-mitre-t1548`).*

1. Khởi động công cụ:
   ```bash
   labedit
   ```
2. Trên menu thanh công cụ: Chọn **File** $\rightarrow$ **Open Lab**.
3. Chọn đường dẫn: `/home/student/labtainer/trunk/labs/<tên_lab_cũ>` $\rightarrow$ Nhấn **Open**.
4. Chọn **File** $\rightarrow$ **Save Lab As**, nhập tên mới (ví dụ: `atk-mitre-t1548`) và nhấn **Confirm**.
5. Sau khi lưu thành công, đóng giao diện `labedit`.

---

### 4. Cấu hình `REGISTRY` và Làm Sạch Thư Mục `docs`

Di chuyển vào thư mục bài lab mới (ví dụ `atk-mitre-t1548`):

1. **Cấu hình `start.config`**:
   ```bash
   cd ~/labtainer/trunk/labs/<tên_lab_mới>/config
   ```
   Chỉnh sửa file `start.config` để khối `GLOBAL_SETTINGS` trỏ đúng về registry của nhóm:
   ```text
   GLOBAL_SETTINGS
       LAB_MASTER_SEED <master_seed>
       REGISTRY <registry-namespace>
   ```

2. **Làm sạch `docs` và tạo `read_first.txt` rỗng**:
   ```bash
   cd ~/labtainer/trunk/labs/<tên_lab_mới>/docs
   # Sao lưu docs trước; chỉ xóa các tệp hướng dẫn cũ đã xác định trong docs của bài này.
   touch read_first.txt
   ```
   *(Ý nghĩa: File rỗng `read_first.txt` giúp lúc sinh viên gõ lệnh khởi động lab sẽ dừng lại ở dòng `Press <enter> to start the lab` mà không in văn bản rác cũ).*

---

## Tiêu Chí Kiểm Tra (Checklist Bước 5)
- [ ] Thư mục lab mới có đầy đủ thư mục `dockerfiles/`.
- [ ] Đã chạy `java -version` và xác nhận phiên bản OpenJDK 17.
- [ ] Tên bài lab mới được lưu đồng bộ qua `labedit`.
- [ ] File `start.config` có `REGISTRY <registry-namespace>`.
- [ ] Thư mục `docs/` chỉ chứa duy nhất 1 file `read_first.txt` có kích thước 0 byte.
