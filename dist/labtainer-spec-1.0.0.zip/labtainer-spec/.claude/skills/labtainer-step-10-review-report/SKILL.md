---
name: labtainer-step-10-review-report
description: Viết báo cáo DOCX bước 10 theo Mẫu báo cáo thực hành từ hồ sơ kiểm thử HTML trên labtainer-test ở bước 9. Giữ hàng đợi html/report, không ghi đè báo cáo và chỉ xuất nháp khi BLOCKED.
---

> **Cấu hình dùng chung:** Đọc [cấu hình](../labtainer-spec/references/configuration.md) và [chuẩn/checklist](../labtainer-spec/references/standards.md). Các `<...>` là tham số cần lấy từ cấu hình/quan sát, không chạy nguyên mẫu. Scripts và assets ở skill `labtainer-spec`. `configuration.md` bên dưới chỉ tài liệu cấu hình này. Mật khẩu lấy từ biến môi trường `connection.password_env`, không lưu trong JSON.


# Bước 10: Báo cáo kiểm thử theo template

Claude Code chạy bước này hoàn toàn trên máy thật Windows. Python, template, manifest và ảnh đã tải về đều ở local; sinh DOCX vào `<workspace>/report/`. Không SSH sang tester để render, không cài Word/LibreOffice hay bộ helper báo cáo trên VM. VM `<username>@<host>` chỉ thực thi bài theo HTML và cung cấp ảnh/log/.lab cho bước 9.

Đọc [rules](../labtainer-spec/references/review-rules.md), [workflow](../labtainer-spec/references/review-workflow.md) và [schema](../labtainer-spec/templates/report-data.json). Bộ helper và [mẫu Word](../labtainer-spec/assets/report-template.docx) dùng chung từ skill `labtainer-spec`; mẫu đã loại nội dung ví dụ/danh tính cũ từ `Mẫu báo cáo thực hành.docx`. Không thay bằng mẫu HTML, báo cáo Google Docs hoặc PDF. Thông tin tích hợp ở [nguồn kế thừa](../labtainer-spec/references/release-notes.md).

1. Nhận workspace `<workspace>` (hoặc workspace lượt riêng đã thống nhất) và manifest bước 9. Đọc toàn bộ hồ sơ, ảnh, `.lab`, kết quả checkwork và giới hạn. Xác minh chúng thuộc đúng HTML/hash và đúng VM test; không tự chạy lại bài khi chỉ được giao viết báo cáo.
2. Quét hàng đợi bằng lệnh dưới: DOCX hợp lệ cùng tên → SKIP kể cả FAIL; đầu ra lỗi hoặc trùng → CONFLICT, bảo toàn. BLOCKED chưa có kết luận chỉ tạo nháp trong `_work/`.
3. Hoàn thiện bìa học phần/người thực hiện nếu đã biết, nếu thiếu để trống hoặc Agent review. Viết mục tiêu/kịch bản, các nhiệm vụ và bước thực hiện, ảnh/chú thích, câu trả lời, kết quả PASS/FAIL/BLOCKED, checkwork và `.lab`, URL phát hành, VM/snapshot, nguồn/hash và giới hạn. Phân biệt lỗi HTML, lỗi gói/image, lỗi môi trường và kết quả có chủ đích. Không suy AC nếu chưa nộp hệ thống.
4. Sinh Word từ mẫu, không viết lại bố cục bìa/logo/styles/lề/footer. Không ghi đè báo cáo hoặc đổi tên output tùy ý. Cột mục lục và danh mục hình do helper sinh từ nội dung; helper không tính số trang mục lục tự động.

```powershell
$root = (Get-Location).Path
$review = Join-Path $root '.claude/skills/labtainer-spec'
$workspace = '<workspace-from-run-config>'
python "$review/scripts/workspace_queue.py" scan --workspace "$workspace"
# $manifest là đường dẫn report-data.json được prepare trả về ở bước 8.
python "$review/scripts/render_report.py" "$manifest" --workspace "$workspace"
# Với BLOCKED, thay lệnh render trên bằng:
python "$review/scripts/render_report.py" "$manifest" --workspace "$workspace" --draft
```

5. Kiểm tra DOCX mở được, tiếng Việt đúng, ảnh khớp bước/chú thích, không còn ví dụ/danh tính mẫu. Có Word/LibreOffice thì render và xem bố cục; thiếu công cụ phải ghi rõ chỉ kiểm tra cấu trúc. Test helper không chứng minh lab đã PASS hoặc ảnh thật.
6. Quét lại và bàn giao `report/<môn>/<lab>.docx`, hồ sơ `_work/`, danh sách SKIP/CONFLICT/BLOCKED và lỗi cần sửa. FAIL có căn cứ là báo cáo review hoàn tất nhưng bài lab chưa đạt; BLOCKED không tạo báo cáo cuối. Không tự đăng Google Docs hay nộp SecLab.

Kiểm tra helper offline: `python -B -m unittest discover -s "$review/tests" -v`. Fixture kiểm thử phần mềm không được dùng làm bằng chứng lab.

## Nguồn và định danh hiện hành

Với lượt kiểm thử lại bản hiệu chỉnh ở bước 9, dùng chính workspace/manifest mới đã bàn giao; báo cáo lần trước không khiến lượt mới bị SKIP. Trình bày URL và bản hướng dẫn đã dùng, các điểm hiệu chỉnh được kiểm tra lại, kết quả thực hành mới và giới hạn. Giữ báo cáo cũ, không ghép ảnh/.lab cũ vào lượt này.

Nhận hồ sơ kiểm thử imodule từ URL bất kỳ, ưu tiên ptitdseclab; không yêu cầu bài đã qua bước 7, nguồn <registry-namespace> hoặc VM sạch/độc lập. Ghi mã sinh viên <student_id> vào thông tin người thực hiện (không suy tên thật), URL thực tế và trạng thái ban đầu trong báo cáo. Phân biệt kết quả sẵn có với từng thao tác/ảnh mới. Dùng template DOCX chuẩn học viện đã đóng gói tại ../labtainer-spec/assets/report-template.docx, giữ bìa/logo/styles/lề/footer.

Ưu tiên thư mục báo cáo người dùng đã chỉ định; mặc định <workspace>/report. Helper ánh xạ theo workspace/report: chọn workspace sao cho report/ đúng nơi đã yêu cầu. Nếu thư mục đích có tên khác report, render vào report/ của workspace lượt riêng rồi sao chép DOCX đã kiểm tra đến đích, giữ tên tương ứng và không ghi đè; kiểm tra đích trước queue để không vô tình làm lại báo cáo đã có. Bàn giao đường dẫn báo cáo cuối và evidence local.
