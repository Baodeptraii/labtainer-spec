"""
Module: helpers.cli
Giao diện dòng lệnh (CLI) hỗ trợ Agent và Kỹ sư thực hiện nhanh các tác vụ
chuẩn hóa bài lab mà không cần viết lại mã script Python.

Cách sử dụng:
  python -m helpers.cli --help
  python -m helpers.cli doc-setup <doc_id> <lab_name>
  python -m helpers.cli doc-style-tables <doc_id> <tab2_id>
  python -m helpers.cli doc-add-comments <doc_id> <tab1_id> <comments_json_path>
  python -m helpers.cli drive-upload <file_path>
  python -m helpers.cli vm-start <lab_name> [--student-id <id>]
  python -m helpers.cli vm-stop [lab_name]
  python -m helpers.cli vm-checkwork [lab_name]
  python -m helpers.cli vm-capture-student <output_png>
  python -m helpers.cli vm-capture-container <container_name> <output_png>
  python -m helpers.cli vm-type <container_name> <command>
  python -m helpers.cli vm-list-windows
"""

import sys
import json
import argparse
import os

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from helpers import vm, gdocs, lab_parser


def main():
    parser = argparse.ArgumentParser(description="SecLab PTIT Helper CLI Toolkit")
    subparsers = parser.add_subparsers(dest="command", help="Danh sách lệnh hỗ trợ")

    # 1. doc-setup
    p_setup = subparsers.add_parser("doc-setup", help="Thiết lập 2 Tab chuẩn và khổ A4 4 lề cho Google Docs")
    p_setup.add_argument("doc_id", help="Google Docs Document ID")
    p_setup.add_argument("lab_name", help="Tên bài lab (VD: pen_c3_t1048_002)")
    p_setup.add_argument("--subtext", default=None, help="Mô tả phụ bên dưới tiêu đề đỏ")

    # 2. doc-style-tables
    p_tables = subparsers.add_parser("doc-style-tables", help="Dinh dang cot A4 va xoa mau nen o trong suot 100%%")
    p_tables.add_argument("doc_id", help="Google Docs Document ID")
    p_tables.add_argument("tab_id", help="ID của Tab 2 (VD: t.tkne18lqkcj9)")

    # 3. doc-add-comments
    p_comments = subparsers.add_parser("doc-add-comments", help="Đăng native comments từ tệp JSON và bôi vàng")
    p_comments.add_argument("doc_id", help="Google Docs Document ID")
    p_comments.add_argument("tab_id", help="ID của Tab 1")
    p_comments.add_argument("comments_json", help="Đường dẫn file JSON chứa list [{'snippet': '...', 'comment': '...'}]")
    p_comments.add_argument("--keep-old", action="store_true", help="Không xóa comments cũ")

    # 4. drive-upload
    p_upload = subparsers.add_parser("drive-upload", help="Upload ảnh chụp lên Drive và lấy direct download link")
    p_upload.add_argument("file_path", help="Đường dẫn tệp ảnh PNG trên máy trạm")
    p_upload.add_argument("--filename", default=None, help="Tên hiển thị trên Drive")

    # 5. vm-start
    p_vm_start = subparsers.add_parser("vm-start", help="Khởi động bài lab trên máy ảo Labtainer")
    p_vm_start.add_argument("lab_name", help="Tên bài lab")
    p_vm_start.add_argument("--student-id", default=os.environ.get("LABTAINER_STUDENT_ID", ""), help="Mã sinh viên dùng khi prompt email")
    p_vm_start.add_argument("--no-reset", action="store_true", help="Không dùng cờ -r")

    # 6. vm-stop
    p_vm_stop = subparsers.add_parser("vm-stop", help="Dừng bài lab trên máy ảo")
    p_vm_stop.add_argument("lab_name", nargs="?", default="", help="Tên bài lab (tuỳ chọn)")

    # 7. vm-checkwork
    p_vm_cw = subparsers.add_parser("vm-checkwork", help="Chạy lệnh checkwork trên terminal máy trạm sinh viên")
    p_vm_cw.add_argument("lab_name", nargs="?", default="", help="Tên bài lab")

    # 8. vm-capture-student
    p_cap_stud = subparsers.add_parser("vm-capture-student", help="Chụp ảnh màn hình terminal sinh viên")
    p_cap_stud.add_argument("output_png", help="Đường dẫn lưu tệp PNG trên Windows")

    # 9. vm-capture-container
    p_cap_cont = subparsers.add_parser("vm-capture-container", help="Chụp ảnh màn hình terminal container")
    p_cap_cont.add_argument("container_name", help="Tên container (VD: attacker, victim)")
    p_cap_cont.add_argument("output_png", help="Đường dẫn lưu tệp PNG trên Windows")

    # 10. vm-type
    p_type = subparsers.add_parser("vm-type", help="Gõ lệnh vào terminal container")
    p_type.add_argument("container_name", help="Tên container (VD: attacker)")
    p_type.add_argument("command_text", help="Câu lệnh cần thực thi")
    p_type.add_argument("--no-enter", action="store_true", help="Không nhấn phím Return")

    # 11. doc-format-typography
    p_typo = subparsers.add_parser("doc-format-typography", help="Chuẩn hóa Typography Google Docs (Times New Roman 13pt, Headings, Code chỉ căn giữa)")
    p_typo.add_argument("doc_id", help="Google Docs Document ID")
    p_typo.add_argument("tab_id", help="ID của Tab cần format")
    p_typo.add_argument("--no-code-detect", action="store_true", help="Không tự động nhận diện khối lệnh")

    # 12. vm-list-windows
    subparsers.add_parser("vm-list-windows", help="Liệt kê danh sách các cửa sổ đang hiển thị trên desktop máy ảo")

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(0)

    if args.command == "doc-setup":
        print(f"[*] Setting up document: {args.doc_id}")
        gdocs.setup_page_a4_margins(args.doc_id)
        tabs = gdocs.setup_standard_tabs(args.doc_id)
        gdocs.set_red_header(args.doc_id, tabs["tab1_id"], args.lab_name, args.subtext)
        print(f"[OK] Tabs info: {json.dumps(tabs, indent=2)}")

    elif args.command == "doc-style-tables":
        print(f"[*] Styling tables for doc {args.doc_id}, tab {args.tab_id}...")
        gdocs.style_tables_a4(args.doc_id, args.tab_id)
        print("[OK] Tables styled.")

    elif args.command == "doc-format-typography":
        print(f"[*] Formatting typography for doc {args.doc_id}, tab {args.tab_id}...")
        gdocs.format_tab_typography(args.doc_id, args.tab_id, auto_detect_code=not args.no_code_detect)
        print("[OK] Typography formatted.")

    elif args.command == "doc-add-comments":
        print(f"[*] Reading comments from: {args.comments_json}")
        with open(args.comments_json, "r", encoding="utf-8") as f:
            c_data = json.load(f)
        gdocs.post_all_comments(args.doc_id, args.tab_id, c_data, clear_old=not args.keep_old)
        print("[OK] Finished posting comments.")

    elif args.command == "drive-upload":
        url = gdocs.upload_image_to_drive(args.file_path, args.filename)
        print(f"[OK] Direct URL: {url}")

    elif args.command == "vm-start":
        vm.start_lab(args.lab_name, student_id=args.student_id, reset=not args.no_reset)
        print("[OK] Start lab finished.")

    elif args.command == "vm-stop":
        vm.stop_lab(args.lab_name)
        print("[OK] Stop lab completed.")

    elif args.command == "vm-checkwork":
        res = vm.run_checkwork(args.lab_name)
        print(f"[OK] Checkwork triggered. Result:\n{res}")

    elif args.command == "vm-capture-student":
        ok = vm.capture_student_terminal(args.output_png)
        print(f"[STATUS] Capture student terminal: {'Success' if ok else 'Failed'}")

    elif args.command == "vm-capture-container":
        ok = vm.capture_container_terminal(args.container_name, args.output_png)
        print(f"[STATUS] Capture container '{args.container_name}': {'Success' if ok else 'Failed'}")

    elif args.command == "vm-type":
        wid = vm.get_container_wid(args.container_name)
        if not wid:
            print(f"[ERROR] Window for container '{args.container_name}' not found!")
            sys.exit(1)
        vm.type_terminal(wid, args.command_text, enter=not args.no_enter)
        print(f"[OK] Sent command to {args.container_name}: {args.command_text}")

    elif args.command == "vm-list-windows":
        wins = vm.list_desktop_windows()
        print(f"[*] Found {len(wins)} windows on desktop:")
        for w in wins:
            print(f" - {w['title']}")


if __name__ == "__main__":
    main()
