# Cấu hình và ranh giới máy

## Đầu vào

`config/run.example.json` trong project là mẫu, không chứa cấu hình thật. Sao chép thành `run.local.json` và điền. Không đưa password/token/private key vào JSON; `password_env` chỉ chứa **tên biến**. Thông tin riêng của người dùng luôn nằm ngoài bundle chia sẻ.

| Trường | Ý nghĩa |
|---|---|
| schema_version | 1 |
| mode | review (bỏ qua DOCX hợp lệ đã có), retest (lượt mới), resume (tiếp tục checkpoint cùng bản) |
| steps | Các bước 1–10 được giao; mặc định kiểm thử 8,9,10 |
| source_html | File HTML đầy đủ đã hiệu chỉnh; đường dẫn local |
| imodule_url | URL được giao; không giới hạn registry/organization |
| workspace | Thư mục local chứa html/ và report/; retest chọn thư mục lượt mới |
| report_directory | Nơi bàn giao DOCX; mặc định workspace/report, có thể chọn nơi khác |
| student_id | Định danh nhập tại prompt; không tự thêm đuôi email |
| connection | host, port, username; password_env; known_hosts; display; tiêu đề terminal và đường dẫn VM nếu đã biết |
| cover | Thông tin bìa; thiếu có thể để trống |

Đường dẫn tương đối được tính từ **thư mục chứa file JSON**, không từ cwd. `known_hosts` là file fingerprint server đã xác minh, không phải khóa đăng nhập. Không coi IP/hostname của host SSH là IP đích trong topology bài học.

Mode và steps là chỉ dẫn agent, không phải công cụ tự khởi chạy quy trình. Launcher kiểm tra schema/đường dẫn/credential reference rồi chạy lệnh local được truyền; không phân tích HTML thành lệnh và không tự đánh dấu bước hoàn tất. Bước 1–7 có thể thêm tài liệu nguồn và thông tin registry trong yêu cầu; không ép có HTML đầu ra khi chưa soạn xong.

## Host điều phối và VM

- Máy thật chạy Claude Code, Python 3.10+, queue, renderer và lưu checkpoint. Python/SSH phải được xác minh sẵn; Paramiko là dependency tùy chọn cho mật khẩu, có thể dùng `uv run --with paramiko python` khi cần.
- VM host chạy Labtainer, desktop X11/công cụ tương thích, terminal sinh viên và các container. Chuẩn bị công cụ host trước khi bài chạy. VM không cần agent hoặc renderer DOCX.
- Xác minh host fingerprint trước lần đầu bằng terminal SSH tương tác; lưu known_hosts. Không tắt kiểm tra host key. Backend mật khẩu tắt private-key lookup và SSH agent.
- Nếu dùng PowerShell, chạy cú pháp PowerShell; không đưa `$env:` trực tiếp vào Git Bash. Launcher truyền cấu hình cho cùng subprocess nên không phụ thuộc biến shell từ lần tool trước (trừ password cần được kế thừa từ môi trường cha).

## Helper kế thừa

`run_config.py` đặt LABTAINER_SSH_TARGET/PORT/AUTH, LABTAINER_KNOWN_HOSTS, LABTAINER_DISPLAY, LABTAINER_STUDENT_WINDOW và LABTAINER_STUDENT_ID trong subprocess; password được đọc từ biến đã đặt. Không có IP hoặc mã sinh viên mặc định.

Các lệnh `python -m helpers.cli ...` trong step skill dùng module nằm tại `labtainer-spec/scripts/helpers`, không nằm ở root project. Để chạy được ở project bất kỳ, gọi qua launcher (PowerShell, `$skill` trỏ tới `.claude/skills/labtainer-spec`):

```powershell
uv run --with paramiko python "$skill/scripts/run_config.py" 'config/run.local.json' -- python -m helpers.cli vm-list-windows
```

Thay `vm-list-windows` bằng lệnh helper của bước đang làm. Với các lệnh SSH minh họa của bước build, dùng target/port và phương thức xác thực đã khai báo; `labtainer-build` không phải host mặc định được tạo sẵn. Không chạy nguyên placeholder hoặc giả định alias tồn tại. Khi đổi giữa build/test, dùng file config riêng cho từng host; launcher hỗ trợ kết nối bước 1, 5–9, bước 10 không cần SSH.

`<registry-namespace>` trong hướng dẫn là đích được giao để build/publish; `ptitdseclab` chỉ là ưu tiên khi chọn bài kiểm thử, không tự cấp quyền phát hành vào tổ chức đó. Tài khoản Google Docs và repository cũng phải được người dùng cung cấp theo phạm vi bước 1–7.

`helpers.cli vm-list-windows`, `vm-type`, `vm-capture-*`, `vm-checkwork`, `vm-stop` chỉ hỗ trợ thao tác: phải xem đúng cửa sổ và kết quả thật. Các helper VM còn quy ước đường dẫn `~/labtainer*`, user container `ubuntu` và X11; đối chiếu thực tế trước khi gọi. Không dùng `vm-start` để nghiệm thu vì legacy helper reset mặc định/gửi ID theo thời gian chờ; dùng thao tác từng prompt đã quan sát. SCP API trong password mode sử dụng SFTP; đường dẫn remote nên là tuyệt đối, SFTP không mở rộng `~`.

`helpers.gdocs` chỉ dùng khi được giao bước Google Docs, lấy GDOCS_TOKEN_PATH từ môi trường; không tự cho rằng API/token khả dụng. Helper có thao tác chia sẻ ảnh công khai, nên không gọi nhánh đó nếu chưa được giao công khai ảnh. Đây không phải dependency của kiểm thử DOCX.
