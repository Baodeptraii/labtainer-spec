---
name: labtainer-step-02-scenario-cybok
description: >-
  Thực hiện Bước 2 trong quy trình chuẩn hoá bài lab Labtainer: Báo cáo Thẻ 2 - Bảng tổng hợp lỗi, đánh giá AC, thông tin quản lý CYBOK 1.1, liên kết môn học PTIT và câu hỏi sinh viên.
  Sử dụng khi người dùng yêu cầu "làm bước 2", "hoàn thiện bước 2", hoặc trong cụm "bước 1-2".
---

> **Cấu hình dùng chung:** Đọc [cấu hình](../labtainer-spec/references/configuration.md) và [chuẩn/checklist](../labtainer-spec/references/standards.md). Các `<...>` là tham số cần lấy từ cấu hình/quan sát, không chạy nguyên mẫu. Scripts và assets ở skill `labtainer-spec`. `configuration.md` bên dưới chỉ tài liệu cấu hình này. Mật khẩu lấy từ biến môi trường `connection.password_env`, không lưu trong JSON.


# Bước 2: Báo cáo Thẻ 2 - Tổng Hợp Lỗi, Đánh Giá AC & Quản Lý CYBOK 1.1

Skill này hướng dẫn xây dựng trọn vẹn nội dung Thẻ 2 trong báo cáo Google Docs chuẩn hoá bài lab cho SecLab PTIT.

## Mục Tiêu & Phạm Vi Đầu Ra (Deliverables)

1. **Vị trí lưu trữ**: Đưa vào Tab 2 của Google Docs (`Báo cáo 2: Tổng hợp lỗi, minh chứng, đề xuất`).
2. **Quy chuẩn Header & Typography Google Docs**:
   - Tiêu đề đầu trang in chữ **ĐỎ nổi bật** (`<mã_lab_cũ>`, font đỏ đậm `#d93025`, in đậm, 20–22pt) và **CĂN GIỮA (CENTER)** kèm phụ đề *Báo cáo 2: Tổng hợp lỗi, minh chứng, đề xuất*.
   - **Font chữ toàn văn bản:** Sử dụng 100% font **Times New Roman**, cỡ chữ **13pt** cho toàn bộ nội dung và các cấp tiêu đề.
   - **Phân cấp tiêu đề rõ ràng (h1, h2, h3, h4 đều cỡ 13pt Times New Roman):**
     - **Heading 1 & Heading 2:** Cỡ **13pt**, **in đậm (bold)**.
     - **Heading 3 & Heading 4:** Cỡ **13pt**, **in đậm + in nghiêng (bold + italic)**.
   - **Định dạng khối lệnh / Code:** Chỉ căn giữa (**CENTER**), giữ nguyên màu chữ đen và kiểu chữ tiêu chuẩn Times New Roman 13pt (tuyệt đối không tô màu xanh lá, không in nghiêng).
3. **Quy chuẩn định dạng bảng**: Bảng tuyệt đối không tô màu nền cho ô (nền trong suốt 100%), sử dụng viền đen mảnh và chữ đen tiêu chuẩn.
4. **Bảng tổng hợp lỗi (4 cột)**:
   - Tổng hợp toàn bộ các lỗi đã phát hiện ở Thẻ 1.
   - Chiều rộng các cột phân bổ vừa khít A4: `32 pt` - `180 pt` - `180 pt` - `73 pt` (Tổng: $465\,\text{pt} \le 467.7\,\text{pt}$ khổ in A4).
   - Cột 4 sẵn sàng đối soát khi sinh HTML ở Bước 3.
5. **Mục đánh giá khả năng nộp bài và đạt AC**:
   - Nêu rõ hiện trạng bài lab gốc có đạt AC (Accepted) trên hệ thống SecLab PTIT hay bị WA (Wrong Answer) / Lỗi môi trường.
   - Phân tích các nguyên nhân kỹ thuật cốt lõi (sai logic kiểm tra, thiếu goal trong goals.config, script không tương thích, lỗi CRLF, permissions...).
6. **Bảng thông tin phục vụ quản lý bài lab & CYBOK 1.1**:
   - Định dạng 2 cột, chiều rộng phân bổ vừa khít A4: `140 pt` - `325 pt` (Tổng: $465\,\text{pt} \le 467.7\,\text{pt}$).
   - Gồm: Tên Lab gốc, Tên Lab mới chuẩn CYBOK, Mức độ khó, Thời lượng thực hành (30-60 phút), Phân loại CYBOK 1.1 (Lĩnh vực chính & phụ), Môn học phù hợp tại PTIT.
7. **Bổ sung tối thiểu 3 câu hỏi tư duy / phân tích cho sinh viên**:
   - Mỗi câu hỏi phải có dòng kẻ trả lời chuẩn: `Trả lời: ___________________________`.
8. **Quy định về Tab giải trình sửa code (Tab 3 - nếu có sửa code)**:
   - Nếu bài lab có sửa mã nguồn (sửa code web, script chấm điểm, container files), bổ sung thêm Tab 3: `Giải trình sửa đổi mã nguồn và cấu hình chấm điểm` nêu rõ những điểm đã sửa, lý do và ảnh chụp cấu hình.
9. **Lược bỏ văn bản dài khỏi Tab 2**:
   - **LƯỢC BỎ hoàn toàn 2 mục văn bản:** *"Đề xuất kịch bản doanh nghiệp thực tế"* và *"Sự liên kết bài lab với các môn học tại PTIT"* khỏi Báo cáo 2 (các nội dung này sẽ được thể hiện trực tiếp trong file Hướng dẫn thực hành HTML ở Bước 3 và Bảng quản lý CYBOK).
   - Tránh viết hoa tất cả chữ cái đầu ở các tiêu đề đầu mục; khi đã có từ tiếng Việt thì không mở ngoặc đơn chèn thêm tiếng Anh.

---

## Mẫu Trình Bày Chuẩn Cho Thẻ 2

```markdown
# THẺ 2: BÁO CÁO 2 - TỔNG HỢP LỖI, MINH CHỨNG, ĐỀ XUẤT

## I. BẢNG TỔNG HỢP LỖI BÀI LAB GỐC VÀ ĐỀ XUẤT CHỈNH SỬA

| STT | Tên lỗi và minh chứng | Đề xuất chỉnh sửa | Bản hướng dẫn mới sinh đã đáp ứng chưa? |
| :--- | :--- | :--- | :--- |
| 1 | Lỗi cú pháp lệnh tải & phụ thuộc kho cá nhân... | Sửa chữ thường imodule, chuyển repo về <registry-namespace>. | [ ] |
| 2 | LỖI NGHIÊM TRỌNG: Sai lệch địa chỉ IP... | Đồng bộ URL/IP về dải mạng thực tế. | [ ] |
| 3 | LỖI KỸ THUẬT: Mâu thuẫn cơ chế nộp cờ... | Bắt song song từ file kết quả và .bash_history. | [ ] |
| 4 | LỖI HỆ THỐNG: File goals.config rỗng 100%... | Thêm đầy đủ định nghĩa goals vào goals.config. | [ ] |

---

## II. ĐÁNH GIÁ HIỆN TRẠNG KHẢ NĂNG NỘP BÀI VÀ ĐẠT AC TRÊN HỆ THỐNG SECLAB

Bài lab gốc hiện tại: **KHÔNG ĐẠT AC (WA / ERROR)** trên hệ thống SecLab PTIT.
Nguyên nhân kỹ thuật chính:
1. Thiếu cấu hình định nghĩa mục tiêu kiểm tra trong `goals.config`.
2. Logic bắt cờ trong `results.config` bị gán cứng đường dẫn, không bao quát được trường hợp sinh viên thao tác lệnh hợp lệ.
3. Thiếu cơ chế kiểm tra kết hợp giữa file đầu ra và lịch sử lệnh `.bash_history`.

---

## III. PHÂN LOẠI THEO CYBOK 1.1 VÀ THÔNG TIN QUẢN LÝ BÀI LAB

| Thông tin quản lý | Chi tiết cấu hình bài lab |
| :--- | :--- |
| Tên Lab gốc | <mã_lab_cũ> |
| Tên Lab mới chuẩn hóa CYBOK | <mã_lab_mới> |
| Mức độ khó | Dễ / Trung bình / Khó |
| Thời lượng thực hành | 30 - 45 phút |
| Phân loại CYBOK 1.1 | Lĩnh vực chính: ...<br>Lĩnh vực phụ: ... |
| Môn học phù hợp tại PTIT | 1. ...<br>2. ... |

---

## IV. BỔ SUNG CÂU HỎI ĐÁNH GIÁ CHO SINH VIÊN

Câu hỏi 1: ...
Trả lời: __________________________________________________________________________________

Câu hỏi 2: ...
Trả lời: __________________________________________________________________________________

Câu hỏi 3: ...
Trả lời: __________________________________________________________________________________
```

---

## Tiêu Chí Kiểm Tra (Checklist Bước 2)
- [ ] Bảng tổng hợp lỗi có đủ 4 cột đúng kích thước A4 ($\le 467.7\,\text{pt}$), không tô màu nền ô.
- [ ] Có mục đánh giá hiện trạng bài lab có đạt AC hay không trên SecLab kèm nguyên nhân kỹ thuật cụ thể.
- [ ] Bảng thông tin quản lý & CYBOK 1.1 có đủ 2 cột, phân loại chính xác Lĩnh vực chính & phụ và môn học thực tế tại PTIT.
- [ ] Tối thiểu 3 câu hỏi sinh viên có dòng kẻ trả lời chuẩn: `Trả lời: ___________________________`.
- [ ] Đã lược bỏ hoàn toàn 2 mục văn bản dài (kịch bản doanh nghiệp và liên kết môn học) khỏi Báo cáo 2.
- [ ] Tiêu đề in đỏ đậm `#d93025`, không viết hoa toàn bộ chữ cái đầu các tiêu đề mục.

---

## Hướng Dẫn Tái Sử Dụng Helper Toolkit Cho Bước 2

Sau khi đưa nội dung Tab 2 vào Google Docs, Agent chạy ngay lệnh helper để định dạng bảng khổ A4 chuẩn và xóa màu nền ô trong suốt 100%:

```powershell
python -m helpers.cli doc-style-tables <doc_id> <tab2_id>
```
Hoặc trong Python:
```python
from helpers.gdocs import style_tables_a4
style_tables_a4(doc_id, tab2_id)
```
