"""Validate a local run configuration and launch a local command, without a shell."""
import argparse
import json
import os
from pathlib import Path
import re
import subprocess
import sys
from urllib.parse import urlsplit

REMOTE_STEPS = {1, 5, 6, 7, 8, 9}


def load_config(filename):
    path = Path(filename).expanduser().resolve()
    data = json.loads(path.read_text(encoding="utf-8-sig"))
    if data.get("schema_version") != 1:
        raise ValueError("schema_version must be 1")
    if data.get("mode") not in {"review", "retest", "resume"}:
        raise ValueError("mode must be review, retest or resume")
    steps = data.get("steps")
    if not isinstance(steps, list) or not steps or any(
        type(s) is not int or s not in range(1, 11) for s in steps
    ):
        raise ValueError("steps must contain step numbers 1..10")
    connection = data.get("connection", {})
    if any(key in connection for key in ("password", "token", "private_key")):
        raise ValueError("Do not store credentials in JSON; use password_env")
    if any(s in REMOTE_STEPS for s in steps):
        for field in ("host", "username", "password_env", "known_hosts"):
            value = connection.get(field)
            if not isinstance(value, str) or not value.strip() or value == "REPLACE_ME":
                raise ValueError(f"connection.{field} is required")
        port = connection.get("port", 22)
        if type(port) is not int or not 1 <= port <= 65535:
            raise ValueError("connection.port must be 1..65535")
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", connection["password_env"]):
            raise ValueError("password_env must be an environment variable name")
    if any(s in steps for s in (1, 6, 9)) and data.get("student_id", "") in ("", "REPLACE_ME"):
        raise ValueError("student_id is required for practical execution steps")
    for field in ("source_html", "workspace", "report_directory"):
        value = data.get(field)
        if not value or value == "REPLACE_ME":
            raise ValueError(f"{field} is required")
        resolved = Path(value).expanduser()
        data[field] = str((path.parent / resolved).resolve())
    if any(s in steps for s in (8, 9, 10)):
        html = Path(data["source_html"])
        if not html.is_file() or html.suffix.lower() not in {".html", ".htm"}:
            raise ValueError("source_html must be an existing HTML file")
    if any(s in steps for s in (8, 9)):
        url = urlsplit(data.get("imodule_url", ""))
        if not url.scheme or not url.netloc:
            raise ValueError("imodule_url must be an absolute URL")
        if url.username or url.password:
            raise ValueError("Do not embed credentials in imodule_url")
    if any(s in REMOTE_STEPS for s in steps):
        known = (path.parent / Path(connection["known_hosts"]).expanduser()).resolve()
        if not known.is_file():
            raise ValueError("known_hosts must be an existing verified host-key file")
        connection["known_hosts"] = str(known)
    data["_config_path"] = str(path)
    return data


def child_environment(data, parent=None):
    env = dict(os.environ if parent is None else parent)
    connection = data.get("connection", {})
    # Do not leak an old VM selection into a new run.
    for key in ("LABTAINER_SSH_TARGET", "LABTAINER_SSH_KEY", "LABTAINER_SSH_PASSWORD",
                "LABTAINER_SSH_PORT", "LABTAINER_SSH_AUTH", "LABTAINER_KNOWN_HOSTS",
                "LABTAINER_STUDENT_WINDOW", "LABTAINER_DISPLAY", "LABTAINER_STUDENT_ID"):
        env.pop(key, None)
    source = os.environ if parent is None else parent
    if any(s in REMOTE_STEPS for s in data["steps"]):
        password = source.get(connection["password_env"], "")
        if not password:
            raise ValueError("The configured password environment variable is not set")
        env.update({
            "LABTAINER_SSH_TARGET": f"{connection['username']}@{connection['host']}",
            "LABTAINER_SSH_PORT": str(connection.get("port", 22)),
            "LABTAINER_SSH_AUTH": "password",
            "LABTAINER_SSH_PASSWORD": password,
            "LABTAINER_KNOWN_HOSTS": connection["known_hosts"],
            "LABTAINER_DISPLAY": connection.get("display", ":0"),
            "LABTAINER_STUDENT_WINDOW": connection.get("student_window", ""),
        })
    env["LABTAINER_STUDENT_ID"] = data.get("student_id", "")
    env["LABTAINER_RUN_CONFIG"] = data["_config_path"]
    scripts = str(Path(__file__).resolve().parent)
    env["PYTHONPATH"] = scripts + (os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")
    return env


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("config")
    parser.add_argument("--check", action="store_true")
    # Split at -- explicitly so --check remains a launcher option.
    argv = sys.argv[1:]
    split = argv.index("--") if "--" in argv else len(argv)
    args = parser.parse_args(argv[:split])
    command = argv[split + 1:]
    try:
        data = load_config(args.config)
        env = child_environment(data)
        if args.check:
            print("Configuration valid; credentials available. No SSH connection attempted.")
            return 0
        if not command:
            parser.error("provide --check or -- <local command>")
        return subprocess.run(command, env=env, check=False).returncode
    except (ValueError, OSError) as exc:
        # Never print configuration or environment contents.
        print(f"Configuration/command error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
