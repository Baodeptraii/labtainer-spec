---
name: labtainer-step-06-rebuild-test
description: >-
  Thực hiện Bước 6 trong quy trình chuẩn hoá bài lab Labtainer: Chỉnh sửa logic cấu hình chấm điểm (results.config, goals.config), chạy lệnh rebuild bài lab, xử lý lỗi xung đột Docker (Troubleshooting) và kiểm thử thực tế đảm bảo checkwork đạt Y.
  Sử dụng khi người dùng yêu cầu "làm bước 6", "hoàn thiện bước 6", hoặc trong cụm "bước 5-6".
---

> **Cấu hình dùng chung:** Đọc [cấu hình](../labtainer-spec/references/configuration.md) và [chuẩn/checklist](../labtainer-spec/references/standards.md). Các `<...>` là tham số cần lấy từ cấu hình/quan sát, không chạy nguyên mẫu. Scripts và assets ở skill `labtainer-spec`. `configuration.md` bên dưới chỉ tài liệu cấu hình này. Mật khẩu lấy từ biến môi trường `connection.password_env`, không lưu trong JSON.


# Bước 6: Sửa Config Chấm Điểm, Rebuild Docker & Kiểm Thử Checkwork

Skill này hướng dẫn thực hiện chỉnh sửa cấu hình logic chấm điểm, rebuild image Docker của bài lab và kiểm thử kỹ thuật toàn diện.

## Mục Tiêu & Phạm Vi Đầu Ra (Deliverables)

1. **Hiệu chỉnh bộ chấm điểm (`instr_config`)**: Hoàn thiện `results.config`, `goals.config`, xử lý phân quyền `chmod +x` và định dạng `dos2unix` cho `pregrade.sh` hoặc các script kiểm tra.
2. **Rebuild thành công bài lab**: Thực thi lệnh `rebuild -f <tên_lab_mới>`.
3. **Xử lý xung đột Docker (nếu có)**: Dọn sạch container và image cũ bị khóa trước khi build lại.
4. **Kiểm thử bài lab thực tế**: Chạy `labtainer <tên_lab_mới>`, hoàn thành các nhiệm vụ và xác nhận lệnh `checkwork` trả về trạng thái `Y` cho 100% các tiêu chí.

---

## Các Thao Tác Kỹ Thuật Chi Tiết

> **Thực thi từ Windows Host qua SSH:**
> ```powershell
> ssh -n labtainer-build "<chuỗi_lệnh_bash>"
> ```


### 1. Hiệu chỉnh Cấu hình Chấm điểm (`instr_config`)

Di chuyển vào thư mục cấu hình chấm điểm của bài lab mới:
```bash
cd ~/labtainer/trunk/labs/<tên_lab_mới>/instr_config
ls -la
```

1. **Chuẩn hoá định dạng file script**:
   ```bash
   dos2unix pregrade.sh 2>/dev/null
   chmod +x pregrade.sh 2>/dev/null
   ```

2. **Chỉnh sửa `results.config` và `goals.config`**:
   - Mở `results.config` để bổ sung hoặc sửa đổi các biểu thức trích xuất kết quả (từ `stdout`, file log, hoặc trạng thái hệ thống).
   - Mở `goals.config` để định nghĩa các mục tiêu (task) chấm điểm hiển thị khi sinh viên chạy `checkwork`.
   *(Mẹo: Sử dụng đúng cú pháp quy định của Labtainer: `boolean`, `matchany`, `string_equal`, `CONTAINS`...)*

---

### 2. Thực hiện Rebuild Bài Lab

```bash
cd ~/labtainer/labtainer-student
rebuild -f <tên_lab_mới>
```

---

### 3. Xử lý Lỗi Trong Quá Trình Rebuild (Troubleshooting Docker)

Nếu quá trình rebuild gặp lỗi xung đột image/container cũ, thực hiện chuỗi lệnh dọn dẹp sau:

```bash
# 1. Xác định container thuộc đúng bài đang rebuild; chỉ dừng/xóa container đó:
docker ps -a
docker rm -f <container_id_cua_bai_duoc_giao>

# 2. Xem danh sách images để xác định image của bài lab cũ:
docker images

# 3. Xoá image của bài lab cũ:
docker rmi <tên_image_cũ_hoặc_image_id>

# 4. Không prune toàn host; chỉ xóa image đã xác minh thuộc bài nếu cần.
```

> **Lưu ý xử lý lỗi Container giữ Image:**
> Nếu khi xoá image gặp lỗi:
> `Error response from daemon: conflict: unable to delete <IMAGE_ID> (cannot be forced) - image is being used by running container <CONTAINER_ID>`
> $\rightarrow$ Thực hiện xoá ngay container đang chiếm giữ:
> ```bash
> docker rm -f <CONTAINER_ID>
> docker rmi <IMAGE_ID>
> ```
> Sau đó tiến hành chạy lại lệnh `rebuild -f <tên_lab_mới>`.

---

### 4. Kiểm Thử (Test) Thực Tế Bài Lab

Khởi động bài lab mới:
```bash
labtainer <tên_lab_mới>
```

Quy trình kiểm thử nghiêm ngặt:
1. Quan sát xem terminal có dừng đúng ở thông báo `Press <enter> to start the lab` không (nhờ file `read_first.txt` rỗng).
2. Nhấn Enter để vào các terminal container ảo.
3. Làm lần lượt từ đầu đến cuối tất cả các nhiệm vụ thực hành đã thiết kế.
4. Chạy lệnh chấm điểm trên terminal:
   ```bash
   checkwork
   ```
5. Đảm bảo toàn bộ danh sách các task hiển thị trạng thái `Y`. Nếu có task nào chưa đạt hoặc báo lỗi grader, quay lại kiểm tra `results.config` / `prestop` và lặp lại bước rebuild.
6. Kết thúc bài lab:
   ```bash
   stoplab <tên_lab_mới>
   ```

### 5. Thẻ Giải Trình Minh Chứng Khởi Động Bài Lab Mới
Sau khi build xong, chụp 1 ảnh màn hình quá trình khởi động bài lab trên máy trạm để đưa vào báo cáo làm minh chứng:
- Minh chứng không còn file tài liệu hướng dẫn docs cũ (hệ thống dừng đúng ở prompt `Press <enter> to start the lab`).
- Minh chứng image được kéo về từ đúng đường dẫn DockerHub của khoa (`<registry-namespace>/<tên_lab_mới>...`).

---

## Tiêu Chí Kiểm Tra (Checklist Bước 6)
- [ ] Script `pregrade.sh` đã được `dos2unix` và có quyền thực thi.
- [ ] Logic chấm điểm trong `results.config` hỗ trợ kiểm tra linh hoạt (bắt song song file và lịch sử `.bash_history`).
- [ ] Quá trình `rebuild -f` kết thúc thành công (Exit Code 0).
- [ ] Không còn xung đột docker container/image treo.
- [ ] Kết quả `checkwork` khi test thực tế đạt 100% `Y`.
- [ ] Đã có ảnh chụp quá trình khởi động bài lab xác nhận sạch thư mục docs và pull đúng repo `<registry-namespace>`.

---

## Hướng Dẫn Tái Sử Dụng Helper Toolkit Cho Bước 6

Sử dụng trực tiếp các lệnh CLI để kiểm thử bài lab trên máy ảo:

```powershell
# 1. Khởi động bài lab mới test thực tế:
python -m helpers.cli vm-start <tên_lab_mới> --student-id <student_id>

# 2. Chạy checkwork kiểm tra kết quả chấm điểm:
python -m helpers.cli vm-checkwork <tên_lab_mới>

# 3. Chụp ảnh minh chứng terminal sinh viên (checkwork 100% Y):
python -m helpers.cli vm-capture-student path/to/checkwork_pass.png

# 4. Dừng bài lab giải phóng tài nguyên:
python -m helpers.cli vm-stop
```

