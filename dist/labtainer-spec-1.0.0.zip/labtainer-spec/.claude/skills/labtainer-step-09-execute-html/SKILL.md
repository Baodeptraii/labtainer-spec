---
name: labtainer-step-09-execute-html
description: Tải imodule từ URL được giao và thực hành lại toàn bộ theo HTML đã hiệu chỉnh, kế thừa phần kiểm thử thực tế của bước 6. Ưu tiên ptitdseclab, chụp minh chứng mới từng bước, kiểm tra checkwork và thu .lab để bàn giao bước 10.
---

> **Cấu hình dùng chung:** Đọc [cấu hình](../labtainer-spec/references/configuration.md) và [chuẩn/checklist](../labtainer-spec/references/standards.md). Các `<...>` là tham số cần lấy từ cấu hình/quan sát, không chạy nguyên mẫu. Scripts và assets ở skill `labtainer-spec`. `configuration.md` bên dưới chỉ tài liệu cấu hình này. Mật khẩu lấy từ biến môi trường `connection.password_env`, không lưu trong JSON.


# Bước 9: Thực thi theo HTML mới

Claude Code điều phối trên Windows; tester là `<username>@<host>`, xác thực mật khẩu theo configuration.md, không dùng khóa riêng. VM chỉ chạy bài và thu minh chứng; dùng SFTP/SSH tải ảnh, log, .lab về máy thật ngay sau mỗi bước. Manifest, phân tích HTML và báo cáo được xử lý trên Windows, không yêu cầu cài agent/report renderer trên tester.

Đọc [rules](../labtainer-spec/references/review-rules.md), [workflow](../labtainer-spec/references/review-workflow.md), [schema](../labtainer-spec/templates/report-data.json) và [môi trường](../labtainer-spec/references/configuration.md). Kế thừa thứ tự đọc HTML → thực hiện → chụp ảnh → checkwork/.lab → kết luận; không sửa lab để làm đẹp kết quả.

## Điều kiện bắt đầu

- Đọc [skill bước 6](../labtainer-step-06-rebuild-test/SKILL.md), đặc biệt mục 4 (kiểm thử thực tế) và mục 5 (minh chứng khởi động). Kế thừa chuỗi khởi động → xử lý prompt → làm đủ nhiệm vụ → checkwork → stoplab. Các thao tác sửa grader, rebuild, xóa container/image hàng loạt của bước 6 không thuộc lượt kiểm thử bước 9.
- Nhận manifest và workspace bước 8; `environment.step8_status=READY`. Kiểm tra lại định danh VM, hash HTML, desktop và trạng thái phiên trước khi tiếp tục. Nếu đổi môi trường, kiểm tra lại kết nối/công cụ; không yêu cầu snapshot sạch.
- Đọc hết văn bản, sơ đồ, bảng, câu hỏi và điều kiện hoàn thành; liệt kê **toàn bộ** bước dự kiến trước khi chạy. Cú pháp mẫu không phải lệnh có thể chạy nguyên văn; lấy IP/role từ quan sát của lab, không dùng IP mẫu báo cáo.
- Thực hiện tuần tự từng bài. Không lấy ảnh/kết quả từ bước 6 hoặc bộ review cũ làm bằng chứng cho lượt hiện tại.

## Kiểm thử lại bản đã hiệu chỉnh

Đây là một lượt **thực hành lại từ đầu đến cuối theo hướng dẫn đã hiệu chỉnh**, kể cả bài đã được kiểm thử ở bước 6. Không chỉ đọc HTML, tải gói hoặc chạy lại checkwork để kết luận. Không yêu cầu VM/snapshot mới; ghi trạng thái sẵn có và thao tác thực hiện mới.

1. Nhận bản HTML kết quả sau hiệu chỉnh và URL imodule tương ứng (sau bước 7 hoặc được giao trực tiếp). Đọc lại toàn bộ HTML mới, không dùng danh sách lệnh của bản cũ theo trí nhớ. Ghi đường dẫn/hash HTML, URL gói, thời điểm tải và phiên bản/hash gói nếu lấy được. Với nguồn trực tiếp, không bắt buộc có hồ sơ bước 6.
2. Nếu có kết quả bước 6/lượt trước, đọc các lỗi và thay đổi đã hiệu chỉnh để lập mục cần kiểm tra lại, nhưng vẫn thực hiện **tất cả** nhiệm vụ của HTML mới. Ghi liên kết hồ sơ trước trong `environment.previous_run` nếu có; không sao chép trạng thái PASS, ảnh hoặc .lab cũ sang lượt mới.
3. Tạo manifest/run-id mới cho bản hiệu chỉnh. Nếu đã có báo cáo cùng tên, yêu cầu kiểm thử lại bản hiệu chỉnh là chỉ định chạy lại, không bỏ qua vì quy tắc SKIP thông thường. Bảo toàn báo cáo cũ; dùng workspace lượt riêng, ví dụ `workspaces/retests/<run-id>/` với `html/` và `report/`, hoặc thư mục lượt mới trong nơi người dùng đã chỉ định. Ghi nơi báo cáo cuối để bước 10 dùng đúng workspace. Nếu chỉ tiếp tục một lượt gián đoạn của cùng bản, dùng checkpoint của lượt đó.
4. Hoàn tất công cụ host trước thực hành. Nếu phiên cũ của chính bài đang chạy, lưu checkpoint/minh chứng rồi dừng đúng bài trước khi tải lại gói hiệu chỉnh; không đụng phiên không liên quan. Tải lại từ URL để kiểm thử gói được giao, không mặc định bản đã cài là bản đã sửa. Không sửa grader/build ngay trên tester để thay thế gói phát hành.

Trên **terminal sinh viên của host Labtainer**, thực hiện từng lệnh dưới đây sau khi thay giá trị từ HTML/yêu cầu. Đây là trình tự có quan sát giữa các lệnh, không phải script chạy liền:

```bash
imodule <URL_imodule_bản_đã_hiệu_chỉnh>
labtainer <tên_lab_trong_hướng_dẫn_đã_hiệu_chỉnh>
# Quan sát prompt; nhập <student_id> khi được hỏi email/mã sinh viên.
# Nếu xuất hiện Press <enter> to start the lab, nhấn Enter rồi quan sát terminal.
# Thực hiện lại toàn bộ nhiệm vụ HTML trên đúng terminal/container và chụp từng bước.
checkwork
# Chụp đủ bảng goals, đối chiếu từng kết quả với nhiệm vụ vừa thực hiện.
stoplab <tên_lab_trong_hướng_dẫn_đã_hiệu_chỉnh>
# Thu .lab thật của lượt này và chuyển về Windows cùng ảnh/log.
```

Quan sát tải/khởi động và ghi gói/image thực tế, lỗi download/pull hoặc prompt khác dự kiến. Không bắt buộc prompt read_first rỗng hay registry <registry-namespace> như ví dụ bước 6; dùng đúng hành vi và nguồn của bài được giao. Nếu không xác minh được bản hiệu chỉnh đã được nạp, ghi giới hạn và không kết luận đã kiểm thử bản mới.

## Tải, khởi động và thực hành

1. Trên terminal sinh viên của VM test, chạy **đúng URL imodule người dùng giao (hoặc link trong HTML nếu không có chỉ định khác) và tên lab đã xác minh**. Thu log/ảnh tải và khởi động, ghi URL, phiên bản/imodule hash nếu lấy được, image tag/digest thực tế. Chấp nhận môi trường/image đã có; ghi rõ bản đang dùng và dữ liệu tồn tại trước lượt. Không dùng kết quả/ảnh cũ thay cho thực hành mới. Nếu tải không được, phân biệt lỗi link/image với lỗi mạng môi trường.
2. Khởi động không reset mặc định. Quan sát prompt email/mã sinh viên rồi nhập đúng `<student_id>`; không gửi ID sau một khoảng chờ cố định. Ghi terminal/role do lab sinh ra, ảnh xác nhận đúng gói/image thực tế; không coi tài liệu hoặc dữ liệu cũ là điều kiện chặn.
3. Chạy nhiệm vụ đúng thứ tự và đúng cửa sổ/container bằng công cụ desktop qua SSH. Ưu tiên terminal/tab do Labtainer tạo; chỉ mở thêm khi HTML thực sự yêu cầu. Listener/tcpdump phải sẵn sàng trước tác nhân tạo lưu lượng. Không dùng terminal dựng riêng để làm minh chứng. GUI phải chụp cửa sổ GUI có kết quả, không thay bằng curl hay ảnh lệnh mở ứng dụng.
4. Sau **mỗi bước**, ghi `started_at`, `finished_at`, `action`, `expected`, `actual`, `executed`, `status`, `source`, `terminal`; chụp PNG mới, tải về `run-dir/evidence/`, mở xem rõ chữ/đúng role rồi lưu manifest. Evidence dùng đường dẫn tương đối, `caption`, `captured_at`, `origin=live-capture`. Log là bổ sung, không thay ảnh. Ảnh thử bước 8 không tính là minh chứng nhiệm vụ.
5. Các helper VM cũ chỉ hỗ trợ gửi lệnh; giá trị trả về hoặc đã chờ đủ giây không chứng minh thao tác thành công. Đối chiếu cửa sổ và kết quả thật. Không dùng `start_lab` tự gửi ID/reset cho lượt nghiệm thu; điều khiển từng prompt đã quan sát.

## Kết thúc và đánh giá

1. Chạy `checkwork` trên terminal sinh viên, chụp toàn bộ bảng goals; đối chiếu từng goal với kết quả học tập, kể cả dấu hiệu goal đạt trước khi thực hiện. `checkwork`/`stoplab` thuộc kiểm định nội bộ, không thêm chúng thành nhiệm vụ trong HTML.
2. Chạy `stoplab` đúng phiên, thu file `.lab` **thật của lượt này**, tải về run-dir và điền `assessment.lab_file`. Ghi ảnh/log dừng, xác nhận container đã dừng; nếu dọn dẹp lỗi, ghi rõ trạng thái còn tồn tại, không chuyển bài khác một cách mù quáng.
3. PASS cần mọi bước bắt buộc đạt với ảnh hợp lệ, checkwork đủ Y và `.lab` thật. FAIL khi có sai lệch đã thực hiện và chứng minh bằng ảnh; mô tả các bước phụ thuộc NOT_RUN. BLOCKED khi thiếu điều kiện/kết quả chưa đủ để kết luận. N/A chỉ khi có lý do, chưa chạy không phải N/A. Lỗi chủ đích trong bài có thể là kết quả đúng. Không có checkwork thì giữ BLOCKED đến khi tiêu chí thay thế được xác nhận và công cụ báo cáo được điều chỉnh phù hợp; renderer kế thừa hiện yêu cầu full Y cho PASS.
4. Không sửa HTML, grader, history hay artifact để ép Y; ghi phát hiện, nguyên nhân có căn cứ và đề xuất trả về bước 3/5/6/7. Lượt kiểm thử bản sửa phải có hồ sơ mới. Không tự nộp SecLab; full Y không tương đương AC.

Đầu ra: manifest hoàn chỉnh, PNG đã xem, log, `.lab`, câu trả lời dựa trên thực nghiệm và giới hạn. Dù BLOCKED vẫn lưu checkpoint. Bước 10 sinh báo cáo; bước 9 không tự tạo báo cáo cuối nếu chỉ được giao thực thi.

## Checklist lượt kiểm thử lại

- [ ] Đã đọc phần kiểm thử của bước 6 và toàn bộ HTML sau hiệu chỉnh.
- [ ] Đã tải imodule đúng URL bản được giao, lưu log/ảnh và thông tin nhận diện bản thực tế.
- [ ] Đã tạo hồ sơ lượt mới, giữ báo cáo/bằng chứng trước đó; không SKIP yêu cầu kiểm thử lại chỉ vì có DOCX cũ.
- [ ] Đã khởi động, xử lý prompt đúng thực tế và nhập <student_id> khi được yêu cầu.
- [ ] Đã làm lại từng bước của mọi nhiệm vụ, chụp và xem PNG mới sau mỗi bước; ghi rõ bước lỗi/chưa chạy.
- [ ] Đã đối chiếu các điểm hiệu chỉnh với kết quả mới, chụp checkwork và ghi đúng PASS/FAIL/BLOCKED; không sửa để ép Y.
- [ ] Đã stoplab đúng bài, thu .lab thật và bàn giao manifest/ảnh/log cho bước 10 sinh DOCX theo mẫu học viện trên Windows.

## Giới hạn cài đặt trong lượt thực hành

Công cụ kết nối/chụp/truyền file phải được chuẩn bị trên host ở bước 8. Sau khi bài đã khởi động, không cài thêm công cụ trên host hoặc container, kể cả để khắc phục thiếu dependency. Nếu HTML yêu cầu cài gói, ghi rõ bước đó chưa thực hiện do giới hạn này; không âm thầm bỏ qua rồi kết luận PASS. Lưu bằng chứng/checkpoint và tiếp tục các bước không phụ thuộc nếu có thể. Thực hiện tuần tự từng bước, chụp/xem ảnh thật sau mỗi bước, không lấy kết quả sẵn có làm bằng chứng đã thực hiện.
