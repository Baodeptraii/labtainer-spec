"""
Module: helpers.vm
Điều khiển máy ảo Labtainer qua SSH và xdotool (X11 DISPLAY=:0).
Tuân thủ nghiêm ngặt quy tắc:
- 100% thao tác trên terminal do bài lab sinh ra hoặc terminal máy trạm sinh viên.
- Tuyệt đối không tự tạo terminal ngoài (xterm, gnome-terminal).
- Hỗ trợ chụp ảnh màn hình qua import và scp về local.
- Hỗ trợ chạy checkwork và stoplab dọn dẹp môi trường.
"""

import os
import sys
import time
import subprocess
from contextlib import contextmanager
from typing import Optional, List, Dict, Tuple

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

SSH_KEY_DEFAULT = os.environ.get("LABTAINER_SSH_KEY", "")
SSH_TARGET_DEFAULT = os.environ.get("LABTAINER_SSH_TARGET", "")
DISPLAY_DEFAULT = os.environ.get("LABTAINER_DISPLAY", ":0")


class VMClient:
    def __init__(self, target: str = SSH_TARGET_DEFAULT, key_path: str = SSH_KEY_DEFAULT, display: str = DISPLAY_DEFAULT):
        self.target = target
        self.key_path = key_path
        self.display = display

    def _connection(self, program: str) -> List[str]:
        # SSH aliases supply User/Port/IdentityFile from the user's SSH config.
        args = [program, "-o", "BatchMode=yes", "-o", "ConnectTimeout=10"]
        if self.key_path:
            args += ["-i", self.key_path]
        return args

    @contextmanager
    def _password_client(self, timeout: int = 30):
        """Password SSH for the tester; no agent or private-key lookup."""
        try:
            import paramiko
        except ImportError as exc:
            raise RuntimeError(
                "Password SSH requires paramiko; run with uv run --with paramiko python"
            ) from exc
        if "@" not in self.target:
            raise ValueError("Password mode requires user@host, not an SSH alias")
        user, host = self.target.rsplit("@", 1)
        client = paramiko.SSHClient()
        known_hosts = os.environ.get("LABTAINER_KNOWN_HOSTS", "")
        if known_hosts:
            client.load_host_keys(known_hosts)
        else:
            client.load_system_host_keys()
        client.set_missing_host_key_policy(paramiko.RejectPolicy())
        try:
            client.connect(
                hostname=host, username=user,
                port=int(os.environ.get("LABTAINER_SSH_PORT", "22")),
                password=os.environ["LABTAINER_SSH_PASSWORD"],
                look_for_keys=False, allow_agent=False,
                timeout=min(timeout, 30), auth_timeout=30, banner_timeout=30,
            )
            yield client
        finally:
            client.close()

    def run_ssh(self, cmd: str, timeout: int = 300) -> str:
        """Thực thi câu lệnh trên máy ảo qua SSH."""
        if os.environ.get("LABTAINER_SSH_AUTH") == "password":
            with self._password_client(timeout) as client:
                _, stdout, _ = client.exec_command(cmd, timeout=timeout)
                stdout.channel.set_combine_stderr(True)
                output = stdout.read().decode("utf-8", errors="replace")
                code = stdout.channel.recv_exit_status()
                if code:
                    raise RuntimeError(f"Remote command failed ({code}): {output}")
                return output
        proc = subprocess.Popen(
            self._connection("ssh") + [self.target, cmd],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT
        )
        try:
            out, _ = proc.communicate(timeout=timeout)
            return out.decode("utf-8", errors="replace")
        except subprocess.TimeoutExpired:
            proc.kill()
            return f"[ERROR] Command timed out after {timeout} seconds: {cmd}"

    def scp_to_vm(self, local_path: str, remote_path: str) -> bool:
        """Sao chép tệp từ Windows host lên máy ảo."""
        if os.environ.get("LABTAINER_SSH_AUTH") == "password":
            with self._password_client() as client, client.open_sftp() as sftp:
                sftp.put(local_path, remote_path)
            return True
        res = subprocess.run(
            self._connection("scp") + [local_path, f"{self.target}:{remote_path}"],
            capture_output=True, text=True, errors="replace"
        )
        return res.returncode == 0

    def scp_from_vm(self, remote_path: str, local_path: str) -> bool:
        """Kéo tệp từ máy ảo về Windows host."""
        os.makedirs(os.path.dirname(os.path.abspath(local_path)), exist_ok=True)
        if os.environ.get("LABTAINER_SSH_AUTH") == "password":
            with self._password_client() as client, client.open_sftp() as sftp:
                sftp.get(remote_path, local_path)
            return True
        res = subprocess.run(
            self._connection("scp") + [f"{self.target}:{remote_path}", local_path],
            capture_output=True, text=True, errors="replace"
        )
        return res.returncode == 0

    def get_student_terminal_wid(self) -> str:
        """Lấy Window ID của terminal máy trạm sinh viên (student@LabtainerVMware)."""
        pattern = os.environ.get("LABTAINER_STUDENT_WINDOW", "")
        if not pattern:
            raise ValueError("Set LABTAINER_STUDENT_WINDOW from the observed VM terminal title")
        safe_pattern = pattern.replace("'", "'\"'\"'")
        cmd = f"DISPLAY={self.display} xdotool search --name '{safe_pattern}' | head -n 1"
        wid = self.run_ssh(cmd).strip()
        return wid

    def get_container_wid(self, container_name: str) -> str:
        """Lấy Window ID của terminal container (ubuntu@<container_name>: ~)."""
        cmd = f"DISPLAY={self.display} xdotool search --name 'ubuntu@{container_name}: ~' | head -n 1"
        wid = self.run_ssh(cmd).strip()
        return wid

    def get_window_wid(self, name_pattern: str) -> str:
        """Tìm Window ID theo mẫu tên cửa sổ."""
        cmd = f"DISPLAY={self.display} xdotool search --name '{name_pattern}' | head -n 1"
        wid = self.run_ssh(cmd).strip()
        return wid

    def list_desktop_windows(self) -> List[Dict[str, str]]:
        """Liệt kê toàn bộ cửa sổ đang hiển thị trên desktop máy ảo."""
        cmd = f"DISPLAY={self.display} xdotool search --onlyvisible '' getwindowname %@ 2>/dev/null"
        output = self.run_ssh(cmd)
        windows = []
        for line in output.splitlines():
            line = line.strip()
            if line:
                windows.append({"title": line})
        return windows

    def type_terminal(self, wid: str, command: str, enter: bool = True, sleep_after: float = 1.0) -> None:
        """Kích hoạt cửa sổ và nhập câu lệnh trực tiếp qua xdotool."""
        if not wid:
            raise ValueError("Window ID (wid) is empty!")
        # Thoát các ký tự nhạy cảm trong câu lệnh
        safe_cmd = command.replace("'", "'\"'\"'")
        script = f"DISPLAY={self.display} xdotool windowactivate --sync {wid} && DISPLAY={self.display} xdotool type '{safe_cmd}'"
        if enter:
            script += f" && DISPLAY={self.display} xdotool key Return"
        self.run_ssh(script)
        if sleep_after > 0:
            time.sleep(sleep_after)

    def switch_terminal_tab(self, wid: str, tab_num: int = 1, sleep_after: float = 0.5) -> None:
        """Chuyển đổi tab ảo trên terminal container bằng tổ hợp Alt+<tab_num>."""
        script = f"DISPLAY={self.display} xdotool windowactivate --sync {wid} && DISPLAY={self.display} xdotool key alt+{tab_num}"
        self.run_ssh(script)
        if sleep_after > 0:
            time.sleep(sleep_after)

    def capture_window(self, wid: str, local_output_path: str, remote_tmp_path: str = "/tmp/vm_capture.png") -> bool:
        """Chụp ảnh màn hình cửa sổ theo WID bằng import và tải về local."""
        if not wid:
            print(f"[VMClient] Cannot capture: invalid WID '{wid}'")
            return False
        # Kích hoạt trước khi chụp
        self.run_ssh(f"DISPLAY={self.display} xdotool windowactivate --sync {wid}")
        time.sleep(0.5)
        # Chụp ảnh
        cmd_cap = f"DISPLAY={self.display} import -window {wid} {remote_tmp_path}"
        self.run_ssh(cmd_cap)
        # Kéo về local
        ok = self.scp_from_vm(remote_tmp_path, local_output_path)
        if ok:
            print(f"[VMClient] Captured WID {wid} -> {local_output_path}")
        else:
            print(f"[VMClient] Failed to scp capture from {remote_tmp_path} to {local_output_path}")
        return ok

    def capture_student_terminal(self, local_output_path: str) -> bool:
        """Chụp ảnh terminal của máy trạm sinh viên."""
        wid = self.get_student_terminal_wid()
        if not wid:
            print("[VMClient] Student terminal window not found!")
            return False
        return self.capture_window(wid, local_output_path)

    def capture_container_terminal(self, container_name: str, local_output_path: str) -> bool:
        """Chụp ảnh terminal của container bài lab."""
        wid = self.get_container_wid(container_name)
        if not wid:
            print(f"[VMClient] Container terminal 'ubuntu@{container_name}: ~' not found!")
            return False
        return self.capture_window(wid, local_output_path)

    def start_lab(self, lab_name: str, student_id: str = "", reset: bool = True, wait_sec: int = 25) -> bool:
        """
        Khởi động bài lab trên terminal sinh viên.
        Tự động trả lời prompt nhập email bằng mã sinh viên.
        """
        student_id = student_id or os.environ.get("LABTAINER_STUDENT_ID", "")
        if not student_id:
            raise ValueError("Set LABTAINER_STUDENT_ID or pass student_id explicitly")
        swid = self.get_student_terminal_wid()
        if not swid:
            print("[VMClient] Student terminal window not found. Cannot launch lab.")
            return False

        flag = "-r " if reset else ""
        print(f"[VMClient] Starting labtainer {flag}{lab_name}...")
        self.type_terminal(swid, f"labtainer {flag}{lab_name}")

        time.sleep(12)
        # Tự động nhập email / mã sinh viên nếu có prompt
        print(f"[VMClient] Sending student ID '{student_id}' in case email prompt appears...")
        self.type_terminal(swid, student_id)

        print(f"[VMClient] Waiting {wait_sec} seconds for containers and GUI to spin up...")
        time.sleep(wait_sec)
        return True

    def run_checkwork(self, lab_name: str = "", wait_sec: int = 10) -> str:
        """
        Thực thi câu lệnh checkwork trên terminal máy trạm sinh viên.
        """
        swid = self.get_student_terminal_wid()
        if not swid:
            return "[VMClient] Error: Student terminal window not found."

        cmd = f"checkwork {lab_name}".strip()
        print(f"[VMClient] Executing '{cmd}' on student terminal...")
        self.type_terminal(swid, cmd)
        time.sleep(wait_sec)

        # Đọc nội dung file kết quả checkwork gần nhất nếu có
        res = self.run_ssh(f"cat ~/labtainer_student/{lab_name}/.grades.txt 2>/dev/null || true")
        return res

    def stop_lab(self, lab_name: str = "", wait_sec: int = 10) -> None:
        """
        Dừng bài lab trên terminal sinh viên và giải phóng tài nguyên.
        """
        swid = self.get_student_terminal_wid()
        if not swid:
            print("[VMClient] Student terminal not found, running stoplab directly over SSH...")
            self.run_ssh(f"cd ~/labtainer/labtainer-student && stoplab {lab_name}")
            return

        cmd = f"stoplab {lab_name}".strip()
        print(f"[VMClient] Stopping lab with '{cmd}'...")
        self.type_terminal(swid, cmd)
        time.sleep(wait_sec)

    def ensure_firefox_no_sandbox(self, url: Optional[str] = None) -> None:
        """Mở Firefox từ container hoặc VM không bị lỗi sandbox."""
        cmd = "MOZ_DISABLE_CONTENT_SANDBOX=1 firefox"
        if url:
            cmd += f" {url}"
        cmd += " &"
        self.run_ssh(f"DISPLAY={self.display} {cmd}")


# Singleton instance tiện dụng
vm = VMClient()

# Export trực tiếp các hàm tiện ích
run_ssh = vm.run_ssh
scp_to_vm = vm.scp_to_vm
scp_from_vm = vm.scp_from_vm
get_student_terminal_wid = vm.get_student_terminal_wid
get_container_wid = vm.get_container_wid
get_window_wid = vm.get_window_wid
list_desktop_windows = vm.list_desktop_windows
type_terminal = vm.type_terminal
switch_terminal_tab = vm.switch_terminal_tab
capture_window = vm.capture_window
capture_student_terminal = vm.capture_student_terminal
capture_container_terminal = vm.capture_container_terminal
start_lab = vm.start_lab
run_checkwork = vm.run_checkwork
stop_lab = vm.stop_lab
ensure_firefox_no_sandbox = vm.ensure_firefox_no_sandbox
