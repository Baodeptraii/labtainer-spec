"""Offline fixtures only: no Labtainer commands or real screenshots are produced."""
import copy
import hashlib
import json
from pathlib import Path
import struct
import sys
import tempfile
import unittest
import xml.etree.ElementTree as E
from zipfile import ZipFile
import zlib

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"scripts"))
import render_report as renderer
import workspace_queue as queue

def png(width=800,height=240):
    def chunk(kind, data):
        return struct.pack(">I",len(data))+kind+data+struct.pack(">I",zlib.crc32(kind+data)&0xffffffff)
    rows=b"".join(b"\0"+bytes([224,235,245])*width for _ in range(height))
    return b"\x89PNG\r\n\x1a\n"+chunk(b"IHDR",struct.pack(">IIBBBBB",width,height,8,2,0,0,0))+chunk(b"IDAT",zlib.compress(rows))+chunk(b"IEND",b"")

class ReviewTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(dir=ROOT/"tests")
        self.workspace=Path(self.tmp.name)
        (self.workspace/"html").mkdir()
        self.source=self.workspace/"html"/"routing.html"
        self.source.write_text("<html>Test fixture only</html>",encoding="utf-8")
        self.job=queue.prepare(self.workspace,"html/routing.html")
        self.manifest=Path(self.job["manifest"])
        self.run=self.manifest.parent
        self.data=json.loads(self.manifest.read_text(encoding="utf-8"))
        (self.run/"evidence"/"fixture.png").write_bytes(png())

    def tearDown(self):
        self.tmp.cleanup()

    def save(self):
        self.manifest.write_text(json.dumps(self.data,ensure_ascii=False),encoding="utf-8")

    def complete_fail(self):
        self.data["status"]="FAIL"
        self.data["summary"]="TEST ONLY: a simulated failure for renderer validation."
        self.data["steps"][0].update(status="FAIL",executed=True,started_at="2026-01-01T00:00:00Z",
            finished_at="2026-01-01T00:01:00Z",actual="Synthetic test failure",
            evidence=[{"file":"evidence/fixture.png","caption":"TEST FIXTURE - not lab evidence",
                       "captured_at":"2026-01-01T00:00:30Z","origin":"live-capture"}])
        self.save()

    def test_scan_initial_pending(self):
        self.assertEqual(queue.scan(self.workspace)[0]["status"],"PENDING")

    def test_publish_then_scan_skips_failed_report(self):
        self.complete_fail()
        out=renderer.publish(self.manifest,self.workspace)
        self.assertEqual(out,self.workspace/"report"/"routing.docx")
        self.assertTrue(queue.valid_docx(out))
        self.assertEqual(queue.scan(self.workspace)[0]["status"],"SKIP")

    def test_changed_html_with_existing_report_still_skipped(self):
        self.complete_fail();renderer.publish(self.manifest,self.workspace)
        self.source.write_text("Changed HTML",encoding="utf-8")
        self.assertEqual(queue.scan(self.workspace)[0]["status"],"SKIP")

    def test_new_html_remains_pending_after_first_report(self):
        self.complete_fail();renderer.publish(self.manifest,self.workspace)
        (self.workspace/"html"/"new.html").write_text("<html>new</html>")
        rows={j["source_html"]:j["status"] for j in queue.scan(self.workspace)}
        self.assertEqual(rows,{"html/new.html":"PENDING","html/routing.html":"SKIP"})

    def test_no_overwrite_existing(self):
        self.complete_fail();out=renderer.publish(self.manifest,self.workspace)
        before=out.read_bytes()
        with self.assertRaises(FileExistsError):renderer.publish(self.manifest,self.workspace)
        self.assertEqual(out.read_bytes(),before)

    def test_incomplete_draft_does_not_mark_done(self):
        with self.assertRaisesRegex(ValueError,"draft"):renderer.publish(self.manifest,self.workspace)
        out=renderer.publish(self.manifest,self.workspace,draft=True)
        self.assertEqual(out,self.run/"draft.docx")
        self.assertEqual(queue.scan(self.workspace)[0]["status"],"PENDING")

    def test_changed_source_rejected_before_publication(self):
        self.complete_fail();self.source.write_text("different")
        with self.assertRaisesRegex(ValueError,"changed"):renderer.publish(self.manifest,self.workspace)

    def test_invalid_existing_report_is_conflict(self):
        out=self.workspace/"report"/"routing.docx";out.write_bytes(b"not a docx")
        self.assertEqual(queue.scan(self.workspace)[0]["status"],"CONFLICT")
        with self.assertRaises(FileExistsError):queue.prepare(self.workspace,"html/routing.html")

    def test_collision_rejected(self):
        self.source.with_suffix(".htm").write_text("duplicate")
        with self.assertRaisesRegex(ValueError,"collision"):queue.scan(self.workspace)

    def test_nested_html_maps_to_nested_report(self):
        nested=self.workspace/"html"/"chapter";nested.mkdir()
        (nested/"routing.HTML").write_text("nested")
        rows=queue.scan(self.workspace)
        self.assertIn("report/chapter/routing.docx",[x["report"] for x in rows])

    def test_escape_workspace_rejected(self):
        with self.assertRaises(ValueError):queue.paths(self.workspace,"../escape.html")
        self.complete_fail();self.data["steps"][0]["evidence"][0]["file"]="../../outside.png"
        with self.assertRaises(ValueError):renderer.build(self.data,self.run,ROOT/"assets/report-template.docx")

    def test_pass_requires_execution_and_screenshot(self):
        self.data["steps"][0]["status"]="PASS"
        with self.assertRaisesRegex(ValueError,"execution"):renderer.validate(self.data,self.run)
        self.data["steps"][0].update(executed=True,started_at="x",finished_at="y")
        with self.assertRaisesRegex(ValueError,"screenshot"):renderer.validate(self.data,self.run)

    def test_pass_requires_actual_lab_and_goal_evidence(self):
        self.complete_fail()
        self.data["steps"][0]["status"]="PASS";self.data["status"]="PASS"
        self.data["assessment"].update(status="PASS",full_y=True)
        with self.assertRaisesRegex(ValueError,".lab"):renderer.validate(self.data,self.run)

    def test_template_image_origin_rejected(self):
        self.complete_fail()
        self.data["steps"][0]["evidence"][0]["origin"]="template-pdf"
        with self.assertRaisesRegex(ValueError,"live-capture"):renderer.validate(self.data,self.run)

    def test_word_contains_unicode_images_and_no_old_template_examples(self):
        self.complete_fail()
        self.data["lab"]="Bài định tuyến — kiểm thử"
        self.data["steps"][0]["action"]='echo "<literal & text>"'
        self.save();out=renderer.publish(self.manifest,self.workspace)
        with ZipFile(out) as z:
            root=E.fromstring(z.read("word/document.xml"))
            text="".join(root.itertext())
            self.assertIn("Bài định tuyến — kiểm thử",text)
            self.assertIn("<literal & text>",text)
            for stale in ("Cài đặt Windows","Moodle","basic CPU","{{LAB}}","{{REPORT_BODY}}"):
                self.assertNotIn(stale,text)
            self.assertEqual(z.read("word/media/evidence-1.png"),png())
            for n in z.namelist():
                if n.endswith((".xml",".rels")): E.fromstring(z.read(n))
            self.assertNotIn("customXml/item1.xml",z.namelist())
            self.assertIn("Agent review",text)

if __name__=="__main__":
    unittest.main()

