---
name: labtainer-spec
description: >-
  Điều phối toàn bộ quy trình chuẩn hoá và build lại bài thực hành Labtainer cho hệ thống SecLab PTIT.
  Sử dụng khi người dùng cung cấp (html đề cũ, template html mới, source code bài cũ) và yêu cầu thực hiện theo cụm bước cụ thể (ví dụ: "hoàn thiện bước 1-2", "làm bước 3-4", "thực hiện bước 5-6", "bước 7"), đảm bảo chỉ làm đúng phạm vi bước được yêu cầu (Scope Isolation) mà không làm tràn sang các bước khác.
---

# Quy trình Điều phối Chuẩn hoá và Build lại Bài Lab SecLab PTIT

Đọc [chuẩn/checklist](references/standards.md) và [cấu hình](references/configuration.md). Nhận yêu cầu từ `$ARGUMENTS` hoặc hội thoại, chỉ đọc skill bước được giao.

Skill này quản lý vòng đời 10 bước chuẩn hoá, build và kiểm thử thực tế bài lab. Bước 8–10 chỉ cần HTML đã phát hành và môi trường/hồ sơ kiểm thử, không yêu cầu lại source cũ. Bước 1–7 sử dụng **3 thành phần đầu vào**:
1. `html đề cũ`: Tài liệu hướng dẫn bài lab cũ.
2. `template html mới`: Mẫu HTML chuẩn giao diện của SecLab PTIT.
3. `source code bài cũ`: Mã nguồn ban đầu của bài lab (chứa `config`, `dockerfiles`, `instr_config`...).

> [!IMPORTANT]
> **Tái sử dụng Helper Toolkit (`helpers/`):**
> Để tăng tốc và tránh viết lại các đoạn script cồng kềnh (SSH xdotool, chụp ảnh, setup Google Docs, định dạng A4, upload ảnh, gắn native comment neo kix), Agent bắt buộc sử dụng thư viện module `helpers` (`from helpers import vm, gdocs, lab_parser`) hoặc gọi trực tiếp CLI `python -m helpers.cli <lệnh>`. Chi tiết xem tại [.claude/HELPERS.md](references/helpers.md).

---

## Nguyên tắc Vận hành theo Yêu cầu người dùng (Scope Isolation)

Khi người dùng ra lệnh theo các cụm bước:
-- **"Hoàn thiện bước 1-2" (hoặc "bước 1", "bước 2")**:
  - *Đầu vào sử dụng:* `html đề cũ` + `source code bài cũ` + video thực tế (nếu có).
  - *Kích hoạt:* `labtainer-step-01-audit` và `labtainer-step-02-scenario-cybok`.
  - *Đầu ra duy nhất:*
    - Tab 1: Nội dung bài gốc kèm Native Comments neo kix bôi vàng (không chèn comment inline text, không chèn phần test checkwork vào Tab 1).
    - Tab 2: Bảng tổng hợp lỗi (4 cột $\le 467.7\,\text{pt}$), Đánh giá hiện trạng đạt AC/WA, Bảng quản lý & CYBOK 1.1 (2 cột $\le 467.7\,\text{pt}$), và 3 Câu hỏi sinh viên kèm dòng kẻ `Trả lời: ___________________________`.
    - *(Chú ý: Lược bỏ 2 mục văn bản dài về kịch bản doanh nghiệp và liên kết môn học khỏi Báo cáo 2; các nội dung này sẽ được đưa trực tiếp vào file HTML ở Bước 3).*
  - *Quy tắc Terminal bắt buộc:* 100% thao tác trên các cửa sổ terminal do bài lab sinh ra (`start.config`) và terminal máy trạm sinh viên (`student@LabtainerVMware:~/labtainer/labtainer-student`). Tuyệt đối KHÔNG tự tạo terminal mới (xterm, gnome-terminal). Chạy `stoplab` dọn dẹp môi trường ngay khi kết thúc.
  - *Tuyệt đối không:* Tự sinh file HTML hay can thiệp vào mã nguồn Labtainer trong cụm bước 1-2.

- **"Hoàn thiện bước 3-4" (hoặc "bước 3", "bước 4")**:
  - *Đầu vào sử dụng:* `guide-template.html` + Phân tích kỹ thuật & Câu hỏi Thẻ 2 + `source code bài cũ`.
  - *Kích hoạt:* `labtainer-step-03-html-guide` và `labtainer-step-04-tech-report`.
  - *Đầu ra duy nhất:*
    - File HTML bài lab mới chuẩn hóa lưu tại `<tên_môn>/New-HTML/<tên_lab_mới>.html` (kế thừa layout `guide-template.html`, chuẩn box màu, lệnh tải/khởi động trong `.box-info`, tiêu đề `Nhiệm vụ <số> - <mã_checkwork>: <Tên nhiệm vụ>`, xưng hô sinh viên, bỏ AI Title-Case, footer SecLab PTIT).
    - Báo cáo Thẻ 3 (Kế hoạch kỹ thuật sửa `results.config`/`goals.config`), Thẻ 4 (Nhận xét phụ trách), Thẻ 5 (Nhận xét HTML).

- **"Hoàn thiện bước 5-6" (hoặc "bước 5", "bước 6")**:
  - *Đầu vào sử dụng:* `source code bài cũ` (file zip/rar gốc) + Kế hoạch kỹ thuật Thẻ 3.
  - *Kích hoạt:* `labtainer-step-05-prep-rename` và `labtainer-step-06-rebuild-test`.
  - *Đầu ra duy nhất:* Đưa `source code bài cũ` vào máy trạm, cấu hình Java 17, đổi tên lab CYBOK bằng `labedit`, sửa `REGISTRY <registry-namespace>`, tạo `read_first.txt` rỗng, sửa chữa `results.config`/`goals.config` (hỗ trợ kiểm tra linh hoạt song song file và history), chạy lệnh `rebuild -f` và test kiểm tra `checkwork` đạt 100% `Y`, kèm ảnh chụp quá trình khởi động xác nhận sạch docs cũ và pull đúng repo `<registry-namespace>`.
  - *Quy tắc Terminal bắt buộc:* Thao tác trực tiếp trên terminal của bài sinh ra và terminal máy trạm sinh viên, tuyệt đối không tự tạo terminal mới. Chạy `stoplab` dọn dẹp môi trường ngay sau khi kết thúc.

- **"Hoàn thiện bước 7"**:
  - *Đầu vào sử dụng:* Lab mới đã build xong + File HTML mới.
  - *Kích hoạt:* `labtainer-step-07-publish-imodule`.
  - *Đầu ra duy nhất:* Publish image lên DockerHub `<registry-namespace>`, tạo `imodule.tar`, đẩy lên GitHub repo bằng PAT và chèn raw download link chuẩn vào file HTML mới cùng Thẻ 3.

---

## Bảng Tổng hợp Bước 1–7 & Luồng Dữ liệu Đầu Vào

| Nhóm | Bước | Tên Bước | Đầu Vào Cần Dùng | Đầu Ra (Deliverables) | Skill Chuyên Biệt |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Giai đoạn I: Đánh giá & Soạn thảo** | **Bước 1** | Thẻ 1: Audit bài gốc & Kiểm thử hiện trạng | `html/docx đề cũ` + `source code bài cũ` + video (nếu có) | Tab 1 Google Docs: Nội dung gốc + Native Comments neo kix, kiểm thử trung thực hiện trạng | `labtainer-step-01-audit` |
| | **Bước 2** | Thẻ 2: Bảng lỗi, CYBOK 1.1 & Câu hỏi | `html/docx đề cũ` + Kết quả Bước 1 | Tab 2 Google Docs: Bảng lỗi 4 cột, Đánh giá AC, Bảng quản lý & CYBOK 1.1, 3 Câu hỏi sinh viên | `labtainer-step-02-scenario-cybok` |
| | **Bước 3** | Biên soạn Hướng dẫn Thực hành HTML | `guide-template.html` + Nội dung đã chuẩn hóa | File `<tên_môn>/New-HTML/<tên_lab_mới>.html` chuẩn giao diện `guide-template.html`, đối soát checklist | `labtainer-step-03-html-guide` |
| | **Bước 4** | Thẻ 3, 4, 5: Kế hoạch kỹ thuật & Tổng kết | `source code bài cũ` + Kết quả Bước 1-3 | Bảng kế hoạch sửa config trong lab mới, thông tin DockerHub/GitHub, Thẻ 4-5 | `labtainer-step-04-tech-report` |
| **Giai đoạn II: Kỹ thuật & Build** | **Bước 5** | Source gốc, Đổi tên CYBOK & Config | File nén gốc `.zip`/`.rar` | Code gốc đầy đủ, Java 17 + `labedit`, đổi tên lab CYBOK, sửa `start.config` (REGISTRY <registry-namespace>), `read_first.txt` rỗng | `labtainer-step-05-prep-rename` |
| | **Bước 6** | Sửa Config, Rebuild & Test Checkwork | Source code lab mới + Thẻ 3 | Sửa `results.config`/`goals.config`, `rebuild -f`, fix docker conflict, test 100% Y, ảnh khởi động lab mới | `labtainer-step-06-rebuild-test` |
| | **Bước 7** | Publish DockerHub, imodule & Raw Link | Code lab mới + HTML mới | Image trên DockerHub (`<registry-namespace>`), imodule trên GitHub, cập nhật raw download link vào HTML | `labtainer-step-07-publish-imodule` |

---

## Giai đoạn III: Kiểm thử thực tế và báo cáo

Đọc [cấu hình môi trường](references/configuration.md) trước khi kết nối. Chỉ làm số bước được giao; yêu cầu toàn bộ quy trình bao gồm bước 1–10. Bước 7 kết thúc phát hành, chưa chứng minh HTML mới đã được kiểm thử trên máy test hiện có.

| Bước | Đầu vào | Đầu ra | Skill |
|---|---|---|---|
| 8: Kết nối máy test | HTML/URL imodule được giao hoặc sau bước 7, VM hiện có | HTML staging có hash, hồ sơ môi trường READY/BLOCKED, ảnh thử | [labtainer-step-08-connect-test](../labtainer-step-08-connect-test/SKILL.md) |
| 9: Thực thi HTML | Hồ sơ bước 8 READY | Bước/ảnh/log thật, checkwork, .lab, kết luận | [labtainer-step-09-execute-html](../labtainer-step-09-execute-html/SKILL.md) |
| 10: Viết báo cáo | Hồ sơ bước 9, mẫu Word kế thừa | DOCX PASS/FAIL hoặc nháp BLOCKED | [labtainer-step-10-review-report](../labtainer-step-10-review-report/SKILL.md) |

- Yêu cầu bước 8: bàn giao HTML và xác minh kết nối và công cụ host, chưa chạy bài.
- Yêu cầu bước 9: kiểm tra điều kiện bước 8 rồi thực hiện trên labtainer-test; không tự sửa/build/publish.
- Yêu cầu bước 10: dùng hồ sơ đã có; thiếu bằng chứng thì ghi BLOCKED, không tự chạy lại bài.
- Yêu cầu bước 8–10: xử lý tuần tự, kế thừa queue html/ → report/, bỏ qua báo cáo đã có.
- Helper bước 10 được dùng cho queue/schema/render; không yêu cầu Google Docs để tạo Word. Hướng dẫn chuyên biệt bước 8–10 bổ sung vận hành remote, giữ nguyên quy trình bước 1–7.
- Checklist tương ứng: references/standards.md mục 6.8, 6.9, 6.10.

## Đối soát Checklist Nghiệm thu Theo Từng Bước

Trước khi kết thúc bất kỳ bước nào và bàn giao sản phẩm cho người dùng, agent bắt buộc phải đối soát đầy đủ các tiêu chí tại **Mục 6 trong references/standards.md của skill labtainer-spec**:
- **Bước 1:** Đối soát Mục 6.0 và 6.1 (khổ A4, font Times New Roman 13pt, tiêu đề đỏ căn giữa, native comments neo kix bôi vàng, kiểm thử trên terminal container, minh chứng checkwork trên terminal máy trạm, stoplab).
- **Bước 2:** Đối soát Mục 6.0 và 6.2 (bảng tổng hợp lỗi 4 cột và bảng CyBOK 2 cột không quá 467.7 pt, nền trong suốt viền đen chữ đen, đánh giá AC, 3 câu hỏi sinh viên kèm dòng kẻ trả lời, tab giải trình nếu có sửa code).
- **Bước 3:** Đối soát Mục 6.0 và 6.3 (file HTML New-HTML kế thừa layout template-v2, huy hiệu độ khó, phân biệt khối terminal và hộp xanh dương, điều kiện hoàn thành kỹ thuật, kịch bản doanh nghiệp 3 phần thường, tiêu đề nhiệm vụ chuẩn, sơ đồ mạng thuần túy, bỏ checkwork/stoplab cuối bài).
- **Bước 4:** Đối soát Mục 6.0 và 6.4 (Thẻ 3 phân tích logic kết quả chấm điểm file or hist, thông tin DockerHub <registry-namespace> và GitHub, Thẻ 4 nhận xét phụ trách, Thẻ 5 nhận xét HTML).
- **Bước 5:** Đối soát Mục 6.0 và 6.5 (source code gốc zip/rar, Java 17 + labedit, đổi tên lab chuẩn CyBOK, cập nhật REGISTRY <registry-namespace>, làm sạch docs và tạo read_first.txt rỗng).
- **Bước 6:** Đối soát Mục 6.0 và 6.6 (sửa goals/results config file or hist, dos2unix pregrade.sh, rebuild -f, kiểm thử 100% Y trên terminal container và máy trạm, ảnh khởi động sạch docs pull <registry-namespace>, stoplab).
- **Bước 7:** Đối soát Mục 6.0 và 6.7 (publish DockerHub <registry-namespace>, đóng gói imodule.tar, push GitHub PAT, lấy raw download link, cập nhật vào HTML và Thẻ 3).



## Claude Code và vị trí thực thi

Skills được nạp từ .claude/skills; điểm vào quy tắc là CLAUDE.md. Có thể gọi /labtainer-spec hoặc /labtainer-step-08-connect-test, /labtainer-step-09-execute-html, /labtainer-step-10-review-report. Tester cố định theo cấu hình hiện tại là <username>@<host>, đăng nhập password local theo configuration.md, không yêu cầu key. Claude Code và toàn bộ việc sinh báo cáo chạy trên máy thật; VM chỉ thực thi HTML và cung cấp minh chứng. Chỉ dùng công cụ thực sự sẵn có trong phiên Claude Code, không mặc định có plugin Google Docs/desktop từ agent cũ.

## Nhận yêu cầu kiểm thử trực tiếp

Khi được giao kiểm thử imodule từ URL bất kỳ, dùng ngay bước 8–10, không yêu cầu bước 1–7 hoặc nguồn <registry-namespace>. Ưu tiên ptitdseclab khi chọn/xếp hàng, giữ URL cụ thể được giao. Không yêu cầu snapshot sạch hay VM độc lập. Tự cài công cụ cần thiết trên host bên ngoài container trước khi chạy bài; sau khi bài đã chạy không cài bổ sung. Nhập mã sinh viên <student_id>, thực hành và chụp ảnh từng bước; sinh báo cáo trên Windows theo template DOCX học viện vào thư mục đã chỉ định (mặc định <workspace>/report). Quy tắc này áp dụng ưu tiên cho kiểm thử; <registry-namespace> trong hướng dẫn build cũ chỉ là ngữ cảnh/ví dụ phát hành, không phải danh sách nguồn cho phép.
