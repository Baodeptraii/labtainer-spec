#!/usr/bin/env python3
"""Capture the current Linux desktop with an already installed tool. Python 3.10+."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    parser.add_argument("--backend", choices=("scrot", "gnome-screenshot"), required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    metadata = output.with_suffix(".capture.json")
    if output.suffix.lower() != ".png":
        parser.error("Use a .png filename")
    if output.exists() or metadata.exists():
        parser.error("Refusing to overwrite capture or metadata")
    exe = shutil.which(args.backend)
    if not exe:
        parser.error("Backend not installed; do not install automatically")
    if not (os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY")):
        parser.error("No desktop session; terminal-only execution is not screenshot evidence")
    if args.backend == "scrot" and os.environ.get("XDG_SESSION_TYPE") == "wayland":
        parser.error("scrot is not selected for Wayland; use an authorized desktop capture tool")
    output.parent.mkdir(parents=True, exist_ok=True)
    started = datetime.now(timezone.utc).isoformat()
    cmd = [exe, str(output)] if args.backend == "scrot" else [exe, "-f", str(output)]
    subprocess.run(cmd, check=True, timeout=30)
    if not output.is_file() or not output.read_bytes().startswith(b"\x89PNG\r\n\x1a\n"):
        raise RuntimeError("No valid PNG produced")
    data = {"file": output.name, "backend": args.backend, "origin": "live-capture",
            "captured_at": started, "finished_at": datetime.now(timezone.utc).isoformat(),
            "sha256": hashlib.sha256(output.read_bytes()).hexdigest()}
    metadata.write_text(json.dumps(data, indent=2), encoding="utf-8")
    print(json.dumps(data, indent=2))
    print("Inspect the image: successful capture does not prove correct window or lab result.")

if __name__ == "__main__":
    main()
