"""
Module: helpers.lab_parser
Phân tích tĩnh cấu hình bài lab Labtainer và trích xuất nội dung tài liệu đề bài gốc (.docx / .html).
"""

import os
import re
from typing import Dict, List, Any, Optional

try:
    import docx
except ImportError:
    docx = None


def parse_start_config(start_config_path: str) -> Dict[str, Any]:
    """
    Phân tích file start.config:
    - Danh sách container và số terminal cấu hình
    - Danh sách mạng ảo kết nối
    - Các tham số khởi chạy
    """
    if not os.path.isfile(start_config_path):
        raise FileNotFoundError(f"start.config not found at: {start_config_path}")

    containers = {}
    networks = {}
    current_container = None

    with open(start_config_path, "r", encoding="utf-8", errors="replace") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue

            parts = line.split(maxsplit=1)
            key = parts[0]
            val = parts[1] if len(parts) > 1 else ""

            if key == "CONTAINER":
                current_container = val.strip()
                containers[current_container] = {
                    "name": current_container,
                    "terminals": 1,
                    "networks": [],
                    "raw_params": []
                }
            elif current_container and key == "TERMINALS":
                try:
                    containers[current_container]["terminals"] = int(val.strip())
                except ValueError:
                    pass
            elif current_container and key.endswith("_NETWORK"):
                containers[current_container]["networks"].append({
                    "net_name": key.replace("_NETWORK", ""),
                    "ip": val.strip()
                })
            elif key == "NETWORK":
                net_parts = val.split()
                if net_parts:
                    networks[net_parts[0]] = val
            elif current_container:
                containers[current_container]["raw_params"].append((key, val))

    return {
        "containers": containers,
        "networks": networks
    }


def parse_goals_config(goals_config_path: str) -> List[Dict[str, str]]:
    """
    Phân tích file goals.config để trích xuất các mục tiêu chấm điểm.
    """
    if not os.path.isfile(goals_config_path):
        return []

    goals = []
    with open(goals_config_path, "r", encoding="utf-8", errors="replace") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue

            # Format: goal_id = operator : target : [args...]
            if "=" in line:
                goal_id, rest = line.split("=", 1)
                goal_id = goal_id.strip()
                rest = rest.strip()
                goals.append({
                    "id": goal_id,
                    "definition": rest
                })

    return goals


def parse_results_config(results_config_path: str) -> List[Dict[str, str]]:
    """
    Phân tích file results.config để trích xuất các biến kết quả và phương thức thu thập.
    """
    if not os.path.isfile(results_config_path):
        return []

    results = []
    with open(results_config_path, "r", encoding="utf-8", errors="replace") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue

            if "=" in line:
                res_id, rest = line.split("=", 1)
                results.append({
                    "id": res_id.strip(),
                    "definition": rest.strip()
                })

    return results


def extract_docx_text(docx_path: str) -> str:
    """Trích xuất toàn bộ văn bản thuần từ file Word .docx."""
    if docx is None:
        raise ImportError("Package 'python-docx' is required to parse .docx files.")

    if not os.path.isfile(docx_path):
        raise FileNotFoundError(f"File not found: {docx_path}")

    doc = docx.Document(docx_path)
    paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
    return "\n\n".join(paragraphs)


def extract_docx_sections(docx_path: str) -> List[Dict[str, Any]]:
    """
    Phân tách tài liệu .docx thành các mục theo tiêu đề và nội dung đoạn văn.
    """
    if docx is None:
        raise ImportError("Package 'python-docx' is required.")

    if not os.path.isfile(docx_path):
        raise FileNotFoundError(f"File not found: {docx_path}")

    doc = docx.Document(docx_path)
    sections = []
    current_title = "Giới thiệu"
    current_texts = []

    for p in doc.paragraphs:
        txt = p.text.strip()
        if not txt:
            continue

        # Nhận diện Heading hoặc các mẫu số thứ tự mục (1., 2., I., II., Nhiệm vụ...)
        is_heading = p.style.name.startswith("Heading") or re.match(r"^(\d+\.|\bNhiệm vụ\b|[IVXLCDM]+\.)", txt)
        if is_heading:
            if current_texts:
                sections.append({
                    "title": current_title,
                    "content": "\n".join(current_texts)
                })
                current_texts = []
            current_title = txt
        else:
            current_texts.append(txt)

    if current_texts:
        sections.append({
            "title": current_title,
            "content": "\n".join(current_texts)
        })

    return sections
