# Chuẩn nội dung và checklist 10 bước

Tài liệu này định nghĩa hệ thống Rules điều phối toàn bộ quy trình chuẩn hoá bài thực hành Labtainer cho hệ thống SecLab PTIT. Bộ quy tắc này áp dụng mặc định và bắt buộc cho tất cả các bài thực hành, báo cáo và tài liệu hướng dẫn.

---

## 0. HỆ THỐNG TIÊU CHÍ & BỘ QUY TẮC CHUẨN HÓA MẶC ĐỊNH (TIÊU CHUẨN CỐT LÕI)

Mọi bài thực hành và tài liệu được chuẩn hóa bắt buộc phải tuân thủ nghiêm ngặt 5 nhóm tiêu chí sau:

### 1. QUY CHUẨN NỘI DUNG (CONTENT CRITERIA)
* **Kịch bản thực tế doanh nghiệp 3 phần chuẩn:** 
  - *Tình huống doanh nghiệp (Scenario):* Giả lập bối cảnh tổ chức/doanh nghiệp có thật hoặc thực tế (ví dụ: công ty cổ phần, bảo tàng, ngân hàng, sàn đấu giá số...).
  - *Vấn đề an ninh mạng (Security Issues):* Phân tích rõ các lỗ hổng kỹ thuật (theo MITRE ATT&CK / CVE / OWASP Top 10) và mối đe dọa tiềm tàng nếu bị khai thác hoặc xâu chuỗi.
  - *Vai trò & Nhiệm vụ cụ thể của sinh viên:* Xác định rõ chức danh nghề nghiệp (ví dụ: Chuyên viên Đánh giá An toàn thông tin / Red Team / SOC Analyst) được ủy quyền kiểm thử kèm các mục tiêu kỹ thuật cần đạt.
* **Phân loại chuẩn CYBOK 1.1:** Xác định rõ Lĩnh vực kiến thức chính (Knowledge Area) và Chủ đề phụ (Topic) tương ứng trong CyBOK v1.1.
* **Liên kết chương trình đào tạo PTIT:** Chỉ rõ sự liên kết với tối thiểu 2–3 học phần chuyên ngành An toàn thông tin đang giảng dạy tại PTIT (ví dụ: An toàn ứng dụng Web và Cơ sở dữ liệu, Kiểm thử xâm nhập, Cơ sở ATTT, Quản trị an ninh mạng...).
* **Bảng thông tin quản trị:** Thống nhất Tên Lab gốc, Tên Lab mới chuẩn CYBOK, Mức độ khó, Thời lượng thực hành (30–60 phút).
* **Câu hỏi tư duy & Đánh giá năng lực:** Bổ sung tối thiểu 3 câu hỏi chuyên sâu kiểm tra bản chất kỹ thuật, cơ chế phòng thủ, kèm dòng kẻ trả lời chuẩn: `Trả lời: ___________________________`.
* **Xưng hô chuẩn mực:** 100% sử dụng danh xưng **"sinh viên"**, tuyệt đối không xưng "bạn", "người dùng", "chúng ta".

---

### 2. QUY CHUẨN TRÌNH BÀY HTML & GIAO DIỆN SECLAB (HTML & UI CRITERIA)
* **Kế thừa Layout mẫu:** Bắt buộc sử dụng khung cấu trúc, font chữ Times New Roman 13pt, khoảng cách dòng, và footer bản quyền từ `.claude/skills/labtainer-spec/assets/guide-template.html` (độ rộng `.page` tối đa `860px`, có khối `@media print`).
* **Quy tắc màu sắc Huy hiệu Mức độ (Difficulty Badges ở Header):**
  - **Dễ**: Màu **Xanh lá** (class `.badge-easy`, nền `#e8f5e9`, chữ `#2e7d32`, viền `#a5d6a7`).
  - **Trung bình**: Màu **Vàng** (class `.badge-medium`, nền `#fff3cd`, chữ `#856404`, viền `#ffc107`).
  - **Khó**: Màu **Đỏ** (class `.badge-hard`, nền `#fdecea`, chữ `#a83226`, viền `#f5b7b1`).
* **Hệ thống 4 Hộp màu nội dung (Boxes) & Khối lệnh Terminal:**
  - **Khối màu đen terminal (`<pre><span class="cmd">...</span></pre>`)**: Dành riêng cho **lệnh sẵn sao chép (copy-paste trực tiếp)**, cú pháp cố định chuẩn xác mà sinh viên có thể chạy ngay không cần chỉnh sửa tham số.
  - **Xanh dương (`.box-info`)**: **Gợi ý câu lệnh cần sửa tham số** (dành cho các câu lệnh mang tính gợi ý, cú pháp mẫu hoặc template chứa các biến/tham số cần sinh viên tự thay thế như `<IP_server>`, `<cổng>`, `<tên_miền>`, `<tệp_tin>`).
  - **Xanh lá (`.box-success`)**: **Điều kiện hoàn thành** (nêu rõ các tiêu chí kết quả kỹ thuật đạt được cụ thể; **TUYỆT ĐỐI KHÔNG ghi máy móc** dạng *"Sinh viên chạy lệnh checkwork và mục tiêu X đạt trạng thái Y"* hay *"Lệnh checkwork trả về trạng thái Y cho mục tiêu..."*).
  - **Đỏ / Hồng nhạt (`.box-danger`)**: **Câu hỏi cho sinh viên** (kèm dòng gạch dưới trả lời).
  - **Vàng (`.box-warning`)**: **Lưu ý quan trọng** hoặc cảnh báo an toàn.
  - **Kịch bản / Tình huống:** Trình bày bằng văn bản thường, **tuyệt đối KHÔNG bọc box**.
* **Quy tắc phần Tải và Khởi động bài thực hành (theo chuẩn `guide-template.html`):**
  Trình bày trong khối `.box-info` chuẩn:
  ```html
  <div class="box box-info">
    Để tải bài thực hành, sinh viên thực hiện câu lệnh: <br />
    <code>imodule https://github.com/<registry-namespace>/<tên_lab_mới>/raw/refs/heads/main/imodule.tar</code><br />
    Để khởi động bài thực hành, sinh viên dùng câu lệnh: <br />
    <code>labtainer <tên_lab_mới></code><br />
    <em>(chú ý: sinh viên sử dụng mã sinh viên của mình để nhập thông tin email người thực hiện bài lab khi có yêu cầu, để sử dụng khi chấm điểm)</em>
  </div>
  ```
* **Quy tắc Tiêu đề Nhiệm vụ:** Bắt buộc theo đúng định dạng: `Nhiệm vụ <số> - <mã_checkwork>: <Tên nhiệm vụ>` (Ví dụ: `Nhiệm vụ 1 - port_scan: Quét và xác định cổng dịch vụ nội bộ qua SSRF`).
* **Lược bỏ phần Hướng dẫn kiểm tra và kết thúc:** **KHÔNG ghi mục "Hướng dẫn kiểm tra và kết thúc bài thực hành"** (không đưa lệnh checkwork hay stoplab ở cuối trang HTML), **chỉ cần ghi các nhiệm vụ thực hành thôi**.

---

### 3. QUY CHUẨN GOOGLE DOCS & BÁO CÁO AUDIT (GDOCS & AUDIT CRITERIA)
* **Tên tài liệu Google Docs:** Đặt theo định dạng `1 - <mã_lab_cũ>` (Ví dụ: `1 - pen_a1_t1595`).
* **Phân chia 2 Tab tiêu chuẩn:**
  - **Tab 1:** `Báo cáo 1: Nhận xét chung về bài lab` (chứa toàn bộ nội dung bài gốc và hệ thống nhận xét chi tiết qua Native Comments; **BỎ HOÀN TOÀN phần:** *"KIỂM THỬ HIỆN TRẠNG VÀ KẾT QUẢ CHECKWORK BÀI LAB GỐC"* khỏi Tab 1).
  - **Tab 2:** `Báo cáo 2: Tổng hợp lỗi, minh chứng, đề xuất` (chứa Bảng tổng hợp lỗi, Bảng thông tin quản lý & CYBOK 1.1, và 3 Câu hỏi đánh giá sinh viên; **LƯỢC BỎ hoàn toàn 2 mục văn bản:** *"Đề xuất kịch bản doanh nghiệp thực tế"* và *"Sự liên kết giữa bài lab với các môn học tại PTIT"* khỏi Báo cáo 2).
* **Định dạng trang in chuẩn A4 & Căn lề 4 hướng:**
  - Khổ giấy: **A4** ($595.3\,\text{pt} \times 841.9\,\text{pt}$).
  - Căn lề 4 hướng: **Top: 2.0 cm** ($56.7\,\text{pt}$), **Bottom: 2.0 cm** ($56.7\,\text{pt}$), **Left: 2.5 cm** ($70.9\,\text{pt}$), **Right: 2.0 cm** ($56.7\,\text{pt}$).
  - Bề rộng in khả dụng tối đa cho các bảng: $\le 467.7\,\text{pt}$.
* **Tiêu đề đầu trang in ĐỎ & CĂN GIỮA:** Đầu trang của cả 2 tab (và các tab khác) để tên bài in màu **ĐỎ nổi bật** (`<mã_lab_cũ>`, font đỏ đậm `#d93025`, in đậm, 20–22pt) và **CĂN GIỮA (alignment: CENTER)** thay vì ghi "BÁO CÁO THẺ 1..." hay "BÁO CÁO THẺ 2...".
* **Quy chuẩn Font chữ, Cỡ chữ & Phân cấp Headings (h1, h2, h3, h4):**
  - **Font chữ toàn bộ văn bản:** Bắt buộc 100% sử dụng font **Times New Roman** cho toàn bộ tài liệu (bao gồm thân bài, tiêu đề, bảng biểu, danh sách).
  - **Cỡ chữ toàn bộ text nội dung:** Thống nhất toàn bộ văn bản thông thường và các cấp tiêu đề đều ở cỡ **13pt**.
  - **Phân chia rõ ràng các đoạn sử dụng h1, h2, h3, h4 (toàn bộ giữ đúng cỡ chữ 13pt):**
    - **Heading 1 (h1) & Heading 2 (h2):** Cỡ chữ **13pt**, **in đậm (bold)**.
    - **Heading 3 (h3) & Heading 4 (h4):** Cỡ chữ **13pt**, **in đậm + in nghiêng (bold + italic)**.
* **Quy chuẩn định dạng text là Code (Khối lệnh / Payload / Cấu hình):**
  - Khi văn bản là câu lệnh terminal, cú pháp mẫu, payload hoặc nội dung mã/file cấu hình:
    - **Chỉ căn giữa (alignment: CENTER)**.
    - Giữ nguyên màu chữ đen và kiểu chữ tiêu chuẩn của văn bản Times New Roman 13pt (tuyệt đối không tô màu xanh lá, không in nghiêng).
* **Lược bỏ thông tin thừa / Đồ án cá nhân:** Xóa sạch 2 dòng `Chủ đề gốc: ...` và `Tác giả bài gốc: ...`, đồng thời loại bỏ toàn bộ phần báo cáo đồ án tốt nghiệp của tác giả bài cũ (chụp ảnh labedit, lệnh git commit, docker login cá nhân...).
* **Cơ chế Nhận xét (Comments) Native Google Docs:**
  - **Xóa bỏ triệt để các đoạn comment dạng inline text** (`💬 Comment nhận xét 1...`) trong thân bài.
  - Sử dụng **Google Docs API `batchUpdate` (`insertComment`)** với tọa độ `startIndex` và `endIndex` chính xác để tạo mã neo `kix.*` nội bộ.
  - Mỗi comment phải neo và bôi vàng (highlight) trực tiếp vào đoạn văn bản được nhận xét.
  - **Các comment phải viết ngắn gọn, súc tích, đi thẳng vào lỗi kỹ thuật, tuyệt đối không viết dài dòng.**
* **Định dạng Bảng ở Tab 2 vừa vặn A4 & Bảng nền hoàn toàn trong suốt, viền đen chữ đen:**
  - Định dạng bảng: **Tuyệt đối không tô màu nền cho ô bảng (nền trong suốt 100%), sử dụng viền màu đen mảnh và chữ đen tiêu chuẩn**.
  - *Bảng tổng hợp lỗi (4 cột):* Phân bổ cột `32 pt` - `180 pt` - `180 pt` - `73 pt` (Tổng: $465\,\text{pt} \le 467.7\,\text{pt}$).
  - *Bảng quản lý CYBOK (2 cột):* Phân bổ cột `140 pt` - `325 pt` (Tổng: $465\,\text{pt} \le 467.7\,\text{pt}$).
* **Nội dung Tab 2 (Báo cáo 2: Tổng hợp lỗi, minh chứng, đề xuất):**
  - Chứa Bảng tổng hợp lỗi, Bảng thông tin quản lý & CYBOK 1.1, và 3 Câu hỏi đánh giá sinh viên.
  - **Bổ sung mục đánh giá bài lab có AC không:** Nêu rõ hiện trạng bài lab gốc có đạt AC (Accepted) trên hệ thống SecLab hay bị WA/Error, chỉ rõ nguyên nhân kỹ thuật.
  - Lược bỏ hoàn toàn 2 mục văn bản dài: kịch bản doanh nghiệp và sự liên kết môn học khỏi Báo cáo 2.
* **Quy định về Tab giải trình sửa code (Tab 3 - nếu có sửa code):**
  - Nếu bài lab có sửa mã nguồn (sửa code web, script chấm điểm, container files), bắt buộc bổ sung thêm 1 tab riêng: `Giải trình sửa đổi mã nguồn và cấu hình chấm điểm`.
  - Nội dung tab giải trình: Nêu chi tiết những điểm đã sửa, lý do sửa, kèm ảnh chụp file cấu hình chấm điểm (`results.config`, `goals.config`, `pregrade.sh`).
* **Quy chuẩn quá trình build và đóng gói bài lab:**
  - **Build bài lab bằng tên mới chuẩn CYBOK** theo đúng hướng dẫn.
  - **Bỏ hoàn toàn thư mục tài liệu docs hướng dẫn trong bài lab cũ** và tạo file rỗng `touch docs/read_first.txt` trước khi build lại bằng tên mới.
  - **Thêm thẻ giải trình minh chứng bằng ảnh chụp:** Sau khi build xong, bổ sung thẻ giải trình đính kèm 1 ảnh chụp quá trình khởi động bài lab trên máy trạm để kiểm tra xem còn file docs cũ không và xác nhận image được pull về đúng từ đường dẫn DockerHub của khoa (`<registry-namespace>/...`).
* **Quy tắc Kiểm thử & Chụp ảnh minh chứng ở Bước 1 (Audit bài lab gốc):**
  - **Tuân thủ đúng hướng dẫn bài cũ:** Bắt buộc thực hiện theo đúng các bước và câu lệnh trong tài liệu đề bài gốc (`.docx`).
  - **Không cố gắng gượng ép để đạt Y hết:** Tuyệt đối không can thiệp, không hack hay tạo file giả lập bên ngoài để ép checkwork đạt `Y`. Nếu làm theo hướng dẫn bài cũ mà kết quả trả về `N`, lỗi hoặc thiếu cờ thì ghi nhận trung thực hiện trạng, ghi chú rõ nguyên nhân kỹ thuật và gắn native comment audit chỉ rõ lỗi đó. Việc sửa đổi, chuẩn hóa mã nguồn và cấu hình chấm điểm để đạt 100% `Y` sẽ được thực hiện ở các bước sau (Bước 5 & 6).
  - **Bắt buộc thao tác trực tiếp trên terminal của bài lab sinh ra (TUYỆT ĐỐI KHÔNG TỰ TẠO TERMINAL MỚI):**
    • Khi khởi động bài lab bằng lệnh `labtainer <tên_lab>`, hệ thống Labtainer sẽ tự động khởi tạo các cửa sổ terminal container trên màn hình desktop máy ảo (`DISPLAY=:0`) theo đúng cấu hình `start.config` (ví dụ: `ubuntu@attacker:~` với số tab tương ứng).
    • **Nghiêm cấm tuyệt đối:** Không được chạy các lệnh `xterm`, `gnome-terminal`, `xterm -e ...` hoặc tự tạo bất kỳ cửa sổ terminal mới nào bên ngoài. Việc tự tạo terminal riêng để chụp ảnh là vi phạm quy chuẩn nghiệm thu.
    • **Cơ chế tương tác kỹ thuật bắt buộc qua `xdotool`:**
      1. Tìm Window ID của cửa sổ terminal do bài lab sinh ra: `WID=$(DISPLAY=:0 xdotool search --name "ubuntu@<tên_container>: ~" | head -n 1)`.
      2. Kích hoạt cửa sổ: `DISPLAY=:0 xdotool windowactivate --sync $WID`.
      3. Nhập lệnh trực tiếp vào terminal: `DISPLAY=:0 xdotool type '<lệnh>' && DISPLAY=:0 xdotool key Return`.
      4. Chuyển đổi tab ảo (nếu cấu hình `TERMINALS` > 1): sử dụng phím tắt `DISPLAY=:0 xdotool key alt+1`, `alt+2`.
      5. Chụp ảnh màn hình đúng cửa sổ đó: `DISPLAY=:0 import -window $WID /tmp/<tên_ảnh>.png`.
  - **Phân biệt rõ ràng 2 loại Terminal khi thao tác và chụp ảnh:**
    • **Terminal của container bài lab (`ubuntu@<tên_container>:~` theo `start.config`):** Dành riêng cho toàn bộ các thao tác kỹ thuật chuyên môn (quét mạng, khai thác lỗ hổng, chèn payload, netcat đón shell, leo thang đặc quyền, tạo file backdoor...).
    • **Terminal của máy trạm sinh viên (`student@LabtainerVMware:~/labtainer/labtainer-student`):** Dành riêng cho các câu lệnh điều khiển hệ thống Labtainer gồm `labtainer <tên_lab>`, `checkwork` và `stoplab <tên_lab>`. Khi chụp ảnh minh chứng cho câu lệnh `checkwork` hoặc `stoplab`, bắt buộc phải chuyển sang cửa sổ này (`DISPLAY=:0 xdotool search --name "student@LabtainerVMware: ~/labtainer/labtainer-student"`) để chạy lệnh và chụp ảnh.
  - **Khởi động Firefox không lỗi Sandbox:** Khi mở trình duyệt Firefox từ terminal của container trong bài lab, nếu gặp lỗi sandbox hoặc ứng dụng không khởi động được, sử dụng câu lệnh: `MOZ_DISABLE_CONTENT_SANDBOX=1 firefox &`.
  - **Bắt buộc chạy stoplab khi kết thúc mỗi bài lab:** Ngay sau khi hoàn thành phiên kiểm thử hoặc chụp ảnh minh chứng của mỗi bài lab, bắt buộc phải thực thi câu lệnh `stoplab` trên terminal máy trạm sinh viên (`~/labtainer/labtainer-student`) để dừng toàn bộ container và giải phóng tài nguyên trước khi chuyển sang tác vụ khác.
  - **Gộp nhiều lệnh trên 1 terminal theo nhóm việc:** Được phép và khuyến khích chạy nhiều lệnh liên tiếp trên cùng một cửa sổ terminal nếu các lệnh đó phục vụ chung một nhóm việc/nhiệm vụ (ví dụ: chuỗi lệnh trinh sát nmap/dirsearch, hoặc tạo tệp cấu hình rồi chạy script...), giúp ảnh chụp thể hiện luồng thao tác tự nhiên, mạch lạc thay vì mỗi lệnh mở một cửa sổ rời rạc.
  - **Mở terminal và truy cập (access) đúng yêu cầu khi chụp ảnh:** Nếu bước nào trong kịch bản bắt buộc phải mở thêm terminal hoặc truy cập (access) vào một container/máy chủ khác (ví dụ: mở terminal lắng nghe Netcat đón reverse shell, thiết lập phiên kết nối SSH sang máy chủ mục tiêu, hoặc truy cập console theo yêu cầu bài thực hành), bắt buộc phải mở terminal và truy cập (access) vào đúng ngữ cảnh môi trường theo đúng yêu cầu đề bài rồi mới thực hiện thao tác và chụp ảnh màn hình minh chứng.
  - **Chụp đúng giao diện thực tế đối với các bước tương tác GUI:** Với các bước có thao tác trên giao diện đồ họa (như mở trình duyệt Firefox truy cập web, đăng ký/đăng nhập tài khoản, upload file trên giao diện web, hoặc sử dụng công cụ GUI như OWASP ZAP, Burp Suite, Wireshark...), bắt buộc phải chụp ảnh màn hình chính xác cửa sổ giao diện ứng dụng đó (cửa sổ Firefox hiển thị trang web/form/kết quả, hoặc giao diện ZAP/Wireshark), tuyệt đối **KHÔNG chụp màn hình terminal chỉ gõ lệnh khởi động** (như lệnh `firefox &` hay curl). Ảnh chụp phải thể hiện trực quan nội dung trang web hoặc kết quả xử lý trên giao diện đúng theo yêu cầu kịch bản đề bài.

---

### 4. QUY CHUẨN LOGIC & CẤU TRÚC (LOGIC & ARCHITECTURAL CRITERIA)
* **Không đưa lệnh điều khiển vào các bước nhiệm vụ:** **Tuyệt đối KHÔNG đưa lệnh `checkwork` hay `stoplab` thành các "Bước" trong nhiệm vụ**.
* **Sơ đồ mạng (Topology) thuần túy:** Chỉ vẽ cấu trúc hạ tầng mạng (máy tính, IP, vai trò, dải LAN). **Tuyệt đối không ghi chú spoiler** về cổng ẩn, URL lỗ hổng, tên bảng CSDL, payload khai thác, hay các mũi tên mô tả từng bước tấn công.
* **Logic chấm điểm Labtainer:**
  - `instr_config/goals.config` bắt buộc phải có đầy đủ định nghĩa tất cả các goals (không được để file rỗng).
  - `instr_config/results.config` phải hỗ trợ kiểm tra linh hoạt (bắt song song từ file kết quả và lịch sử lệnh `.bash_history` qua toán tử boolean `file or hist` để tránh chấm trượt sinh viên dùng editor ghi file).

---

### 5. NHỮNG ĐIỀU CẦN TRÁNH TUYỆT ĐỐI (ANTI-PATTERNS / WHAT TO AVOID)
1. **TRÁNH VĂN PHONG DỊCH AI MÁY MÓC & CHÈN TIẾNG ANH TRONG NGOẶC:** Khi đã có từ ngữ tiếng Việt thì tuyệt đối không mở ngoặc đơn chèn thêm từ tiếng Anh tương đương (Ví dụ sai: *đường ống (pipeline)*, *xâu chuỗi lỗ hổng (vulnerability chaining)* $\rightarrow$ Sửa đúng: chỉ dùng một từ tiếng Việt chuẩn xác hoặc giữ nguyên thuật ngữ tiếng Anh gốc).
2. **TRÁNH VIẾT HOA TẤT CẢ CHỮ CÁI ĐẦU Ở CÁC ĐẦU MỤC:** Không viết hoa từng chữ cái đầu của mỗi từ trong tiếng Việt (Ví dụ sai: *Các Nhiệm Vụ Của Bài Thực Hành* $\rightarrow$ Sửa đúng: *Các nhiệm vụ của bài thực hành*).
3. **TRÁNH TÔ MÀU BẢNG LÒE LOẸT:** Bảng biểu dùng viền đen, chữ đen, không tô màu nền cho ô bảng.
4. **TRÁNH SPOIL ĐÁP ÁN & GÁN CỨNG DỮ LIỆU:** Không cung cấp sẵn 100% payload giải bài mà không giải thích; không gán cứng tài khoản demo (test/test) thay vì hướng dẫn sinh viên tự đăng ký tài khoản cá nhân.
5. **TRÁNH LỖI COMMENT "ĐÃ XÓA NỘI DUNG GỐC":** Không gọi Drive API với HTML entities hoặc quote thiếu `kix.*` anchor làm hỏng chức năng nhận xét trong Google Docs.
6. **TRÁNH DÙNG IMODULE ĐỂ SỬA LAB:** Tuyệt đối không dùng thư mục giải nén từ file imodule để rebuild lab (do thiếu `dockerfiles/`), bắt buộc dùng file nén mã nguồn gốc `.rar`/`.zip`.
7. **TRÁNH DÙNG DẤU GẠCH NGANG DÀI VÀ HẠN CHẾ DẤU NGOẶC KÉP:** Tuyệt đối không dùng dấu gạch ngang dài (em-dash `—` hoặc en-dash `–`). Hạn chế tối đa việc đặt các từ hoặc cụm từ trong dấu ngoặc kép.
8. **TRÁNH DÙNG ĐƯỜNG PHÂN CÁCH (DIVIDER LINE):** Không dùng các đường kẻ ngang phân cách (như `---`, `***`, divider line) trong câu trả lời và tài liệu trừ khi mẫu template HTML gốc quy định sẵn.
9. **NGÔN NGỮ VÀ THUẬT NGỮ:** Trả lời hoàn toàn bằng tiếng Việt, các thuật ngữ kỹ thuật chuyên ngành giữ nguyên tiếng Anh chuẩn xác (không tự ý dịch thô sang tiếng Việt).
10. **TÍNH CHÍNH XÁC VÀ TRUNG THỰC:** Tuyệt đối không bịa đặt thông tin, không giả định kết quả khi chưa kiểm chứng thực tế trên mã nguồn, video hoặc máy trạm.
11. **TRÁNH CHỤP TERMINAL THAY THẾ CHO GIAO DIỆN ĐỒ HỌA (GUI):** Những bước yêu cầu tương tác trên giao diện đồ họa (Firefox duyệt web, form submit, upload file qua web, OWASP ZAP) bắt buộc phải chụp đúng cửa sổ giao diện ứng dụng đó, tuyệt đối không chụp cửa sổ terminal chỉ gõ lệnh chạy nền (như `firefox &`) để đối phó.
12. **TRÁNH TỰ MỞ TERMINAL NGOÀI & QUÊN CHẠY STOPLAB:** Tuyệt đối không tự ý mở cửa sổ terminal riêng bên ngoài thay cho các cửa sổ hoặc tab do chính bài lab khởi tạo trên màn hình máy ảo (`start.config`). Luôn luôn chạy câu lệnh `stoplab` để dừng container và dọn dẹp môi trường ngay sau khi hoàn thành kiểm thử hoặc chụp ảnh mỗi bài lab.

---

## 1. ĐỊNH NGHĨA BỘ DỮ LIỆU ĐẦU VÀO THỰC TẾ (INPUT CONTRACT)

Với mỗi bài lab cần chuẩn hoá, người dùng sẽ cung cấp đường dẫn đến thư mục bài lab (ví dụ: `KTXN/SOURCE_CODE/<tên_lab>/`) chứa các thành phần chuẩn sau:

1. **File Đề bài / Hướng dẫn cũ (`<tên_lab>.docx` hoặc `.html`):**
   - Tài liệu Word/HTML chứa nội dung đề bài gốc, các mục tiêu, giải thích lý thuyết, các nhiệm vụ thực hành, câu hỏi và chuỗi lệnh cũ.
   - *Sử dụng cho:* Bước 1 (Trích xuất Thẻ 1, gắn comment audit), Bước 2 (Lập bảng tổng hợp lỗi, nâng cấp kịch bản doanh nghiệp) và Bước 3 (Nội dung cho file HTML mới).
2. **File Nén Mã Nguồn Gốc (`<tên_lab>.rar` hoặc `.zip`):**
   - File nén chứa toàn bộ source code gốc của bài lab: `config/start.config`, `dockerfiles/`, `instr_config/results.config`, `instr_config/goals.config`, `instr_config/pregrade.sh`, thư mục dữ liệu container (`user`, `attacker`, `victim`...).
   - *Sử dụng cho:* Bước 1 & Bước 4 (Phân tích tĩnh cấu hình chấm điểm `instr_config`), Bước 5 (Giải nén đưa vào trạm máy ảo `~/labtainer/trunk/labs/`, cấu hình `REGISTRY`, đổi tên lab), Bước 6 (Sửa `results.config`/`goals.config`, rebuild và test).
3. **Video Quay Thực Hành Thực Tế (`<tên_lab>.mp4` hoặc `.mkv`):**
   - Video quay lại toàn bộ phiên thực hành thực tế của bài lab: các cửa sổ terminal khởi động, thao tác lệnh thực tế của người làm bài, output của dịch vụ và kết quả chạy `checkwork`.
   - *Sử dụng cho:* Bước 1 (Minh chứng trực quan xác nhận thao tác thực tế, đối chiếu với mô tả trong docx, ghi nhận kết quả checkwork và trạng thái đạt AC trên hệ thống SecLab).
4. **Gói iModule Cũ (`imodule_<tên_lab>.tar` hoặc `imodule.tar`):**
   - Gói imodule bài lab cũ phân phối ban đầu. 
   - *Lưu ý cốt lõi:* Tuyệt đối không dùng thư mục giải nén từ file imodule này để sửa và build lab mới (vì thiếu thư mục `dockerfiles/`), mà **bắt buộc phải dùng file nén mã nguồn gốc `.rar` / `.zip` ở mục 2**.
5. **Template HTML Chuẩn Mới (`guide-template.html`):**
   - File HTML mẫu giao diện chuẩn của SecLab PTIT đặt tại đường dẫn: `.claude/skills/labtainer-spec/assets/guide-template.html`.
6. **Thư Mục Lưu Trữ File HTML Mới:**
   - File HTML mới sinh ra bắt buộc phải được lưu vào thư mục `New-HTML` của môn học tương ứng theo cấu trúc:  
     `<project-root>\<tên_môn>\New-HTML\<tên_lab_mới>.html`  
     *(Ví dụ môn KTXN: `<project-root>\KTXN\New-HTML\<tên_lab_mới>.html`)*.

---

## 2. NGUYÊN TẮC CỐT LÕI: PHẠM VI CÔ LẬP (SCOPE ISOLATION)

Khi người dùng ra lệnh thực hiện một hoặc một nhóm bước cụ thể (ví dụ: *"hoàn thiện bước 1-2"*, *"làm bước 3-4"*, *"chỉ làm bước 1"*, *"thực hiện bước 5-6"*, *"bước 7"*):
1. **TUYỆT ĐỐI KHÔNG làm tràn sang các bước khác** ngoài phạm vi được chỉ định.
2. **Tập trung 100% vào đúng đầu ra (deliverables)** của các bước được yêu cầu, kết hợp chặt chẽ giữa các thành phần đầu vào (`<tên_lab>.docx`, `.rar`/`.zip`, `.mp4`, `guide-template.html`) và tuân thủ chính xác form mẫu biểu, bảng, cú pháp và checklist quy định.
3. Khi hoàn thành các bước được giao, **dừng lại và tóm tắt kết quả bàn giao**, kèm theo hướng dẫn/gợi ý để người dùng kiểm tra hoặc chỉ thị tiếp tục sang các bước tiếp theo.

---

## 3. BẢN ĐỒ ÁNH XẠ CÁC BƯỚC THỰC THI (STEP MAPPING DỰA TRÊN CÁC INPUT)

| Bước | Tên Bước / Hạng Mục | Đầu Vào Sử Dụng | Phạm Vi Nội Dung / Đầu Ra (Deliverables) | Skill Kích Hoạt |
| :--- | :--- | :--- | :--- | :--- |
| **Bước 1** | **Báo cáo Thẻ 1: Nhận xét bài lab gốc & Kiểm thử hiện trạng** | - `<tên_lab>.docx`<br>- `<tên_lab>.rar` / `.zip`<br>- `<tên_lab>.mp4` (video minh chứng) | - Đọc `<tên_lab>.docx`, trích xuất toàn bộ nội dung đưa vào Thẻ 1 (trên Google Docs Tab 1).<br>- Bỏ 2 dòng thông tin đồ án cá nhân. Tiêu đề in đỏ.<br>- Đối chiếu lệnh trong đề docx với logic trong `instr_config` của source code và video mp4, tạo native comment qua Docs API (`kix.*` anchor), tuyệt đối không để comment inline trong bài.<br>- **Kiểm thử thực tế theo đúng đề bài cũ:** Chạy bài lab trên máy trạm, thao tác tuần tự đúng theo lệnh đề bài gốc trên chính terminal của bài sinh ra (cho phép gộp nhiều lệnh chung nhóm việc trên 1 terminal). Đối với các bước tương tác GUI (Firefox duyệt web, ZAP, Wireshark), bắt buộc chụp đúng cửa sổ giao diện ứng dụng đó, không chụp terminal gõ lệnh chạy nền. **TUYỆT ĐỐI KHÔNG tự tạo terminal mới** (xterm, gnome-terminal). Minh chứng `checkwork` và `stoplab` bắt buộc chụp trên terminal máy trạm sinh viên (`student@LabtainerVMware:~/labtainer/labtainer-student`). Ghi nhận trung thực hiện trạng kết quả checkwork. | `labtainer-step-01-audit` |
| **Bước 2** | **Báo cáo Thẻ 2: Bảng lỗi, Quản lý CYBOK 1.1, Câu hỏi & Đánh giá AC** | - `<tên_lab>.docx`<br>- Kết quả Thẻ 1 | - Đưa vào Tab 2 Google Docs, tiêu đề in đỏ.<br>- Tổng hợp các lỗi phát hiện thành Bảng lỗi (4 cột, bề rộng $\le 467\,\text{pt}$, không tô màu viền đen chữ đen).<br>- Bảng thông tin quản lý & Phân loại CyBOK 1.1, ánh xạ môn học PTIT (2 cột, $\le 467\,\text{pt}$, không tô màu).<br>- Bổ sung 3 câu hỏi sinh viên kèm dòng kẻ `Trả lời: ___________________________`.<br>- Bổ sung mục đánh giá bài lab có AC không và nguyên nhân.<br>- Nếu có sửa code: bổ sung thêm 1 tab giải trình đã sửa những gì kèm ảnh chụp file cấu hình chấm điểm.<br>- Lược bỏ 2 mục văn bản kịch bản doanh nghiệp và liên kết môn học khỏi Báo cáo 2. | `labtainer-step-02-scenario-cybok` |
| **Bước 3** | **Biên soạn Hướng dẫn Thực hành HTML Chuẩn hóa & Checklist** | - `guide-template.html`<br>- Kịch bản Thẻ 2 (từ docx) | - Xuất file HTML mới vào `<tên_môn>/New-HTML/<tên_lab_mới>.html`.<br>- Kế thừa CSS layout từ `guide-template.html`.<br>- Huy hiệu mức độ: Dễ (Xanh lá), Trung bình (Vàng), Khó (Đỏ).<br>- Phân định khối lệnh: Lệnh sẵn copy dùng khối màu đen terminal `<pre><span class="cmd">...</span></pre>`; Gợi ý câu lệnh cần sửa tham số dùng hộp màu xanh dương `.box-info`.<br>- Hộp 4 màu chuẩn (Success, Danger, Warning, Info).<br>- Tiêu đề nhiệm vụ: `Nhiệm vụ <số> - <mã_checkwork>: <Tên nhiệm vụ>`.<br>- Điều kiện hoàn thành: Mô tả tiêu chí kỹ thuật cụ thể (không ghi máy móc checkwork đạt Y).<br>- Sơ đồ mạng thuần túy không spoiler.<br>- Không đưa checkwork/stoplab thành các bước nhiệm vụ. Xưng hô sinh viên, tránh viết hoa tất cả chữ cái đầu các mục, tránh () tiếng Anh khi đã có tiếng Việt. | `labtainer-step-03-html-guide` |
| **Bước 4** | **Báo cáo Thẻ 3, 4, 5: Kế hoạch Kỹ thuật Sửa Build Lab & Tổng kết Báo cáo** | - `<tên_lab>.rar` / `.zip` (source code bài cũ) | - Phân tích sâu `results.config`, `goals.config`, `pregrade.sh`, `start.config`.<br>- Lập Bảng kỹ thuật và giải pháp sửa chữa cụ thể trong bài mới.<br>- Khai báo DockerHub username (`<registry-namespace>`) và repository GitHub của file imodule.<br>- Soạn thảo Thẻ 4 (Nhận xét người phụ trách) và Thẻ 5 (Nhận xét HTML). | `labtainer-step-04-tech-report` |
| **Bước 5** | **Chuẩn bị Source Code Gốc, Cài Java 17, Đổi Tên Lab (`labedit`) & Cấu hình** | - `<tên_lab>.rar` / `.zip` | - Giải nén mã nguồn gốc vào `/home/student/labtainer/trunk/labs/`.<br>- Cài Java 17, khởi động `labedit`, đổi tên bài lab chuẩn CYBOK.<br>- Cập nhật `REGISTRY <registry-namespace>` trong `config/start.config`.<br>- Làm sạch thư mục `docs/` và tạo `touch docs/read_first.txt` rỗng. | `labtainer-step-05-prep-rename` |
| **Bước 6** | **Sửa Logic Chấm Điểm, Rebuild Docker, Troubleshooting & Kiểm Thử Checkwork** | - Source code lab mới<br>- Kế hoạch kỹ thuật Thẻ 3 | - Trực tiếp sửa `results.config` (bắt song song file và history) và `goals.config` (đầy đủ mục tiêu).<br>- `chmod +x pregrade.sh`, xử lý `dos2unix`.<br>- Bỏ phần docs hướng dẫn trong lab cũ và build lại bằng tên mới.<br>- Rebuild bài lab: `rebuild -f <tên_lab_mới>`.<br>- Xử lý xung đột Docker, chạy kiểm thử thực tế đến khi 100% task đạt `Y`.<br>- Thêm thẻ giải trình minh chứng bằng 1 ảnh chụp quá trình khởi động bài lab xác nhận sạch docs và pull đúng repo `<registry-namespace>`. | `labtainer-step-06-rebuild-test` |
| **Bước 7** | **Publish DockerHub, Tạo imodule GitHub & Cập Nhật Link Vào HTML** | - Lab mới đã build xong<br>- File HTML mới (Bước 3) | - Đẩy image lên DockerHub: `./publish.py -d -l <tên_lab_mới>`.<br>- Đóng gói imodule: `create-imodules.sh`, đổi tên thành `<tên_lab_mới>.tar`.<br>- Đẩy lên GitHub repo PTIT bằng PAT.<br>- Lấy raw download link GitHub, chèn vào file hướng dẫn HTML và Thẻ 3. | `labtainer-step-07-publish-imodule` |


---

## 4. QUY TẮC KẾT NỐI VÀ ĐIỀU KHIỂN MÁY TRẠM LABTAINER QUA SSH

Dùng thông số kết nối tại [configuration.md](configuration.md), khi thực thi các bước kỹ thuật (Bước 1, 5, 6, 7), agent áp dụng các quy chuẩn kết nối sau:

### 4.1. Thông Số Môi Trường Kết Nối
- **Host OS:** Windows (PowerShell / OpenSSH).
- **Địa chỉ máy trạm Labtainer:** `labtainer-build (SSH alias cần cấu hình)` (User: `student`, Mật khẩu sudo mặc định: `<mật-khẩu-sudo-của-VM>`).
- **Khóa xác thực SSH Key:** `<ssh-key-path-if-used>`
- **Thư mục gốc Labtainer:** `/home/student/labtainer/trunk`
- **Định danh sinh viên:** `<student_id>`

### 4.2. Cú Pháp Lệnh Thực Thi Từ Host Windows
Luôn sử dụng tùy chọn `-n` khi gọi lệnh `ssh` từ PowerShell hoặc tiến trình nền để tránh bị chặn luồng `stdin`:

```powershell
ssh -n labtainer-build "<chuỗi_lệnh_bash>"
```

### 4.3. Thiết Lập Môi Trường Trước Khi Chạy Lệnh Labtainer
Mọi chuỗi lệnh thao tác với Labtainer trên máy trạm đều cần nạp đường dẫn và biến môi trường:

```bash
export LABTAINER_DIR=/home/student/labtainer/trunk
export PATH=$LABTAINER_DIR/scripts/labtainer-student/bin:$PATH
cd $LABTAINER_DIR/scripts/labtainer-student
```

---

## 5. BỘ CÔNG CỤ TỰ ĐỘNG HÓA CHUẨN (HELPER TOOLKIT)

Để đảm bảo tính nhất quán, khoa học, sạch sẽ và tái sử dụng, **tuyệt đối không tự viết các file script tạm bợ ngoài thư mục gốc**. Mọi tác vụ tự động hóa bắt buộc phải sử dụng bộ công cụ chuẩn tại thư mục `helpers/` (`from helpers import vm, gdocs, lab_parser`) hoặc thông qua CLI nhanh:

### 5.1. Thao tác Google Docs & Drive:
- **Thiết lập 2 Tab chuẩn và khổ A4 + lề 4 hướng:**
  `python -m helpers.cli doc-setup <doc_id> <tên_lab_gốc>`
- **Định dạng bảng A4 trong suốt 100% (Tab 2):**
  `python -m helpers.cli doc-style-tables <doc_id> <tab2_id>`
- **Đăng Native Comments neo kix và bôi vàng:**
  `python -m helpers.cli doc-add-comments <doc_id> <tab1_id> <path/to/comments.json>`
- **Upload ảnh minh chứng lên Google Drive:**
  `python -m helpers.cli drive-upload <path/to/screenshot.png>`

### 5.2. Điều khiển Máy ảo Labtainer (X11 & SSH):
- **Khởi động bài lab (tự động xử lý prompt email sinh viên):**
  `python -m helpers.cli vm-start <tên_lab_gốc> --student-id <student_id>`
- **Gõ lệnh vào terminal container do bài sinh ra:**
  `python -m helpers.cli vm-type <tên_container> "<câu_lệnh>"`
- **Chụp ảnh terminal container:**
  `python -m helpers.cli vm-capture-container <tên_container> <path/to/save.png>`
- **Chạy checkwork và xem kết quả:**
  `python -m helpers.cli vm-checkwork <tên_lab_gốc>`
- **Chụp ảnh terminal máy trạm sinh viên:**
  `python -m helpers.cli vm-capture-student <path/to/save.png>`
- **Dừng bài lab và dọn dẹp container:**
  `python -m helpers.cli vm-stop`
- **Phân tích tĩnh cấu hình bài lab:**
  Sử dụng `helpers.lab_parser` (`parse_start_config`, `parse_goals_config`, `parse_results_config`, `extract_docx_sections`).

## 6. BẢNG KIỂM TRA (CHECKLIST) NGHIỆM THU THEO TỪNG BƯỚC

Mỗi khi thực hiện bất kỳ bước nào trong quy trình chuẩn hóa, agent bắt buộc phải đối soát và hoàn thành đầy đủ tất cả các tiêu chí trong checklist của bước đó trước khi dừng phiên và bàn giao kết quả.

### 6.0. Nguyên tắc chung áp dụng cho mọi bước
- [ ] Tuân thủ đúng phạm vi cô lập (Scope Isolation): Chỉ làm đúng các bước được yêu cầu, tuyệt đối không làm tràn sang các bước khác.
- [ ] Chuẩn mực xưng hô: 100% sử dụng danh xưng sinh viên, tuyệt đối không xưng bạn, chúng ta, người dùng.
- [ ] Quy chuẩn ngôn từ: Không viết hoa tất cả chữ cái đầu ở các tiêu đề mục. Không chèn từ tiếng Anh trong ngoặc đơn sau từ tiếng Việt. Giữ nguyên thuật ngữ kỹ thuật chuyên ngành gốc.
- [ ] Hạn chế dấu ngoặc kép và không dùng dấu gạch ngang dài (em-dash, en-dash).
- [ ] Không dùng đường kẻ phân cách ngang (như ba dấu gạch nối) trong văn bản.
- [ ] Quy chuẩn terminal kỹ thuật: 100% thao tác kỹ thuật thực hiện trên terminal do container bài lab sinh ra. Tuyệt đối không tự tạo terminal mới bên ngoài qua lệnh xterm hay gnome-terminal.
- [ ] Quy chuẩn terminal điều khiển: Lệnh labtainer, checkwork và stoplab bắt buộc thực hiện trên terminal máy trạm sinh viên (`student@LabtainerVMware:~/labtainer/labtainer-student`).
- [ ] Dọn dẹp tài nguyên: Luôn thực thi lệnh stoplab để tắt container ngay khi kết thúc kiểm thử bài lab.

### 6.1. Bước 1: Báo cáo Thẻ 1 - Nhận xét bài lab gốc và kiểm thử hiện trạng
- [ ] Đặt tên file Google Docs đúng chuẩn: `1 - <mã_lab_cũ>`.
- [ ] Khổ giấy in chuẩn A4 (595.3 pt x 841.9 pt). Căn lề chuẩn: Trên 2.0 cm, Dưới 2.0 cm, Trái 2.5 cm, Phải 2.0 cm. Bề rộng in khả dụng tối đa không quá 467.7 pt.
- [ ] Toàn bộ tài liệu sử dụng font Times New Roman, cỡ chữ chuẩn 13pt cho văn bản và tiêu đề (Heading 1 và 2 in đậm; Heading 3 và 4 in đậm nghiêng).
- [ ] Tiêu đề chính đầu trang của Tab 1 in màu đỏ nổi bật (`<mã_lab_cũ>`, font đỏ đậm `#d93025`, 20-22pt, in đậm, căn giữa).
- [ ] Khối lệnh hoặc payload định dạng: chỉ căn giữa (alignment: CENTER), không tô màu xanh lá, không in nghiêng.
- [ ] Tab 1: Đã trích xuất đầy đủ nội dung bài gốc và xóa hoàn toàn thông tin đồ án tốt nghiệp cá nhân, tác giả cũ, chủ đề cũ.
- [ ] Tab 1: Đã loại bỏ hoàn toàn phần kiểm thử hiện trạng và kết quả checkwork ra khỏi nội dung bài gốc.
- [ ] Tab 1: 100% nhận xét audit được gắn bằng Native Comments qua Docs API (neo kix và bôi vàng chính xác đoạn văn bản được nhận xét). Tuyệt đối không để comment inline text trong thân bài.
- [ ] Tab 1: Nội dung nhận xét ngắn gọn, súc tích, đi thẳng vào lỗi kỹ thuật, tuyệt đối không viết dài dòng.
- [ ] Kiểm thử máy ảo: Chạy lệnh theo đúng hướng dẫn trên terminal do container lab sinh ra qua start.config, tuyệt đối không tự mở terminal riêng.
- [ ] Các bước tương tác GUI (Firefox duyệt web, ZAP, Wireshark): Bắt buộc chụp đúng cửa sổ giao diện ứng dụng đó, không chụp terminal gõ lệnh nền.
- [ ] Mở Firefox nếu lỗi sandbox đã thêm biến môi trường `MOZ_DISABLE_CONTENT_SANDBOX=1 firefox &` nhưng vẫn ghi trong hướng dẫn là dùng firefox &.
- [ ] Minh chứng checkwork: Chạy lệnh và chụp màn hình terminal trực tiếp trên máy trạm sinh viên. Ghi nhận trung thực kết quả thực tế, tuyệt đối không can thiệp hoặc làm giả file để ép pass (kết quả Y). Lưu ý: Nếu gặp lỗi hệ thống [ERROR] khiến checkwork không chạy được, hãy kiểm tra và chạy lại; không nhầm lẫn lỗi này với trường hợp bài làm bị đánh giá không đạt (kết quả N).
- [ ] Đã chạy lệnh stoplab để tắt bài lab gốc sau khi hoàn tất kiểm thử. Lưu ý: Nếu gặp lỗi hệ thống [ERROR] khiến stoplab không chạy được, hãy kiểm tra và chạy lại.

### 6.2. Bước 2: Báo cáo Thẻ 2 - Bảng lỗi, CYBOK 1.1, Đánh giá AC và Câu hỏi sinh viên
- [ ] Đưa vào Tab 2 Google Docs, tiêu đề chính đầu trang in màu đỏ nổi bật (`<mã_lab_cũ>`, font đỏ đậm `#d93025`, 20-22pt, in đậm, căn giữa).
- [ ] Giữ đúng khổ giấy in A4, căn lề 4 hướng và font Times New Roman 13pt.
- [ ] Có mục đánh giá hiện trạng bài lab gốc đạt AC hay WA hoặc Error kèm giải thích nguyên nhân kỹ thuật cụ thể.
- [ ] Bảng tổng hợp lỗi gồm 4 cột (32 pt - 180 pt - 180 pt - 73 pt, tổng 465 pt không quá 467.7 pt), viền đen chữ đen, nền ô trong suốt 100%.
- [ ] Bảng thông tin quản lý và CyBOK v1.1 gồm 2 cột (140 pt - 325 pt, tổng 465 pt không quá 467.7 pt), viền đen chữ đen, nền trong suốt 100%, ánh xạ tối thiểu 2-3 môn học tại PTIT.
- [ ] Đầy đủ tối thiểu 3 câu hỏi đánh giá năng lực kèm dòng kẻ trả lời chuẩn: `Trả lời: ___________________________`.
- [ ] Đã lược bỏ hoàn toàn 2 mục văn bản dài về kịch bản doanh nghiệp và liên kết môn học khỏi Tab 2 (các nội dung này chuyển sang file HTML ở Bước 3).
- [ ] Tab giải trình (nếu có sửa code): Bổ sung một tab riêng giải trình chi tiết những nội dung đã sửa kèm ảnh chụp file cấu hình chấm điểm.

### 6.3. Bước 3: Biên soạn Hướng dẫn Thực hành HTML chuẩn hóa và Checklist đối soát
- [ ] Lưu file HTML mới đúng đường dẫn quy định tại thư mục New-HTML: `<tên_môn>/New-HTML/<tên_lab_mới>.html`.
- [ ] Kế thừa đúng khung cấu trúc, font Times New Roman 13pt, độ rộng tối đa 860px và CSS in ấn từ `guide-template.html`.
- [ ] Huy hiệu độ khó ở phần đầu trang đúng màu chuẩn: Dễ (xanh lá), Trung bình (vàng), Khó (đỏ).
- [ ] Khối terminal nền đen (`<pre><span class="cmd">...</span></pre>`) chỉ dùng cho lệnh chuẩn sẵn sàng sao chép chạy ngay.
- [ ] Hộp màu xanh dương (`.box-info`) dùng cho gợi ý câu lệnh cần sinh viên thay thế tham số.
- [ ] Hộp màu xanh lá (`.box-success`) mô tả điều kiện hoàn thành dựa trên tiêu chí kết quả kỹ thuật cụ thể, không ghi máy móc dạng lệnh checkwork trả về trạng thái Y.
- [ ] Hộp màu đỏ hoặc hồng nhạt (`.box-danger`) chứa câu hỏi sinh viên kèm dòng gạch dưới trả lời.
- [ ] Hộp màu vàng (`.box-warning`) dành cho lưu ý quan trọng hoặc cảnh báo an toàn.
- [ ] Khối thông tin tải và khởi động bài lab đặt trong hộp xanh dương theo đúng mẫu imodule của repo <registry-namespace>.
- [ ] Kịch bản thực tế doanh nghiệp 3 phần đầy đủ (Tình huống, Vấn đề an ninh, Vai trò nhiệm vụ sinh viên), trình bày bằng văn bản thường, không bọc trong box.
- [ ] Tiêu đề các nhiệm vụ đúng định dạng chuẩn: `Nhiệm vụ <số> - <mã_checkwork>: <Tên nhiệm vụ>`.
- [ ] Sơ đồ mạng mô tả cấu trúc mạng thuần túy, tuyệt đối không chứa nội dung spoiler cổng ẩn, URL lỗ hổng, bảng CSDL, payload hay luồng tấn công.
- [ ] Đã lược bỏ hoàn toàn mục hướng dẫn kiểm tra và kết thúc ở cuối bài, không đưa lệnh checkwork và stoplab vào các bước nhiệm vụ.
- [ ] Chân trang giữ nguyên thông tin bản quyền của SecLab PTIT.

### 6.4. Bước 4: Báo cáo Thẻ 3, 4, 5 - Kế hoạch kỹ thuật sửa build lab và tổng kết
- [ ] Thẻ 3: Phân tích chi tiết các file cấu hình chấm điểm gốc (`results.config`, `goals.config`, `pregrade.sh`, `start.config`).
- [ ] Thẻ 3: Xác định rõ phương án sửa đổi logic chấm điểm hỗ trợ bắt song song từ file và lịch sử lệnh qua toán tử `file or hist`.
- [ ] Thẻ 3: Khai báo rõ thông tin tài khoản DockerHub tổ chức (`<registry-namespace>`) và kho lưu trữ GitHub của imodule.
- [ ] Thẻ 4: Soạn thảo đầy đủ nội dung nhận xét của người phụ trách theo mẫu.
- [ ] Thẻ 5: Hoàn thiện nhận xét đánh giá giao diện HTML theo checklist đối soát.

### 6.5. Bước 5: Chuẩn bị mã nguồn gốc, cài Java 17, đổi tên lab (`labedit`) và cấu hình
- [ ] Sử dụng đúng file nén mã nguồn gốc (.zip hoặc .rar) đưa vào máy trạm, tuyệt đối không dùng thư mục giải nén từ file imodule cũ.
- [ ] Đặt mã nguồn đúng thư mục: `/home/student/labtainer/trunk/labs/`.
- [ ] Cài đặt Java 17 và khởi động công cụ `labedit`.
- [ ] Đổi tên bài lab sang tên mới chuẩn CyBOK bằng công cụ `labedit`.
- [ ] Cấu hình `config/start.config` đã cập nhật thông số `REGISTRY <registry-namespace>`.
- [ ] Làm sạch toàn bộ tài liệu trong thư mục `docs/` cũ của bài lab và tạo file rỗng `touch docs/read_first.txt`.

### 6.6. Bước 6: Sửa logic chấm điểm, Rebuild Docker, Troubleshooting và kiểm thử checkwork
- [ ] File `instr_config/goals.config` có đầy đủ định nghĩa tất cả các mục tiêu, không để file rỗng.
- [ ] File `instr_config/results.config` đã hỗ trợ kiểm tra linh hoạt song song từ file kết quả và lịch sử lệnh `bash_history` qua toán tử `file or hist`.
- [ ] File `instr_config/pregrade.sh` (nếu có) đã được cấp quyền thực thi và chuyển đổi định dạng dòng bằng `dos2unix`.
- [ ] Rebuild bài lab thành công với tùy chọn `-f`: `rebuild -f <tên_lab_mới>`.
- [ ] Đã xử lý triệt để xung đột Docker hoặc lỗi build Dockerfile nếu có.
- [ ] Khởi động bài lab mới, thực hiện kiểm thử trên terminal container và máy trạm sinh viên, xác nhận 100% các mục tiêu checkwork đều đạt trạng thái `Y`.
- [ ] Chụp ảnh quá trình khởi động bài lab xác nhận hệ thống pull đúng image từ DockerHub `<registry-namespace>` và không còn file docs cũ.
- [ ] Luôn chạy lệnh stoplab để tắt bài lab và dọn dẹp tài nguyên sau khi kết thúc kiểm thử.

### 6.7. Bước 7: Xuất bản DockerHub, đóng gói imodule GitHub và cập nhật liên kết
- [ ] Publish toàn bộ Docker image của bài lab mới lên DockerHub của tổ chức `<registry-namespace>` bằng script `publish.py`.
- [ ] Đóng gói imodule thành công bằng script `create-imodules.sh` và đổi tên thành `<tên_lab_mới>.tar`.
- [ ] Đẩy gói imodule lên đúng repository GitHub của bài lab hoặc môn học tương ứng thuộc tài khoản `<registry-namespace>` bằng PAT.
- [ ] Lấy đường link tải trực tiếp (raw download link) chính xác từ GitHub.
- [ ] Cập nhật câu lệnh imodule chứa link tải thực tế vào khối `.box-info` của file Hướng dẫn Thực hành HTML mới.
- [ ] Cập nhật đường link tải imodule vào Báo cáo Kỹ thuật Thẻ 3.
- [ ] Hoàn tất phát hành và bàn giao HTML đã cập nhật link cho bước 8; chưa kết luận kiểm thử thực tế hoàn tất.




### 6.8. Bước 8: Kết nối máy labtainer-test mới

- [ ] Đọc `.claude/skills/labtainer-step-08-connect-test/SKILL.md` và `configuration.md`; dùng tester <username>@<host> với mật khẩu local, không yêu cầu private key.
- [ ] Nhận HTML trực tiếp hoặc bàn giao sau bước 7 từ `<môn>/New-HTML` sang `<workspace>/html/<môn>/`, đối chiếu SHA-256, bảo toàn nguồn/hồ sơ cũ.
- [ ] Quét queue, SKIP báo cáo đã có, báo CONFLICT đầu ra lỗi/trùng, prepare PENDING.
- [ ] Ghi trạng thái VM/phiên/dữ liệu hiện có rồi tiếp tục, không yêu cầu snapshot sạch hay máy độc lập.
- [ ] Điều khiển/chụp đúng desktop VM test, tải và xem PNG thử; ghi READY/BLOCKED.
- [ ] Không chạy nhiệm vụ khi chỉ được giao bước 8.

### 6.9. Bước 9: Thực thi HTML mới

- [ ] Đọc `.claude/skills/labtainer-step-09-execute-html/SKILL.md`, xác minh hồ sơ bước 8 và hash HTML.
- [ ] Đọc mục kiểm thử thực tế của skill bước 6; tải imodule từ URL bản đã hiệu chỉnh và thực hành lại toàn bộ HTML mới một lần nữa, không chỉ chạy checkwork. Yêu cầu kiểm thử lại dùng hồ sơ/workspace lượt mới để bảo toàn báo cáo cũ và không bị SKIP.
- [ ] Đọc hết HTML, lập đủ bước; tải đúng gói/image phát hành, không chép kết quả/source từ máy build.
- [ ] Thực hiện đúng role/thứ tự/terminal của bài, GUI chụp đúng ứng dụng.
- [ ] Chụp và xem ảnh thật sau từng bước, lưu thời gian/kỳ vọng/thực tế/trạng thái ngay vào manifest.
- [ ] Checkwork trên terminal sinh viên, ảnh đủ goals, .lab thật, stoplab và xác nhận dọn dẹp.
- [ ] PASS/FAIL/BLOCKED theo bằng chứng; không ép Y, không tự sửa HTML/grader, không suy AC từ checkwork.

### 6.10. Bước 10: Báo cáo theo mẫu Word

- [ ] Đọc `.claude/skills/labtainer-step-10-review-report/SKILL.md`, dùng assets/report-template.docx kế thừa.
- [ ] Đối chiếu nguồn/hash/VM/ảnh/checkwork/.lab trước khi render.
- [ ] Giữ bìa/logo/styles/lề/footer mẫu, thay nội dung ví dụ bằng kết quả thực nghiệm.
- [ ] PASS/FAIL xuất `<workspace>/report/<môn>/<lab>.docx`; BLOCKED chỉ checkpoint/draft trong `_work/`.
- [ ] Không ghi đè; báo cáo FAIL cũng được bỏ qua lần sau.
- [ ] Kiểm tra cấu trúc, tiếng Việt, ảnh/chú thích, bố cục nếu có Word/LibreOffice; nêu giới hạn kiểm tra.
- [ ] Scan lại, bàn giao báo cáo/hồ sơ và lỗi cần sửa.

## 7. Môi trường và mẫu ở bước 8–10

Các đường dẫn `/home/student`, tiêu đề `student@LabtainerVMware`, `DISPLAY=:0` ở quy tắc cũ là ví dụ cần đối chiếu theo configuration.md, không phải cấu hình VM đã xác nhận. IP quản trị không lấy từ sơ đồ bài học. Bước 8–10 dùng host tester được cấu hình và helper báo cáo dùng chung trong skill labtainer-spec; không bắt buộc helper Google Docs cho Word. Quy chuẩn Google Docs vẫn dành cho bước 1–4; mẫu nghiệm thu bước 10 là bản Word kế thừa.

## Quy tắc kiểm thử hiện hành (ưu tiên khi hướng dẫn build cũ khác)

- Nhận imodule từ **bất kỳ URL được người dùng giao**, ưu tiên các bài/nguồn `ptitdseclab` khi chọn hoặc xếp hàng. Không giới hạn <registry-namespace>/GitHub và không tự đổi URL đã giao sang tổ chức khác. <registry-namespace> trong bước build/publish hoặc ví dụ cũ không phải điều kiện tiếp nhận kiểm thử.
- Có thể vào thẳng bước 8–10 với URL imodule và HTML hướng dẫn; không cần thực hiện bước 1–7. Nếu chỉ có URL, tìm hướng dẫn trong gói/nguồn liên quan; ghi rõ thiếu hướng dẫn nếu chưa tìm được, không tự bịa các nhiệm vụ.
- Không yêu cầu VM mới, snapshot sạch hay máy độc lập. Ghi trạng thái ban đầu, tiếp tục phiên phù hợp và thực hành tuần tự. Không chặn chỉ vì đã có dữ liệu/image/kết quả cũ; phân biệt kết quả sẵn có với thao tác và ảnh mới trong báo cáo.
- Được tự cài công cụ kết nối, điều khiển/chụp/truyền minh chứng cần thiết **trên host bên ngoài container** (Windows điều phối hoặc host Labtainer), trước khi khởi động bài. Không cần hỏi lại quyền cài này. Kiểm tra và cài đủ ở bước 8; ghi tên/phiên bản và nơi cài. Không cài bổ sung trong container; sau khi bắt đầu thực hành không cài thêm công cụ trên host hay container. Thiếu công cụ lúc đang chạy thì lưu checkpoint, báo bước bị ảnh hưởng, không cài lén để tiếp tục lượt đó.
- Mã sinh viên mặc định: **<student_id>**. Khi xuất hiện prompt email/mã sinh viên, nhập đúng giá trị này; không hỏi lại hoặc tự thêm hậu tố email.
- Thực hiện từng bài, từng bước theo HTML, chụp/xem ảnh thật sau từng bước, lưu log/checkwork/.lab. Báo cáo sinh trên Windows tại thư mục người dùng đã chỉ định; nếu chưa chỉ định riêng, dùng `<workspace>/report/<môn>/<lab>.docx`.
- Dùng `.claude/skills/labtainer-step-10-review-report/assets/report-template.docx`, bản chuẩn hóa từ `Mẫu báo cáo thực hành.docx` của học viện: giữ bìa, logo, styles, lề, footer; thay nội dung mẫu bằng thực nghiệm. Không đổi sang template HTML hay mẫu tự thiết kế.
