# HƯỚNG DẪN SỬ DỤNG BỘ HELPER TOOLKIT CHO AGENT (SECLAB PTIT)

Bộ thư viện helper tại `<skill-dir>/scripts/helpers/` được xây dựng nhằm giúp Agent thực hiện nhanh các tác vụ chuẩn hóa bài lab mà **không cần phải viết lại code từ đầu sau mỗi bài**.

---

## 1. CÁCH SỬ DỤNG TRỰC TIẾP TRONG PYTHON

Trong bất kỳ script Python nào của bài lab, Agent chỉ cần import trực tiếp:

```python
from helpers import vm, gdocs, lab_parser

# Hoặc import từng hàm:
from helpers.vm import (
    start_lab, stop_lab, run_checkwork,
    capture_student_terminal, capture_container_terminal, capture_window,
    type_terminal, switch_terminal_tab, get_container_wid, get_student_terminal_wid
)
from helpers.gdocs import (
    setup_standard_tabs, setup_page_a4_margins, set_red_header,
    style_tables_a4, upload_image_to_drive, post_all_comments,
    clear_tab_content, get_doc, batch_update
)
from helpers.lab_parser import parse_start_config, parse_goals_config, parse_results_config, extract_docx_sections
```

---

## 2. CÁCH SỬ DỤNG QUA CLI (DÒNG LỆNH POWERSHELL NHANH)

Agent có thể chạy ngay qua công cụ `run_command` mà không cần viết script Python tạm:

### Google Docs & Drive:
1. **Thiết lập 2 Tab chuẩn và khổ A4 + lề 4 hướng (tiêu đề in đỏ căn giữa):**
   ```powershell
   python -m helpers.cli doc-setup <doc_id> <lab_name>
   ```
2. **Căn chỉnh độ rộng cột và xóa màu nền ô bảng Tab 2 trong suốt 100%:**
   ```powershell
   python -m helpers.cli doc-style-tables <doc_id> <tab2_id>
   ```
3. **Chuẩn hóa Typography toàn Tab (Times New Roman 13pt, h1-h4, code chỉ căn giữa):**
   ```powershell
   python -m helpers.cli doc-format-typography <doc_id> <tab_id>
   ```
4. **Đăng Native Comments neo kix và bôi vàng từ file JSON:**
   ```powershell
   python -m helpers.cli doc-add-comments <doc_id> <tab1_id> path/to/comments.json
   ```
5. **Upload ảnh chụp lên Google Drive và lấy direct URL:**
   ```powershell
   python -m helpers.cli drive-upload path/to/screenshot.png
   ```

### Máy ảo Labtainer & xdotool:
1. **Khởi động bài lab (tự động điền mã SV khi có email prompt):**
   ```powershell
   python -m helpers.cli vm-start <lab_name> --student-id <student_id>
   ```
2. **Chụp ảnh terminal sinh viên (checkwork / stoplab):**
   ```powershell
   python -m helpers.cli vm-capture-student path/to/save.png
   ```
3. **Chụp ảnh terminal container (attacker, victim...):**
   ```powershell
   python -m helpers.cli vm-capture-container <container_name> path/to/save.png
   ```
4. **Gõ lệnh vào terminal container do bài lab sinh ra:**
   ```powershell
   python -m helpers.cli vm-type <container_name> "nmap -sCV 172.16.10.5"
   ```
5. **Chạy checkwork và xem kết quả:**
   ```powershell
   python -m helpers.cli vm-checkwork <lab_name>
   ```
6. **Dừng bài lab và dọn dẹp môi trường container:**
   ```powershell
   python -m helpers.cli vm-stop
   ```

---

## 3. BẢNG TỔNG HỢP CÔNG VIỆC TỪNG BƯỚC VÀ HELPER TƯƠNG ỨNG

| Bước | Tác vụ | Helper Python | Lệnh CLI nhanh |
| :--- | :--- | :--- | :--- |
| **Bước 1** | Phân tích start.config | `lab_parser.parse_start_config` | - |
| | Khởi động lab trên VM | `vm.start_lab(lab_name)` | `python -m helpers.cli vm-start <lab>` |
| | Thao tác lệnh & chụp ảnh container | `vm.type_terminal`, `vm.capture_container_terminal` | `python -m helpers.cli vm-capture-container <c> <out>` |
| | Chạy checkwork & chụp terminal SV | `vm.run_checkwork`, `vm.capture_student_terminal` | `python -m helpers.cli vm-capture-student <out>` |
| | Stop lab dọn dẹp | `vm.stop_lab()` | `python -m helpers.cli vm-stop` |
| | Upload ảnh minh chứng lên Drive | `gdocs.upload_image_to_drive` | `python -m helpers.cli drive-upload <file>` |
| | Setup Tab 1 & Red Header | `gdocs.setup_standard_tabs`, `gdocs.set_red_header` | `python -m helpers.cli doc-setup <doc_id> <lab>` |
| | Gắn Native Comments neo kix | `gdocs.post_all_comments` | `python -m helpers.cli doc-add-comments <doc> <tab> <json>` |
| **Bước 2** | Định dạng bảng Tab 2 chuẩn A4 trong suốt | `gdocs.style_tables_a4` | `python -m helpers.cli doc-style-tables <doc> <tab>` |
| **Bước 5-6** | Phân tích goals/results config | `lab_parser.parse_goals_config`, `parse_results_config` | - |

## Cấu hình hiện tại và helper bước 8–10

Đọc [configuration.md](configuration.md). `helpers.vm` đọc LABTAINER_SSH_TARGET (không có host mặc định), LABTAINER_SSH_KEY (tùy chọn), LABTAINER_DISPLAY, LABTAINER_STUDENT_WINDOW, LABTAINER_STUDENT_ID. Đặt biến trước khi import. `helpers.gdocs` đọc GDOCS_TOKEN_PATH.

Bước 8–9 chọn labtainer-test và xác minh VM độc lập; thao tác từng prompt theo skill bước 9. Helper queue/render/schema/mẫu Word ở `scripts/` trong skill labtainer-spec. capture_screen phải chạy trên Linux VM; Windows dùng chụp remote đã kiểm tra và SCP về run-dir, không chụp màn hình Windows thay VM.

## Backend mật khẩu cho tester trong Claude Code

Tester là <username>@<host>:<port>. Nạp LABTAINER_SSH_AUTH=password và LABTAINER_SSH_PASSWORD từ biến môi trường được `connection.password_env` trong config chỉ định theo configuration.md. Backend này dùng Paramiko trên Windows, tắt tìm private key/SSH agent, dùng host key đã xác minh và SFTP để chuyển ảnh/.lab. Backend OpenSSH BatchMode chỉ dành cho cấu hình máy build dùng key/agent; không dùng nó để đăng nhập password tester. Queue và render chạy local, không copy bộ render lên VM.
