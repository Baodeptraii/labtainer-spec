"""Offline checks: password transport never connects to a real VM."""
import os
import sys
import unittest
from unittest.mock import MagicMock, patch

from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from helpers.vm import VMClient


class PasswordTransportTests(unittest.TestCase):
    def setUp(self):
        self.env = patch.dict(os.environ, {
            "LABTAINER_SSH_AUTH": "password",
            "LABTAINER_SSH_PASSWORD": "fixture-only",
            "LABTAINER_KNOWN_HOSTS": "fixture-known-hosts",
            "LABTAINER_SSH_PORT": "22",
        })
        self.env.start()
        self.addCleanup(self.env.stop)
        self.paramiko = MagicMock()
        self.modules = patch.dict(sys.modules, {"paramiko": self.paramiko})
        self.modules.start()
        self.addCleanup(self.modules.stop)
        self.client = self.paramiko.SSHClient.return_value
        self.vm = VMClient(target="student@192.0.2.10", key_path="")

    def test_password_auth_disables_key_and_agent_and_checks_host(self):
        stdout = MagicMock()
        stdout.read.return_value = b"tester\n"
        stdout.channel.recv_exit_status.return_value = 0
        self.client.exec_command.return_value = (MagicMock(), stdout, MagicMock())
        self.assertEqual(self.vm.run_ssh("hostname"), "tester\n")
        args = self.client.connect.call_args.kwargs
        self.assertEqual(args["hostname"], "192.0.2.10")
        self.assertEqual(args["username"], "student")
        self.assertFalse(args["look_for_keys"])
        self.assertFalse(args["allow_agent"])
        self.client.load_host_keys.assert_called_once_with("fixture-known-hosts")
        self.client.set_missing_host_key_policy.assert_called_once_with(
            self.paramiko.RejectPolicy.return_value
        )
        self.client.close.assert_called_once()

    def test_remote_failure_is_not_reported_as_success(self):
        stdout = MagicMock()
        stdout.read.return_value = b"command failed"
        stdout.channel.recv_exit_status.return_value = 7
        self.client.exec_command.return_value = (MagicMock(), stdout, MagicMock())
        with self.assertRaisesRegex(RuntimeError, "failed \\(7\\)"):
            self.vm.run_ssh("false")
        self.client.close.assert_called_once()

    def test_password_transfer_uses_sftp(self):
        self.assertTrue(self.vm.scp_to_vm("local file.png", "/tmp/file.png"))
        self.client.open_sftp.return_value.__enter__.return_value.put.assert_called_once_with(
            "local file.png", "/tmp/file.png"
        )

    def test_connection_failure_closes_client(self):
        self.client.connect.side_effect = OSError("connection failed")
        with self.assertRaises(OSError):
            self.vm.run_ssh("hostname")
        self.client.close.assert_called_once()


if __name__ == "__main__":
    unittest.main()
