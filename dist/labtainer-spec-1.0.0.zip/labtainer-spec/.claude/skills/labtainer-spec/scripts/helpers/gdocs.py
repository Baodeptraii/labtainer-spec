"""
Module: helpers.gdocs
Thao tác Google Docs và Google Drive API tự động hóa cho quy trình chuẩn hóa SecLab PTIT.
Tuân thủ nghiêm ngặt các quy tắc:
- Tự động lấy và refresh OAuth token từ token.json.
- Thiết lập định dạng A4 và 4 lề chuẩn (Top 56.7, Bottom 56.7, Left 70.9, Right 56.7 pt).
- Thiết lập 2 Tab chuẩn (Tab 1: Nhận xét chung, Tab 2: Tổng hợp lỗi, minh chứng, đề xuất).
- Tiêu đề in ĐỎ đậm 22pt (#d93025).
- Định dạng bảng A4 trong suốt 100%, căn chỉnh độ rộng cột chuẩn (32-180-180-73 và 140-325 pt).
- Upload ảnh chụp lên Google Drive, set public reader.
- Chèn Native Comments neo chính xác bằng kix anchor, bôi vàng text, không bao giờ bị lỗi "Đã xóa nội dung gốc".
"""

import os
import sys
import json
import urllib.parse
import urllib.request
import subprocess
from typing import Optional, List, Dict, Tuple, Any

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

TOKEN_PATH = os.environ.get("GDOCS_TOKEN_PATH", "")


def refresh_token_now(token_path: str = TOKEN_PATH) -> str:
    """Làm mới Access Token khi hết hạn."""
    with open(token_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    client_id = data["client_id"]
    client_secret = data["client_secret"]
    refresh_tok = data["token"]["refresh_token"]

    url = "https://oauth2.googleapis.com/token"
    payload = urllib.parse.urlencode({
        "client_id": client_id,
        "client_secret": client_secret,
        "refresh_token": refresh_tok,
        "grant_type": "refresh_token"
    }).encode("utf-8")
    req = urllib.request.Request(url, data=payload, method="POST")
    with urllib.request.urlopen(req) as resp:
        res = json.loads(resp.read().decode("utf-8"))
        new_token = res["access_token"]

    data["token"]["access_token"] = new_token
    with open(token_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    return new_token


def get_access_token(token_path: str = TOKEN_PATH) -> str:
    """Lấy Access Token hiện tại từ token.json."""
    with open(token_path, "r", encoding="utf-8") as f:
        tok = json.load(f)
    return tok["token"]["access_token"]


def api_request(url: str, method: str = "GET", data: Optional[Dict[str, Any]] = None, token_path: str = TOKEN_PATH) -> Dict[str, Any]:
    """Gửi HTTP Request đến Google API có cơ chế tự động refresh token khi gặp 401."""
    token = get_access_token(token_path)
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    body = json.dumps(data).encode("utf-8") if data else None
    req = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req) as resp:
            content = resp.read().decode("utf-8")
            return json.loads(content) if content else {}
    except urllib.error.HTTPError as e:
        if e.code == 401:
            print("[GDocsHelper] Token expired (401), refreshing token...")
            token = refresh_token_now(token_path)
            headers["Authorization"] = f"Bearer {token}"
            req2 = urllib.request.Request(url, data=body, headers=headers, method=method)
            with urllib.request.urlopen(req2) as resp:
                content = resp.read().decode("utf-8")
                return json.loads(content) if content else {}
        raise


def get_doc(doc_id: str) -> Dict[str, Any]:
    """Lấy toàn bộ nội dung của Google Doc (bao gồm tất cả các tabs)."""
    return api_request(f"https://docs.googleapis.com/v1/documents/{doc_id}?includeTabsContent=true")


def batch_update(doc_id: str, requests: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Gọi batchUpdate API trên Google Docs."""
    if not requests:
        return {}
    return api_request(f"https://docs.googleapis.com/v1/documents/{doc_id}:batchUpdate", method="POST", data={"requests": requests})


def setup_standard_tabs(doc_id: str) -> Dict[str, str]:
    """
    Thiết lập 2 Tab chuẩn:
    - Tab 1: 'Báo cáo 1: Nhận xét chung về bài lab'
    - Tab 2: 'Báo cáo 2: Tổng hợp lỗi, minh chứng, đề xuất'
    Trả về: {'tab1_id': '...', 'tab2_id': '...'}
    """
    doc = get_doc(doc_id)
    tabs = doc.get("tabs", [])
    if not tabs:
        raise ValueError(f"Document {doc_id} has no tabs!")

    tab1_id = tabs[0]["tabProperties"]["tabId"]
    tab2_id = None
    for t in tabs:
        t_id = t["tabProperties"]["tabId"]
        if t_id != tab1_id:
            tab2_id = t_id
            break

    requests = []
    # Cập nhật tên Tab 1
    requests.append({
        "updateTabProperties": {
            "tabProperties": {
                "tabId": tab1_id,
                "title": "Báo cáo 1: Nhận xét chung về bài lab"
            },
            "fields": "title"
        }
    })

    if not tab2_id:
        print("[GDocsHelper] Tab 2 not found, creating new Tab 2...")
        req_add = {
            "addTab": {
                "tabProperties": {
                    "title": "Báo cáo 2: Tổng hợp lỗi, minh chứng, đề xuất"
                }
            }
        }
        res = batch_update(doc_id, [req_add])
        tab2_id = res["replies"][0]["addTab"]["tabProperties"]["tabId"]
    else:
        requests.append({
            "updateTabProperties": {
                "tabProperties": {
                    "tabId": tab2_id,
                    "title": "Báo cáo 2: Tổng hợp lỗi, minh chứng, đề xuất"
                },
                "fields": "title"
            }
        })

    if requests:
        batch_update(doc_id, requests)

    print(f"[GDocsHelper] Standard tabs configured: Tab 1 = {tab1_id}, Tab 2 = {tab2_id}")
    return {"tab1_id": tab1_id, "tab2_id": tab2_id}


def setup_page_a4_margins(doc_id: str) -> None:
    """
    Cài đặt tài liệu theo chuẩn in A4:
    - Kích thước: A4 (595.3 x 841.9 pt)
    - 4 lề: Top 56.7 pt (2.0 cm), Bottom 56.7 pt (2.0 cm), Left 70.9 pt (2.5 cm), Right 56.7 pt (2.0 cm)
    """
    style_req = {
        "updateDocumentStyle": {
            "documentStyle": {
                "pageSize": {
                    "width": {"magnitude": 595.3, "unit": "PT"},
                    "height": {"magnitude": 841.9, "unit": "PT"}
                },
                "marginTop": {"magnitude": 56.7, "unit": "PT"},
                "marginBottom": {"magnitude": 56.7, "unit": "PT"},
                "marginLeft": {"magnitude": 70.9, "unit": "PT"},
                "marginRight": {"magnitude": 56.7, "unit": "PT"}
            },
            "fields": "pageSize,marginTop,marginBottom,marginLeft,marginRight"
        }
    }
    batch_update(doc_id, [style_req])
    print("[GDocsHelper] Page size set to A4 and margins configured successfully.")


def set_red_header(doc_id: str, tab_id: str, lab_name: str, subtext: Optional[str] = None) -> None:
    """
    Thêm tiêu đề đầu trang in ĐỎ nổi bật (#d93025, 22pt, Bold) CĂN GIỮA (alignment: CENTER) theo đúng quy chuẩn.
    """
    header_text = f"{lab_name}\n"
    full_insert = header_text
    if subtext:
        full_insert += f"{subtext}\n\n"

    reqs = [
        {
            "insertText": {
                "location": {"tabId": tab_id, "index": 1},
                "text": full_insert
            }
        },
        {
            "updateParagraphStyle": {
                "range": {"tabId": tab_id, "startIndex": 1, "endIndex": len(header_text)},
                "paragraphStyle": {
                    "namedStyleType": "HEADING_1",
                    "alignment": "CENTER"
                },
                "fields": "namedStyleType,alignment"
            }
        },
        {
            "updateTextStyle": {
                "range": {"tabId": tab_id, "startIndex": 1, "endIndex": len(header_text)},
                "textStyle": {
                    "bold": True,
                    "fontSize": {"magnitude": 22, "unit": "PT"},
                    "weightedFontFamily": {"fontFamily": "Times New Roman"},
                    "foregroundColor": {"color": {"rgbColor": {"red": 0.85, "green": 0.19, "blue": 0.15}}}
                },
                "fields": "bold,fontSize,foregroundColor,weightedFontFamily"
            }
        }
    ]
    if subtext:
        sub_start = len(header_text)
        sub_end = len(full_insert)
        reqs.append({
            "updateParagraphStyle": {
                "range": {"tabId": tab_id, "startIndex": sub_start, "endIndex": sub_end},
                "paragraphStyle": {"alignment": "CENTER"},
                "fields": "alignment"
            }
        })
        reqs.append({
            "updateTextStyle": {
                "range": {"tabId": tab_id, "startIndex": sub_start, "endIndex": sub_end},
                "textStyle": {
                    "fontSize": {"magnitude": 13, "unit": "PT"},
                    "italic": True,
                    "weightedFontFamily": {"fontFamily": "Times New Roman"}
                },
                "fields": "fontSize,italic,weightedFontFamily"
            }
        })

    batch_update(doc_id, reqs)
    print(f"[GDocsHelper] Red centered header set for '{lab_name}' in tab {tab_id}.")


def clear_tab_content(doc_id: str, tab_id: str) -> None:
    """Xóa an toàn nội dung cũ của một tab."""
    doc = get_doc(doc_id)
    doc_len = 1
    for tab in doc.get("tabs", []):
        if tab.get("tabProperties", {}).get("tabId") == tab_id:
            body = tab.get("documentTab", {}).get("body", {})
            for el in body.get("content", []):
                if "endIndex" in el and el["endIndex"] > doc_len:
                    doc_len = el["endIndex"]
            break

    if doc_len > 15:
        del_req = {
            "deleteContentRange": {
                "range": {"tabId": tab_id, "startIndex": 1, "endIndex": doc_len - 1}
            }
        }
        batch_update(doc_id, [del_req])
        print(f"[GDocsHelper] Cleared content in tab {tab_id} (length was {doc_len}).")


def style_tables_a4(
    doc_id: str,
    tab_id: str,
    table1_widths: Tuple[int, int, int, int] = (32, 180, 180, 73),
    table2_widths: Tuple[int, int] = (140, 325)
) -> None:
    """
    Căn chỉnh độ rộng cột các bảng ở Tab 2 vừa vặn A4 (<= 467.7 pt)
    và xóa sạch màu nền ô bảng (nền trong suốt 100%).
    """
    # 1. Chỉnh độ rộng cột qua gdocs CLI nếu có
    w1_str = ",".join(map(str, table1_widths))
    w2_str = ",".join(map(str, table2_widths))
    subprocess.run(
        f"gdocs mutate style-table-columns {doc_id} --tab {tab_id} --table 1 --col-widths {w1_str}",
        shell=True, capture_output=True, text=True, errors="replace"
    )
    subprocess.run(
        f"gdocs mutate style-table-columns {doc_id} --tab {tab_id} --table 2 --col-widths {w2_str}",
        shell=True, capture_output=True, text=True, errors="replace"
    )

    # 2. Xóa 100% màu nền ô bảng thành trong suốt
    doc = get_doc(doc_id)
    bg_clear_reqs = []
    for tab in doc.get("tabs", []):
        t_id = tab["tabProperties"]["tabId"]
        if t_id != tab_id:
            continue
        body = tab.get("documentTab", {}).get("body", {})
        for el in body.get("content", []):
            if "table" in el:
                table_start = el.get("startIndex")
                bg_clear_reqs.append({
                    "updateTableCellStyle": {
                        "tableCellStyle": {},
                        "fields": "backgroundColor",
                        "tableStartLocation": {"tabId": t_id, "index": table_start}
                    }
                })

    if bg_clear_reqs:
        batch_update(doc_id, bg_clear_reqs)
        print(f"[GDocsHelper] Cleared backgrounds to transparent for {len(bg_clear_reqs)} tables.")


def upload_image_to_drive(file_path: str, filename: Optional[str] = None, token_path: str = TOKEN_PATH) -> str:
    """
    Tải ảnh lên Google Drive, phân quyền public reader, trả về direct download link:
    https://drive.google.com/uc?export=download&id=<file_id>
    """
    token = get_access_token(token_path)
    if not filename:
        filename = os.path.basename(file_path)

    with open(file_path, "rb") as f:
        img_bytes = f.read()

    metadata = {"name": filename, "mimeType": "image/png"}
    boundary = "-------314159265358979323846"
    delimiter = f"\r\n--{boundary}\r\n"
    close_delim = f"\r\n--{boundary}--"
    body = (
        f"{delimiter}Content-Type: application/json; charset=UTF-8\r\n\r\n{json.dumps(metadata)}"
        f"{delimiter}Content-Type: image/png\r\n\r\n"
    ).encode("utf-8") + img_bytes + close_delim.encode("utf-8")

    upload_url = "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart"
    req = urllib.request.Request(upload_url, data=body, headers={
        "Authorization": f"Bearer {token}",
        "Content-Type": f"multipart/related; boundary={boundary}"
    })
    with urllib.request.urlopen(req) as resp:
        res = json.loads(resp.read().decode("utf-8"))
        file_id = res["id"]

    # Phân quyền public reader
    perm_url = f"https://www.googleapis.com/drive/v3/files/{file_id}/permissions"
    perm_body = json.dumps({"role": "reader", "type": "anyone"}).encode("utf-8")
    perm_req = urllib.request.Request(perm_url, data=perm_body, headers={
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    })
    with urllib.request.urlopen(perm_req) as resp:
        pass

    direct_url = f"https://drive.google.com/uc?export=download&id={file_id}"
    print(f"[GDocsHelper] Uploaded {filename} -> {direct_url}")
    return direct_url


def clear_all_comments(doc_id: str, token_path: str = TOKEN_PATH) -> int:
    """Xóa sạch các comment cũ trên Google Doc."""
    token = get_access_token(token_path)
    comm_url = f"https://www.googleapis.com/drive/v3/files/{doc_id}/comments?fields=comments(id)"
    c_req = urllib.request.Request(comm_url, headers={"Authorization": f"Bearer {token}"})
    with urllib.request.urlopen(c_req) as resp:
        c_res = json.loads(resp.read().decode("utf-8"))

    count = 0
    for c in c_res.get("comments", []):
        del_url = f"https://www.googleapis.com/drive/v3/files/{doc_id}/comments/{c['id']}"
        del_req = urllib.request.Request(del_url, method="DELETE", headers={"Authorization": f"Bearer {token}"})
        try:
            urllib.request.urlopen(del_req)
            count += 1
        except Exception:
            pass
    print(f"[GDocsHelper] Cleared {count} old comments from document {doc_id}.")
    return count


def get_tab_text_map(doc_id: str, tab_id: str) -> Tuple[str, List[int], List[Any]]:
    """
    Quét nội dung của một tab trong Google Docs để tạo bản đồ chỉ mục ký tự (index map).
    Trả về: (full_text, index_map, elements_info)
    """
    doc = get_doc(doc_id)
    tab_content = []
    for tab in doc.get("tabs", []):
        if tab.get("tabProperties", {}).get("tabId") == tab_id:
            tab_content = tab.get("documentTab", {}).get("body", {}).get("content", [])
            break

    elements_info = []
    for el in tab_content:
        if "paragraph" in el:
            p = el["paragraph"]
            for pe in p.get("elements", []):
                st = pe.get("startIndex")
                et = pe.get("endIndex")
                txt = pe.get("textRun", {}).get("content", "")
                if txt:
                    elements_info.append((st, et, txt))

    full_text = ""
    index_map = []
    for st, et, txt in elements_info:
        for offset, ch in enumerate(txt):
            index_map.append(st + offset)
            full_text += ch

    return full_text, index_map, elements_info


def post_native_comment(
    doc_id: str,
    tab_id: str,
    snippet: str,
    comment_text: str,
    highlight: bool = True,
    full_text: Optional[str] = None,
    index_map: Optional[List[int]] = None,
    token_path: str = TOKEN_PATH
) -> bool:
    """
    Gắn Native Comment vào văn bản với anchor kix chính xác và bôi vàng đoạn text.
    Không bao giờ gây lỗi 'Đã xóa nội dung gốc'.
    """
    if full_text is None or index_map is None:
        full_text, index_map, _ = get_tab_text_map(doc_id, tab_id)

    pos = full_text.find(snippet)
    if pos == -1:
        print(f"[GDocsHelper] WARNING: Snippet not found in tab {tab_id}: {repr(snippet)}")
        return False

    st = index_map[pos]
    et = index_map[pos + len(snippet)]

    # 1. Bôi vàng văn bản (Yellow Highlight)
    if highlight:
        yellow_highlight = {"backgroundColor": {"color": {"rgbColor": {"red": 1.0, "green": 0.95, "blue": 0.6}}}}
        batch_update(doc_id, [{
            "updateTextStyle": {
                "range": {"tabId": tab_id, "startIndex": st, "endIndex": et},
                "textStyle": yellow_highlight,
                "fields": "backgroundColor"
            }
        }])

    # 2. Tạo native comment neo kix trực tiếp qua Google Docs API batchUpdate
    token = get_access_token(token_path)
    batch_url = f"https://docs.googleapis.com/v1/documents/{doc_id}:batchUpdate"
    payload = json.dumps({
        "requests": [{
            "insertComment": {
                "content": comment_text,
                "range": {
                    "tabId": tab_id,
                    "startIndex": st,
                    "endIndex": et
                }
            }
        }]
    }).encode("utf-8")

    req = urllib.request.Request(batch_url, data=payload, headers={
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    })
    try:
        with urllib.request.urlopen(req) as resp:
            pass
        print(f"[GDocsHelper] Successfully anchored native Docs comment on: {repr(snippet[:40])}...")
        return True
    except Exception as e:
        print(f"[GDocsHelper] Failed to anchor comment: {e}")
        return False


def post_all_comments(doc_id: str, tab_id: str, comments_list: List[Dict[str, str]], clear_old: bool = True) -> int:
    """
    Đăng toàn bộ danh sách nhận xét native comments cho một tab.
    Mỗi phần tử trong comments_list gồm: {'snippet': '...', 'comment': '...'}
    """
    if clear_old:
        clear_all_comments(doc_id)

    # Lấy fresh text mapping
    full_text, index_map, _ = get_tab_text_map(doc_id, tab_id)
    success_count = 0

    for item in comments_list:
        snip = item.get("snippet", "")
        comm = item.get("comment", "")
        if not snip or not comm:
            continue
        ok = post_native_comment(
            doc_id=doc_id,
            tab_id=tab_id,
            snippet=snip,
            comment_text=comm,
            highlight=True,
            full_text=full_text,
            index_map=index_map
        )
        if ok:
            success_count += 1

    print(f"[GDocsHelper] Posted {success_count}/{len(comments_list)} native comments successfully.")
    return success_count


def format_code_range(doc_id: str, tab_id: str, start_index: int, end_index: int) -> None:
    """
    Định dạng một đoạn văn bản là code theo đúng quy chuẩn:
    - Chỉ căn giữa (alignment: CENTER).
    - Giữ nguyên màu chữ đen tiêu chuẩn, font Times New Roman cỡ 13pt (không tô màu xanh lá, không in nghiêng).
    """
    reqs = [
        {
            "updateParagraphStyle": {
                "range": {"tabId": tab_id, "startIndex": start_index, "endIndex": end_index},
                "paragraphStyle": {"alignment": "CENTER"},
                "fields": "alignment"
            }
        },
        {
            "updateTextStyle": {
                "range": {"tabId": tab_id, "startIndex": start_index, "endIndex": end_index},
                "textStyle": {
                    "italic": False,
                    "fontSize": {"magnitude": 13, "unit": "PT"},
                    "weightedFontFamily": {"fontFamily": "Times New Roman"},
                    "foregroundColor": {"color": {"rgbColor": {"red": 0.0, "green": 0.0, "blue": 0.0}}}
                },
                "fields": "italic,fontSize,weightedFontFamily,foregroundColor"
            }
        }
    ]
    batch_update(doc_id, reqs)
    print(f"[GDocsHelper] Formatted code range [{start_index}:{end_index}] in tab {tab_id} (Only Center).")


def is_probable_code_text(text: str) -> bool:
    """Nhận diện xem một đoạn văn bản có phải là câu lệnh hoặc mã nguồn / cấu hình không."""
    stripped = text.strip()
    if not stripped:
        return False
    # Tiền tố dòng lệnh
    code_prefixes = (
        "$ ", "# ", "ubuntu@", "student@", "root@", "> ", "psql", "mysql",
        "imodule ", "labtainer ", "checkwork", "stoplab", "rebuild ",
        "nmap ", "curl ", "chmod ", "cat ", "ls ", "cd ", "python ", "python3 ",
        "ssh ", "nc ", "echo ", "grep ", "export ", "export LABTAINER",
        "sudo ", "find ", "wget ", "ping ", "tar ", "unzip ",
        "dirsearch", "firefox", "git ", "sqlmap ", "gobuster "
    )
    for pref in code_prefixes:
        if stripped.startswith(pref):
            return True

    # Cấu hình goals/results hoặc file config
    if (" = matchany :" in stripped or " = boolean :" in stripped or 
        " : CONTAINS :" in stripped or " : string_equal :" in stripped):
        return True

    return False


def format_tab_typography(doc_id: str, tab_id: str, auto_detect_code: bool = True) -> None:
    """
    Tự động chuẩn hóa toàn bộ Typography của một Tab theo đúng quy chuẩn SecLab PTIT:
    1. Toàn bộ font: Times New Roman.
    2. Toàn bộ text thông thường: cỡ chữ 13pt.
    3. Headings h1, h2: 13pt, in đậm (bold).
    4. Headings h3, h4: 13pt, in đậm + in nghiêng (bold + italic).
    5. Code / Khối lệnh: Chỉ căn giữa (CENTER), font Times New Roman 13pt tiêu chuẩn (không tô màu xanh lá, không in nghiêng).
    """
    doc = get_doc(doc_id)
    target_tab = None
    for tab in doc.get("tabs", []):
        if tab.get("tabProperties", {}).get("tabId") == tab_id:
            target_tab = tab
            break

    if not target_tab:
        print(f"[GDocsHelper] Tab {tab_id} not found in doc {doc_id}.")
        return

    content = target_tab.get("documentTab", {}).get("body", {}).get("content", [])
    if not content:
        return

    requests = []
    for el in content:
        p = el.get("paragraph")
        if not p:
            continue
        st = el.get("startIndex", 0)
        en = el.get("endIndex", 0)
        if st >= en or st < 1:
            continue

        p_style = p.get("paragraphStyle", {})
        named_style = p_style.get("namedStyleType", "NORMAL_TEXT")

        # Bỏ qua dòng tiêu đề chính ở đầu trang (nếu đã là tiêu đề Đỏ cỡ 20-22pt)
        if st == 1:
            # Kiểm tra xem đây có phải tiêu đề bài lab đỏ không
            is_title = False
            for elem in p.get("elements", []):
                t_run = elem.get("textRun", {})
                size = t_run.get("textStyle", {}).get("fontSize", {}).get("magnitude", 0)
                if size >= 18:
                    is_title = True
                    break
            if is_title:
                continue

        # Lấy toàn bộ text của paragraph
        p_text = "".join(elem.get("textRun", {}).get("content", "") for elem in p.get("elements", []))

        # 1. Heading 1 & Heading 2: 13pt, Bold, Căn trái (START)
        if named_style in ("HEADING_1", "HEADING_2"):
            requests.append({
                "updateParagraphStyle": {
                    "range": {"tabId": tab_id, "startIndex": st, "endIndex": en},
                    "paragraphStyle": {"alignment": "START"},
                    "fields": "alignment"
                }
            })
            requests.append({
                "updateTextStyle": {
                    "range": {"tabId": tab_id, "startIndex": st, "endIndex": en},
                    "textStyle": {
                        "bold": True,
                        "italic": False,
                        "fontSize": {"magnitude": 13, "unit": "PT"},
                        "weightedFontFamily": {"fontFamily": "Times New Roman"}
                    },
                    "fields": "bold,italic,fontSize,weightedFontFamily"
                }
            })
        # 2. Heading 3 & Heading 4: 13pt, Bold + Italic, Căn trái (START)
        elif named_style in ("HEADING_3", "HEADING_4"):
            requests.append({
                "updateParagraphStyle": {
                    "range": {"tabId": tab_id, "startIndex": st, "endIndex": en},
                    "paragraphStyle": {"alignment": "START"},
                    "fields": "alignment"
                }
            })
            requests.append({
                "updateTextStyle": {
                    "range": {"tabId": tab_id, "startIndex": st, "endIndex": en},
                    "textStyle": {
                        "bold": True,
                        "italic": True,
                        "fontSize": {"magnitude": 13, "unit": "PT"},
                        "weightedFontFamily": {"fontFamily": "Times New Roman"}
                    },
                    "fields": "bold,italic,fontSize,weightedFontFamily"
                }
            })
        # 3. Code khối lệnh: Căn giữa (CENTER)
        elif auto_detect_code and is_probable_code_text(p_text):
            requests.append({
                "updateParagraphStyle": {
                    "range": {"tabId": tab_id, "startIndex": st, "endIndex": en},
                    "paragraphStyle": {"alignment": "CENTER"},
                    "fields": "alignment"
                }
            })
            requests.append({
                "updateTextStyle": {
                    "range": {"tabId": tab_id, "startIndex": st, "endIndex": en},
                    "textStyle": {
                        "italic": False,
                        "bold": False,
                        "fontSize": {"magnitude": 13, "unit": "PT"},
                        "weightedFontFamily": {"fontFamily": "Times New Roman"},
                        "foregroundColor": {"color": {"rgbColor": {"red": 0.0, "green": 0.0, "blue": 0.0}}}
                    },
                    "fields": "italic,bold,fontSize,weightedFontFamily,foregroundColor"
                }
            })
        # 4. Normal text thông thường: 13pt, Times New Roman, Căn trái (START)
        else:
            requests.append({
                "updateParagraphStyle": {
                    "range": {"tabId": tab_id, "startIndex": st, "endIndex": en},
                    "paragraphStyle": {"alignment": "START"},
                    "fields": "alignment"
                }
            })
            requests.append({
                "updateTextStyle": {
                    "range": {"tabId": tab_id, "startIndex": st, "endIndex": en},
                    "textStyle": {
                        "fontSize": {"magnitude": 13, "unit": "PT"},
                        "weightedFontFamily": {"fontFamily": "Times New Roman"}
                    },
                    "fields": "fontSize,weightedFontFamily"
                }
            })

    # Chia batchUpdate để tránh vượt quota
    batch_size = 50
    for i in range(0, len(requests), batch_size):
        chunk = requests[i:i + batch_size]
        batch_update(doc_id, chunk)

    print(f"[GDocsHelper] Typography formatted for tab {tab_id}: Times New Roman 13pt, Headings, Code centered (standard black text).")

