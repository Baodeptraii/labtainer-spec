# Detailed step procedures

Use the full step skills below. Their instructions and shared standards are authoritative.

- [Step 5](../../labtainer-step-05-prep-rename/SKILL.md)
- [Step 6](../../labtainer-step-06-rebuild-test/SKILL.md)
- [Step 7](../../labtainer-step-07-publish-imodule/SKILL.md)
