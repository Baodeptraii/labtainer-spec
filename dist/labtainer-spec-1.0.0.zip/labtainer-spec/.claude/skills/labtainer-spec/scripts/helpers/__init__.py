"""
SecLab PTIT Helper Toolkit
Cung cấp các hàm và module tiện ích dùng chung cho Agent và Kỹ sư trong quy trình chuẩn hóa:
- helpers.vm: Điều khiển máy ảo qua SSH, tương tác terminal container và student qua xdotool, chụp ảnh màn hình.
- helpers.gdocs: Thao tác tự động với Google Docs, Google Drive, định dạng A4, lề, tiêu đề đỏ, bảng trong suốt, upload ảnh, gắn native comment neo kix.
- helpers.lab_parser: Phân tích cấu hình Labtainer (start, goals, results) và trích xuất tài liệu docx.
"""

from helpers import vm
from helpers import gdocs
from helpers import lab_parser

__all__ = ["vm", "gdocs", "lab_parser"]
