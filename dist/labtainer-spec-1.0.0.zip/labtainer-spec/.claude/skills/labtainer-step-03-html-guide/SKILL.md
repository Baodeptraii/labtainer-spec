---
name: labtainer-step-03-html-guide
description: >-
  Thực hiện Bước 3 trong quy trình chuẩn hoá bài lab Labtainer: Biên soạn file Hướng dẫn Thực hành HTML chuẩn hoá và đối soát checklist.
  Sử dụng khi người dùng yêu cầu "làm bước 3", "hoàn thiện bước 3", hoặc trong cụm "bước 3-4".
---

> **Cấu hình dùng chung:** Đọc [cấu hình](../labtainer-spec/references/configuration.md) và [chuẩn/checklist](../labtainer-spec/references/standards.md). Các `<...>` là tham số cần lấy từ cấu hình/quan sát, không chạy nguyên mẫu. Scripts và assets ở skill `labtainer-spec`. `configuration.md` bên dưới chỉ tài liệu cấu hình này. Mật khẩu lấy từ biến môi trường `connection.password_env`, không lưu trong JSON.


# Bước 3: Biên Soạn Hướng Dẫn Thực Hành HTML Chuẩn Hoá

Skill này hướng dẫn xây dựng file tài liệu hướng dẫn `.html` hoàn chỉnh cho bài lab mới, tuân thủ 100% mẫu thiết kế giao diện từ file template chuẩn `.claude/skills/labtainer-spec/assets/guide-template.html` và checklist tiêu chuẩn của SecLab PTIT.

## Mục Tiêu & Phạm Vi Đầu Ra (Deliverables)

1. **Vị trí lưu trữ file HTML mới**: Bắt buộc lưu vào thư mục `New-HTML` của môn học tương ứng:  
   `<project-root>\<tên_môn>\New-HTML\<tên_lab_mới>.html`  
   *(Ví dụ với môn KTXN: `<project-root>\KTXN\New-HTML\atk-mitre-t1595.html`)*.
2. **File HTML hoàn chỉnh**: Đầy đủ cấu trúc ngữ nghĩa HTML, CSS nhúng trực tiếp từ `.claude/skills/labtainer-spec/assets/guide-template.html` (độ rộng `.page` tối đa `860px`, có khối `@media print`), chia làm 4 phần tiêu chuẩn.
3. **Quy tắc màu sắc Huy hiệu Mức độ (Difficulty Badge ở Header)**:
   - **Dễ**: Màu **Xanh lá** (class `.badge-easy`, nền `#e8f5e9`, chữ `#2e7d32`, viền `#a5d6a7`).
   - **Trung bình**: Màu **Vàng** (class `.badge-medium`, nền `#fff3cd`, chữ `#856404`, viền `#ffc107`).
   - **Khó**: Màu **Đỏ** (class `.badge-hard`, nền `#fdecea`, chữ `#a83226`, viền `#f5b7b1`).
4. **Tuân thủ hệ thống Hộp màu sắc (Box Style) & Khối lệnh Terminal**:
   - **Khối màu đen terminal (`<pre><span class="cmd">...</span></pre>`)**: Dành riêng cho **lệnh sẵn sao chép (copy-paste trực tiếp)**, cú pháp cố định chuẩn xác mà sinh viên có thể chạy ngay không cần chỉnh sửa tham số.
   - **Xanh dương (`.box-info`)**: **Gợi ý câu lệnh cần sửa tham số** (dành cho các câu lệnh mang tính gợi ý, cú pháp mẫu hoặc template chứa các biến/tham số cần sinh viên tự thay thế như `<IP_server>`, `<cổng>`, `<tên_miền>`, `<tệp_tin>`).
   - **Xanh lá cây (`.box-success`)**: Chứa **Điều kiện hoàn thành** (nêu rõ các tiêu chí cụ thể hệ thống kiểm tra chấm điểm; **tuyệt đối KHÔNG ghi máy móc** như *"Sinh viên chạy lệnh checkwork và mục tiêu port_scan đạt trạng thái Y"* hay *"Lệnh checkwork trả về trạng thái Y cho mục tiêu..."*).
   - **Đỏ / Hồng nhạt (`.box-danger`)**: Chứa **Câu hỏi cho sinh viên** (kèm dòng gạch dưới trả lời).
   - **Vàng (`.box-warning`)**: Chứa **Lưu ý** quan trọng hoặc cảnh báo an toàn.
   - **Tình huống / Kịch bản**: Trình bày bằng văn bản thông thường, **tuyệt đối KHÔNG** cho vào khung box.
5. **Tuân thủ quy chuẩn văn phong & Tránh AI-style**:
   - Đổi 100% cách xưng hô từ **"bạn"** sang **"sinh viên"**.
   - **Loại bỏ Title Case**: Tránh viết hoa từng chữ cái đầu của từ (Ví dụ sai: *Các Nhiệm Vụ Của Bài Thực Hành* $\rightarrow$ Sửa đúng: *Các nhiệm vụ của bài thực hành*).
   - **Hạn chế văn phong dịch AI & bỏ tiếng Anh thừa**: Tuyệt đối tránh các cách diễn đạt AI sáo rỗng hoặc từ chèn tiếng Anh trong ngoặc (như `đường ống (pipeline)`, `Vulnerability Chaining (Xâu chuỗi lỗ hổng)`). Dùng tiếng Việt chuyên ngành tự nhiên, chuẩn xác.
   - **Lược bỏ lệnh cơ bản**: Những lệnh quá đơn giản (`cd`, `ls`, `cat`) không cần gợi ý chi tiết từng bước.
   - **Sửa tiêu đề mục**: Mục thực hành luôn mang tiêu đề: `4. Các nhiệm vụ của bài thực hành` (không dùng `5. Nhiệm vụ`).
   - **Quy tắc phần tải và khởi động bài thực hành (theo chuẩn `guide-template.html`)**: Trình bày trong hộp `.box-info` chuẩn:
     ```html
     <div class="box box-info">
       Để tải bài thực hành, sinh viên thực hiện câu lệnh: <br />
       <code>imodule https://github.com/<registry-namespace>/<tên_lab_mới>/raw/refs/heads/main/imodule.tar</code><br />
       Để khởi động bài thực hành, sinh viên dùng câu lệnh: <br />
       <code>labtainer <tên_lab_mới></code><br />
       <em>(chú ý: sinh viên sử dụng mã sinh viên của mình để nhập thông tin email người thực hiện bài lab khi có yêu cầu, để sử dụng khi chấm điểm)</em>
     </div>
     ```
   - **Lược bỏ mục kiểm tra và kết thúc**: Tuyệt đối KHÔNG ghi mục "Hướng dẫn kiểm tra và kết thúc bài thực hành" (không đưa lệnh checkwork hay stoplab ở cuối trang HTML), chỉ ghi các nhiệm vụ thực hành.
   - **Số thứ tự câu hỏi**: Đánh số tăng dần từ đầu đến cuối bài (Câu 1, Câu 2, ...).
   - **Footer bản quyền**: Luôn có chân trang SecLab PTIT.
6. **Quy tắc Tiêu đề nhiệm vụ (Task Header)**: Bắt buộc tuân theo cấu trúc: `<div class="task-header">Nhiệm vụ <số> - <mã_checkwork>: <Tên nhiệm vụ></div>` (Ví dụ: `Nhiệm vụ 1 - port_scan: Xác định cổng dịch vụ web nội bộ qua lỗ hổng SSRF`, `Nhiệm vụ 1 - make_file: Tạo 1 file`).
7. **Quy tắc Sơ đồ mạng (Topology)**: Sơ đồ chỉ thể hiện hạ tầng mạng thuần túy (tên các máy, IP, vai trò chung, dải mạng LAN). **Tuyệt đối không ghi chú spoiler về lỗ hổng, tham số, cổng ẩn, tên bảng CSDL, hay các mũi tên payload mô tả từng bước tấn công**.
8. **Quy tắc Nhiệm vụ thực hành**: **Tuyệt đối không đưa lệnh `checkwork` hay `stoplab` thành các "Bước" trong nhiệm vụ** (các bước chỉ dành cho thao tác kỹ thuật).
9. **Đối soát hoàn thành**: Điền trạng thái đáp ứng vào cột 4 của Bảng tổng hợp lỗi ở Thẻ 2.



---

## Cấu Trúc CSS & HTML Mẫu Chuẩn Xác 100% Theo `guide-template.html`

File HTML mới bắt buộc kế thừa **toàn bộ định dạng CSS và cấu trúc 4 phần lớn** từ `.claude/skills/labtainer-spec/assets/guide-template.html`:

```html
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Hướng dẫn thực hành - [Mã Lab] [Tiêu đề tiếng Việt]</title>
  <style>
    /* Bê nguyên toàn bộ khối <style> từ template.html */
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: "Times New Roman", Times, serif; font-size: 13pt; line-height: 1.8; color: #1a1a1a; background: #f4f6f9; padding: 30px 20px; }
    .page { max-width: 900px; margin: 0 auto; background: #fff; padding: 50px 60px; border: 1px solid #d0d5dd; box-shadow: 0 4px 16px rgba(0, 0, 0, 0.08); }
    .header { text-align: center; border-bottom: 3px solid #003087; padding-bottom: 20px; margin-bottom: 30px; }
    .header .institution { font-size: 11pt; color: #555; text-transform: uppercase; letter-spacing: 1px; }
    .header h1 { font-size: 20pt; color: #003087; margin-top: 8px; font-weight: bold; }
    .header .subtitle { font-size: 13pt; color: #444; margin-top: 4px; font-style: italic; }
    .header .meta { margin-top: 14px; display: flex; justify-content: center; gap: 12px; flex-wrap: wrap; }
    .badge { display: inline-block; padding: 4px 14px; border-radius: 20px; font-size: 10pt; font-weight: bold; }
    .badge-easy { background: #e8f5e9; color: #2e7d32; border: 1px solid #a5d6a7; }
    .badge-medium { background: #fff3cd; color: #856404; border: 1px solid #ffeeba; }
    .badge-hard { background: #fdecea; color: #a83226; border: 1px solid #f5b7b1; }
    .badge-network { background: #d9ecff; color: #0b4f8a; border: 1px solid #a9d1f7; }
    .badge-protocol { background: #e8f5e9; color: #2e7d32; border: 1px solid #a5d6a7; }
    h2 { font-size: 14pt; color: #003087; border-left: 5px solid #003087; padding-left: 10px; margin: 32px 0 12px; font-weight: bold; }
    h3 { font-size: 12.5pt; color: #1a5276; margin: 20px 0 8px; font-weight: bold; }
    p { margin-bottom: 10px; }
    ul, ol { margin: 8px 0 10px 24px; }
    li { margin-bottom: 5px; }
    code { background: #f0f0f0; border: 1px solid #ddd; border-radius: 4px; padding: 2px 7px; font-family: "Courier New", monospace; font-size: 11pt; color: #b03a2e; word-break: break-all; overflow-wrap: anywhere; }
    pre { background: #1e1e2e; color: #cdd6f4; border-radius: 8px; padding: 16px 20px; font-family: "Courier New", monospace; font-size: 11pt; overflow-x: auto; margin: 10px 0 14px; line-height: 1.6; white-space: pre-wrap; text-align: center; }
    pre .cmd { color: #89dceb; font-style: italic; }
    .box { border-radius: 6px; padding: 12px 16px; margin: 14px 0; font-size: 12pt; }
    .box-info { background: #e8f4fd; border-left: 5px solid #2196f3; }
    .box-warning { background: #fff3cd; border-left: 5px solid #ffc107; }
    .box-danger { background: #fdecea; border-left: 5px solid #f44336; }
    .box-success { background: #e8f5e9; border-left: 5px solid #4caf50; }
    .task-block { border: 1px solid #b0c4de; border-radius: 8px; margin: 18px 0; overflow: hidden; }
    .task-header { background: #003087; color: #fff; padding: 10px 18px; font-size: 12.5pt; font-weight: bold; }
    .task-body { padding: 14px 18px; }
    table { width: 100%; border-collapse: collapse; margin: 14px 0; font-size: 12pt; }
    th { background: #003087; color: #fff; padding: 10px 12px; text-align: left; }
    td { padding: 9px 12px; border: 1px solid #d0d5dd; vertical-align: top; }
    tr:nth-child(even) td { background: #f5f7fa; }
    .topology { text-align: center; margin: 18px 0; }
    .topo-wrap { display: inline-block; max-width: 100%; background: #f8fafc; border: 1px solid #cdd0d8; border-radius: 10px; padding: 14px 16px; box-sizing: border-box; }
    .topo-wrap svg { display: block; width: 100%; max-width: 100%; height: auto; }
    .footer { margin-top: 40px; border-top: 1px solid #d0d5dd; padding-top: 14px; text-align: center; font-size: 10pt; color: #777; }
  </style>
</head>
<body>
  <div class="page">
    <div class="header">
      <div class="institution">Học viện Công nghệ Bưu chính Viễn thông - SecLab PTIT</div>
      <h1>HƯỚNG DẪN THỰC HÀNH</h1>
      <div class="subtitle">[Mã Lab] - [Tiêu đề tiếng Việt]</div>
      <div class="meta">
        <span class="badge badge-medium">Mức độ: ...</span>
        <span class="badge badge-network">...</span>
        <span class="badge badge-protocol">...</span>
      </div>
    </div>

    <!-- 1. GIỚI THIỆU LAB -->
    <h2>1. Giới thiệu Lab</h2>
    <table>
      <tr><th style="width: 220px;">Thông tin</th><th>Chi tiết</th></tr>
      <tr><td><strong>Tên Lab</strong></td><td><code>[mã_lab]</code></td></tr>
      <tr><td><strong>Mức độ</strong></td><td>...</td></tr>
      <tr><td><strong>Công cụ sử dụng</strong></td><td><code>...</code></td></tr>
    </table>
    <h3>Mục tiêu học tập</h3>
    <ul><li>...</li></ul>
    <h3>Kỹ năng đạt được</h3>
    <ul><li>...</li></ul>

    <!-- 2. KỊCH BẢN -->
    <h2>2. Kịch bản</h2>
    <p><strong>Tình huống:</strong><br />[Văn bản thường, không bọc box]</p>
    <p><strong>Vai trò của sinh viên:</strong></p>
    <ul><li>...</li></ul>
    <h3>Sơ đồ mô hình mạng</h3>
    <div class="topology">
      <div class="topo-wrap" style="display: block; width: 100%; box-sizing: border-box;">
        <svg viewBox="0 0 960 460" xmlns="http://www.w3.org/2000/svg">
          <!-- Sơ đồ mạng SVG trực quan -->
        </svg>
      </div>
    </div>

    <!-- 3. KIẾN THỨC BỔ TRỢ -->
    <h2>3. Kiến thức bổ trợ</h2>
    <ul><li><strong>[Thuật ngữ]:</strong> Giải thích...</li></ul>
    <h3>Bảng tùy chọn và cú pháp công cụ sử dụng trong bài</h3>
    <table>
      <tr><th style="width: 170px;">Công cụ</th><th style="width: 260px;">Tùy chọn / Cú pháp</th><th>Mô tả tác dụng</th></tr>
      <tr><td><code>...</code></td><td><code>...</code></td><td>...</td></tr>
    </table>

    <!-- 4. CÁC NHIỆM VỤ CỦA BÀI THỰC HÀNH -->
    <h2>4. Các nhiệm vụ của bài thực hành</h2>
    <div class="box box-info">
      Để tải bài thực hành, sinh viên thực hiện câu lệnh: <br />
      <code>imodule https://github.com/<registry-namespace>/[tên_repo]/raw/refs/heads/main/[tên_lab_mới].tar</code><br />
      Để khởi động bài thực hành, sinh viên dùng câu lệnh: <br />
      <code>labtainer [tên_lab_mới]</code><br />
      <em>(chú ý: sinh viên sử dụng mã sinh viên của mình để nhập thông tin email người thực hiện bài lab khi có yêu cầu, để sử dụng khi chấm điểm)</em>
    </div>

    <div class="task-block">
      <div class="task-header">Nhiệm vụ 1 - [mã_checkwork]: [Tên nhiệm vụ]</div>
      <div class="task-body">
        <p><strong>Bước 1:</strong> ...</p>
        <pre><span class="cmd">[lệnh_chạy]</span></pre>
        <div class="box box-success">
          <strong>Điều kiện hoàn thành nhiệm vụ:</strong> Hệ thống kiểm tra [tiêu chí cụ thể cần kiểm tra, không nhắc biến checkwork Y]
        </div>
        <div class="box box-danger">
          <strong>Câu hỏi 1:</strong><br />
          [Nội dung câu hỏi]<br />
          <strong>Trả lời:</strong> _______________________________________
        </div>
      </div>
    </div>

    <div class="footer">
      <p>Học viện Công nghệ Bưu chính Viễn thông - SecLab PTIT</p>
    </div>
  </div>
</body>
</html>
```

---

## Checklist Kiểm Tra Bắt Buộc Sau Khi Tạo HTML
Sau khi sinh mã HTML, hãy tự động đối soát với bảng checklist sau:
- [ ] **Footer**: Đã có chân trang ghi nguồn bản quyền SecLab PTIT.
- [ ] **Số thứ tự câu hỏi**: Tăng dần đều từ đầu đến cuối bài (Câu 1, Câu 2, ...).
- [ ] **Dòng trả lời câu hỏi**: Có `Trả lời: ___________________________` ngay dưới câu hỏi.
- [ ] **Cách xưng hô**: Toàn bộ là **sinh viên**, không còn từ "bạn".
- [ ] **Mô hình mạng**: Được trình bày dưới dạng sơ đồ/hình vẽ SVG hoặc bảng phân vai rõ ràng, thuần túy hạ tầng, không spoiler.
- [ ] **Lược bỏ lệnh đơn giản**: Không hướng dẫn những lệnh cơ bản hiển nhiên (`cd`, `ls`, `cat`).
- [ ] **Loại bỏ yếu tố AI**: Không viết hoa Title Case; Không để từ tiếng Anh trong ngoặc khi đã có tiếng Việt.
- [ ] **Đúng màu các Box**: Xanh lá = Điều kiện; Đỏ/Hồng = Câu hỏi; Vàng = Lưu ý; Xanh dương = Gợi ý lệnh / Hộp tải lab.
- [ ] **Tình huống / Kịch bản**: Là văn bản thuần, không bọc box.
- [ ] **Tiêu đề mục 4**: Đúng chữ `4. Các nhiệm vụ của bài thực hành`.
- [ ] **Phần tải và khởi động bài thực hành**: Bọc trong hộp `.box-info` chuẩn theo `guide-template.html`, có hướng dẫn sinh viên dùng mã sinh viên khi nhập email.
- [ ] **Lược bỏ kết thúc**: Không ghi mục "Hướng dẫn kiểm tra và kết thúc bài thực hành" (stoplab/checkwork) ở cuối HTML.

